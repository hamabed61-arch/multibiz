# Madrasa Malela — Mahudhurio (offline, SQLite)

Mfumo wa mahudhurio ya wanafunzi wa Madrasa Malela. Unafanya kazi **bila internet na bila domain** — data zote
ziko ndani ya simu (SQLite). Lugha: **Kiswahili, English, العربية** (RTL).

## Mantiki ya siku na vipindi

- **Siku za wiki** (Jumatatu–Ijumaa): kipindi kimoja tu — "Leo" inaonyesha moja kwa moja.
- **Wikendi** (Jumamosi na Jumapili): vipindi viwili — **Asubuhi** na **Jioni**, kila kimoja kinahifadhiwa peke yake.

## Sehemu za app

- **Leo** — weka mahudhurio ya siku ya sasa kwa mguso mmoja (Yupo / Hayupo), kwa kundi la Watoto au Watu wazima. Kubonyeza alama iliyochaguliwa tena kunaifuta.
- **Rekodi** — chagua tarehe yoyote iliyopita kuona au kusahihisha mahudhurio ya siku hiyo.
- **Ripoti** — muhtasari wa kipindi (wiki, mwezi, miezi 3, mwaka, zote), mwenendo wa kila siku, na orodha ya kila mwanafunzi kwa asilimia ya mahudhurio — wanaokosa zaidi wanaonekana juu.
- **Wanafunzi** — ongeza, hariri, futa, tafuta kwa jina, chuja kwa Watoto/Watu wazima.
- **Mipangilio** — lugha, maswali ya usalama, nenosiri, backup/restore, futa data yote.

## Kupata APK kupitia GitHub

1. Tengeneza repository mpya kwenye GitHub.
2. Pakia `madrasa-malela.zip` (kama ilivyo) na `.github/workflows/android.yml`.
   *(Ukiwa na kompyuta, unaweza pia kutoa zip na kupakia faili zote moja kwa moja.)*
3. Fungua **Actions → Build Android APK → Run workflow**.
4. Ukimaliza (dakika ~5–10), pakua `MadrasaMalela.apk` kutoka **Artifacts**.

APK hii ni ya *debug* (inafungwa moja kwa moja). Logo ya Madrasa Malela inatumika kama icon ya app kwenye simu.

## Kusahau nenosiri

Wakati wa usajili unajibu maswali 3 ya usalama: jina lako la utani, jina la tatu la mama, na sehemu uliyozaliwa.
Ukisahau nenosiri: **Umesahau nenosiri?** kwenye ukurasa wa kuingia → jibu maswali → weka nenosiri jipya.
Majibu yanahifadhiwa kama hash (si maandishi wazi); herufi kubwa/ndogo, alama na nafasi hazijalishi. Majaribio 5 mabaya = kufungwa dakika 5.
Zinaweza kubadilishwa kwenye **Settings → Maswali ya usalama** (linahitaji nenosiri la sasa).

## Kujaribu kwenye kompyuta (hiari)

```
python3 dev/server.py        # kisha fungua http://localhost:5173
```
Hii inatumia SQLite ya Python kwa majaribio ya UI tu. Kwenye simu, app inatumia `@capacitor-community/sqlite`.

## Muundo

```
index.html, vite.config.js, capacitor.config.json, package.json
.github/workflows/android.yml   ← ujenzi wa APK
resources/android/res/          ← icon ya app (logo ya Madrasa Malela)
src/
  main.js, app.js, state.js     ← kuanza, ganda (sidebar/topbar), hali
  db/                           ← schema.js (students, attendance), index.js, drivers
  data.js                       ← mantiki ya mahudhurio, siku/vipindi, ripoti
  security.js, auth.js          ← nenosiri na maswali ya usalama (PBKDF2)
  i18n/ (sw, en, ar)            ← tafsiri
  screens/                      ← leo, wanafunzi, rekodi, ripoti, settings, about, onboarding, login, recover
  styles.css, icons.css         ← muonekano (mwanga, kijani+dhahabu) na icons za ndani
tools/  gen-icons.py, check-i18n.py
```

- **Kuongeza lugha:** nakili `src/i18n/en.js`, ongeza kwenye `LANGS` ndani ya `src/i18n/index.js`.
- **Backup:** kila rekodi ina `id` ya UUID, hivyo backup/restore (JSON) inafanya kazi kikamilifu kwa wanafunzi na mahudhurio yote.

## Mipaka ya toleo hili

- Mtumiaji mmoja tu (mwalimu mkuu) kwa kila simu — hakuna login za walimu wengi.
- Hakuna arifa za Android (notifications) kwa toleo hili.
- Nenosiri likipotea data haiwezi kurudishwa isipokuwa kwa maswali ya usalama au backup.
