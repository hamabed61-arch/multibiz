// reports.js - Ripoti: mwenendo wa mahudhurio na wanafunzi wanaokosa mara kwa mara
import { t, num, fmtDayShort } from '../i18n/index.js';
import { esc, ic, pageHead, emptyState } from '../ui.js';
import { rangeTotals, dailySeries, studentStats } from '../data.js';
import { rangeFor, rangeTabs, catTabs, onTabs, onCatTabs, rateClass, ratePillClass } from './_shared.js';

export default async function reports(view) {
  let range = 'month';
  let category = 'all';

  async function draw() {
    const [from, to] = rangeFor(range);
    const totals = await rangeTotals(from, to, category);
    const days = Math.round((new Date(to) - new Date(from)) / 86400000) + 1;
    const series = days <= 31 ? await dailySeries(from, to, category) : null;
    const students = await studentStats(from, to, category);
    const max = series ? Math.max(1, ...series.map((s) => s.present + s.absent)) : 1;

    view.innerHTML = `
      ${pageHead(t('nav_reports'))}
      ${rangeTabs(range)}
      ${catTabs(category)}

      <div class="card">
        <div class="card-title">${ic('chart-simple')} ${esc(t('rep_overview'))}</div>
        <div class="mini-stats">
          <div><b>${num(totals.total)}</b><small>${esc(t('rep_sessions'))}</small></div>
          <div><b class="c-green">${num(totals.present)}</b><small>${esc(t('present'))}</small></div>
          <div><b class="c-red">${num(totals.absent)}</b><small>${esc(t('absent'))}</small></div>
          <div><b class="${rateClass(totals.rate)}">${totals.rate === null ? '—' : totals.rate + '%'}</b><small>${esc(t('rep_rate'))}</small></div>
        </div>
      </div>

      ${series ? `<div class="card"><div class="card-title">${ic('chart-column')} ${esc(t('rep_daily'))}</div>
        <div class="bars ${series.length > 14 ? 'dense' : ''}">${series.map((s) => `<div class="bar-col"><div class="bar" style="height:${s.rate === null ? 3 : Math.max(3, (s.rate / 100) * 100)}%" title="${s.rate === null ? '' : s.rate + '%'}"></div>${series.length <= 21 ? `<small>${esc(fmtDayShort(s.d).split(' ')[0])}</small>` : ''}</div>`).join('')}</div></div>` : ''}

      <div class="card"><div class="card-title">${ic('ranking-star')} ${esc(t('rep_by_student'))}</div>
        ${students.length ? students.map((s) => `
          <div class="row slim"><div class="row-main"><b>${esc(s.name)}</b><small>${esc(t('cat_' + s.category))} • ${esc(t('n_sessions', { n: s.total }))}</small></div>
            <span class="stock-pill ${ratePillClass(s.rate)}">${s.rate === null ? t('rep_no_data') : s.rate + '%'}</span></div>`).join('')
          : emptyState('user-graduate', t('no_students'))}
      </div>`;
    onTabs(view, (k) => { range = k; draw(); });
    onCatTabs(view, (k) => { category = k; draw(); });
  }
  await draw();
}
