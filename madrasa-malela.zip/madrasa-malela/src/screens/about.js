// about.js - Kuhusu app
import { t } from '../i18n/index.js';
import { esc, pageHead, brandLogo } from '../ui.js';

export default async function about(view) {
  view.innerHTML = `
    ${pageHead(t('nav_about'))}
    <div class="card center-text about-card">
      ${brandLogo('big')}
      <h3 class="brand-title">Madrasa <span>Malela</span></h3>
      <p class="muted">${esc(t('app_tagline'))}</p>
      <p class="muted">${esc(t('about_version', { v: '1.0.0' }))} • ${esc(t('app_offline'))}</p>
    </div>`;
}
