// login.js - kufungua app kwa nenosiri
import { t, LANGS, setLang, getLang } from '../i18n/index.js';
import { $, esc, ic, brandLogo } from '../ui.js';
import { hashPin } from '../auth.js';
import { setSetting } from '../db/index.js';
import { S } from '../state.js';
import { showRecover } from './recover.js';

export function showLogin(root, onUnlocked, onReset) {
  root.innerHTML = `
    <div class="ob">
      <form class="ob-card center" id="loginForm">
        ${brandLogo('big')}
        <h1>${esc(t('hello_user', { name: S.user.name }))}</h1>
        <p class="ob-sub">${esc(t('enter_password'))}</p>
        <div class="fg"><input id="lg_pin" type="password" autocomplete="current-password" placeholder="${esc(t('password'))}" autofocus></div>
        <div class="form-error" id="lg_err" hidden></div>
        <button class="btn btn-gold block" type="submit">${ic('lock-open')} ${esc(t('unlock'))}</button>
        <div class="lang-mini">${LANGS.map((l) => `<button type="button" class="${getLang() === l.code ? 'on' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}</div>
        <button type="button" class="link-btn strong" id="lg_reset">${esc(t('forgot_password'))}</button>
      </form>
    </div>`;
  const err = $('#lg_err', root);
  $('#loginForm', root).onsubmit = async (e) => {
    e.preventDefault();
    const hash = await hashPin($('#lg_pin', root).value, S.user.salt);
    if (hash === S.user.hash) { S.unlocked = true; onUnlocked(); }
    else { err.hidden = false; err.textContent = t('err_wrong_password'); }
  };
  root.querySelectorAll('[data-lang]').forEach((b) => (b.onclick = async () => {
    setLang(b.dataset.lang);
    await setSetting('lang', b.dataset.lang);
    S.user.lang = b.dataset.lang;
    showLogin(root, onUnlocked, onReset);
  }));
  $('#lg_reset', root).onclick = () => showRecover(root, {
    onDone: onUnlocked,
    onBack: () => showLogin(root, onUnlocked, onReset),
    onReset
  });
}
