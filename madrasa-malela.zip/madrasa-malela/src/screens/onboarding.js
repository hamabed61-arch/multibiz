// onboarding.js - usajili: lugha -> akaunti -> maswali ya usalama -> tayari
import { t, LANGS, setLang, getLang } from '../i18n/index.js';
import { $, $$, esc, ic, brandLogo } from '../ui.js';
import { setSetting, tx } from '../db/index.js';
import { hashPin, newSalt, normalizeAnswer } from '../auth.js';
import { saveSecurity } from '../security.js';
import { S, loadUser } from '../state.js';

const STEPS = ['lang', 'account', 'security'];

export function startOnboarding(root, onDone) {
  const ob = { step: 'lang', name: '', phone: '', pin: '', pin2: '', sec: ['', '', ''], error: '' };
  const dots = () => `<div class="ob-dots">${STEPS.map((s, i) => `<i class="${i <= STEPS.indexOf(ob.step) ? 'on' : ''}"></i>`).join('')}</div>`;

  function frame(title, sub, body, { back = true, next = t('next') } = {}) {
    root.innerHTML = `
      <div class="ob">
        <div class="ob-card">
          ${dots()}
          <h1>${esc(title)}</h1>
          ${sub ? `<p class="ob-sub">${esc(sub)}</p>` : ''}
          <div class="ob-body">${body}</div>
          ${ob.error ? `<div class="form-error">${ic('circle-exclamation')} ${esc(ob.error)}</div>` : ''}
          <div class="btn-row ob-nav">
            ${back ? `<button class="btn btn-ghost" data-back>${esc(t('back'))}</button>` : ''}
            ${next ? `<button class="btn btn-gold" data-next>${esc(next)}</button>` : ''}
          </div>
        </div>
      </div>`;
    const b = $('[data-back]', root);
    if (b) b.onclick = () => { ob.error = ''; go(STEPS[STEPS.indexOf(ob.step) - 1]); };
    const n = $('[data-next]', root);
    if (n) n.onclick = onNext;
  }
  function go(step) { ob.step = step; render(); }
  function fail(msg) { ob.error = msg; render(); }

  function stepLang() {
    root.innerHTML = `
      <div class="ob">
        <div class="ob-card center">
          ${dots()}
          ${brandLogo('big')}
          <h1 class="brand-title">Madrasa <span>Malela</span></h1>
          <p class="ob-sub">${esc(t('app_tagline'))}</p>
          <p class="ob-label">${esc(t('choose_language'))}</p>
          <div class="lang-list">
            ${LANGS.map((l) => `<button class="lang-btn ${getLang() === l.code ? 'sel' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}
          </div>
        </div>
      </div>`;
    $$('[data-lang]', root).forEach((b) => (b.onclick = () => { setLang(b.dataset.lang); go('account'); }));
  }

  function stepAccount() {
    frame(t('ob_account_title'), t('ob_account_sub'), `
      <div class="fg"><label>${esc(t('full_name'))} <b>*</b></label><input id="ob_name" value="${esc(ob.name)}" autocomplete="name"></div>
      <div class="fg"><label>${esc(t('phone'))}</label><input id="ob_phone" type="tel" value="${esc(ob.phone)}" autocomplete="tel"></div>
      <div class="fg"><label>${esc(t('password'))} <b>*</b></label><input id="ob_pin" type="password" value="${esc(ob.pin)}" autocomplete="new-password"><small>${esc(t('password_hint'))}</small></div>
      <div class="fg"><label>${esc(t('password_confirm'))} <b>*</b></label><input id="ob_pin2" type="password" value="${esc(ob.pin2)}" autocomplete="new-password"></div>`);
  }

  function stepSecurity() {
    frame(t('sec_title'), t('sec_sub'), `
      ${[1, 2, 3].map((i) => `<div class="fg sec-q"><label for="ob_s${i}"><span class="q-no">${i}</span>${esc(t('sec_q' + i))} <b>*</b></label>
        <input id="ob_s${i}" value="${esc(ob.sec[i - 1])}" autocomplete="off"></div>`).join('')}
      <small class="muted">${esc(t('sec_hint'))}</small>`, { next: t('finish') });
  }

  async function onNext() {
    ob.error = '';
    if (ob.step === 'account') {
      ob.name = $('#ob_name', root).value.trim();
      ob.phone = $('#ob_phone', root).value.trim();
      ob.pin = $('#ob_pin', root).value;
      ob.pin2 = $('#ob_pin2', root).value;
      if (!ob.name) return fail(t('err_name'));
      if (ob.pin.length < 4) return fail(t('err_pin_short'));
      if (ob.pin !== ob.pin2) return fail(t('err_pin_match'));
      return go('security');
    }
    if (ob.step === 'security') {
      ob.sec = [1, 2, 3].map((i) => $('#ob_s' + i, root).value.trim());
      if (ob.sec.some((a) => normalizeAnswer(a).length < 2)) return fail(t('err_sec_fill'));
      return finish();
    }
  }

  async function finish() {
    const btn = $('[data-next]', root);
    if (btn) btn.disabled = true;
    try {
      const salt = newSalt();
      const hash = await hashPin(ob.pin, salt);
      await tx(async () => {
        await setSetting('user_name', ob.name);
        await setSetting('user_phone', ob.phone);
        await setSetting('pin_salt', salt);
        await setSetting('pin_hash', hash);
        await setSetting('lang', getLang());
        await saveSecurity(ob.sec);
      });
      S.user = await loadUser();
      S.unlocked = true;
      onDone();
    } catch (e) {
      console.error(e);
      if (btn) btn.disabled = false;
      fail(String(e.message || e));
    }
  }

  function render() { ({ lang: stepLang, account: stepAccount, security: stepSecurity })[ob.step](); }
  render();
}
