// students.js - Wanafunzi: orodha, kuongeza, kuhariri, kufuta
import { t } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, formData, emptyState, pageHead, debounce, confirmBox } from '../ui.js';
import { listStudents, saveStudent, deleteStudent, studentHistory } from '../data.js';
import { fmtDate } from '../i18n/index.js';
import { catTabs, onTabs, onCatTabs } from './_shared.js';

export default async function students(view, { params }) {
  let category = 'all';
  let q = '';

  async function draw() {
    const list = await listStudents(category, q);
    view.innerHTML = `
      ${pageHead(t('nav_students'))}
      ${catTabs(category)}
      <div class="search-bar">${ic('magnifying-glass')}<input id="q" type="search" placeholder="${esc(t('search'))}" value="${esc(q)}"></div>
      <div id="slist">${list.length ? list.map(row).join('') : emptyState('user-graduate', t('no_students'), t('no_students_sub'))}</div>
      <button class="fab-btn" id="fab" aria-label="add">${ic('user-plus')}</button>`;
    onCatTabs(view, (k) => { category = k; draw(); });
    $('#q', view).oninput = debounce((e) => { q = e.target.value; draw(); }, 200);
    $('#fab', view).onclick = () => studentForm(null, draw);
    $$('.row[data-id]', view).forEach((b) => (b.onclick = () => open(list.find((s) => s.id === b.dataset.id))));
  }

  function row(s) {
    return `<button class="row" data-id="${s.id}"><div class="row-icon ${s.category === 'mtoto' ? 'c-blue' : 'c-purple'}">${ic(s.category === 'mtoto' ? 'child' : 'user')}</div>
      <div class="row-main"><b>${esc(s.name)}</b><small>${esc(t('cat_' + s.category))}${s.phone ? ' • ' + esc(s.phone) : ''}</small></div>
      <div class="row-end">${ic('chevron-right')}</div></button>`;
  }

  async function open(s) {
    const hist = await studentHistory(s.id, 20);
    sheet(s.name, `
      <div class="kv"><span>${esc(t('category'))}</span><b>${esc(t('cat_' + s.category))}</b></div>
      ${s.phone ? `<div class="kv"><span>${esc(t('phone'))}</span><b>${esc(s.phone)}</b></div>` : ''}
      <div class="btn-row wrap">
        <button class="btn btn-ghost" id="sEdit">${ic('pen')} ${esc(t('edit'))}</button>
        <button class="btn btn-danger" id="sDel">${ic('trash-can')} ${esc(t('delete'))}</button>
      </div>
      ${hist.length ? `<div class="card-title sm">${esc(t('history'))}</div>` + hist.map((h) => `
        <div class="row slim"><div class="row-main"><b>${esc(fmtDate(h.attendance_date))}</b><small>${esc(t('session_' + h.session))}</small></div>
        <span class="stock-pill ${h.status === 'present' ? 'lvl-good' : 'lvl-danger'}">${esc(t(h.status))}</span></div>`).join('') : ''}`,
    (body, close) => {
      $('#sEdit', body).onclick = () => { close(); studentForm(s, draw); };
      $('#sDel', body).onclick = async () => {
        if (await confirmBox(t('delete_confirm', { name: s.name }))) { await deleteStudent(s.id); close(); draw(); }
      };
    });
  }

  await draw();
  if (params.get('new')) studentForm(null, draw);
}

export function studentForm(s, onDone) {
  sheet(s ? t('edit') : t('add_student'), `<form id="stForm">
    ${field({ label: t('full_name'), name: 'name', value: s?.name, required: true })}
    ${selectField({ label: t('category'), name: 'category', value: s?.category || 'mtoto', options: [{ value: 'mtoto', label: t('cat_mtoto') }, { value: 'mzima', label: t('cat_mzima') }] })}
    ${field({ label: t('phone'), name: 'phone', type: 'tel', value: s?.phone })}
    <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
    $('#stForm', body).onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(e.target);
      if (!f.name) return toast(t('err_name'), 'danger');
      await saveStudent(f, s?.id);
      toast(t('saved'), 'good');
      close();
      onDone && onDone();
    };
  });
}
