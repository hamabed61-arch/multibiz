// recover.js - kusahau nenosiri: jibu maswali 3 ya usalama kisha weka nenosiri jipya
import { t } from '../i18n/index.js';
import { $, esc, ic, toast, confirmBox, brandLogo } from '../ui.js';
import { normalizeAnswer } from '../auth.js';
import { verifySecurity, resetPassword, lockMinutesLeft } from '../security.js';
import { wipeAll } from '../db/index.js';
import { S } from '../state.js';

export function showRecover(root, { onDone, onBack, onReset }) {
  const card = (inner) => { root.innerHTML = `<div class="ob"><div class="ob-card">${inner}</div></div>`; };
  const erase = async () => {
    if (await confirmBox(t('reset_warning'), { okText: t('reset_app') })) { await wipeAll(); onReset(); }
  };

  if (!S.user.sec) {
    card(`
      ${brandLogo('big warn')}
      <h1 class="center-text">${esc(t('recover_title'))}</h1>
      <p class="ob-sub center-text">${esc(t('recover_none'))}</p>
      <button class="btn btn-danger block" id="rcErase">${ic('trash-can')} ${esc(t('recover_erase'))}</button>
      <button class="btn btn-ghost block" id="rcBack">${esc(t('back_to_login'))}</button>`);
    $('#rcErase', root).onclick = erase;
    $('#rcBack', root).onclick = onBack;
    return;
  }

  async function stepQuestions(message = '') {
    const locked = await lockMinutesLeft();
    card(`
      <h1>${esc(t('recover_title'))}</h1>
      <p class="ob-sub">${esc(t('recover_sub'))}</p>
      <form id="rcForm">
        ${[1, 2, 3].map((i) => `<div class="fg sec-q"><label for="rc_a${i}"><span class="q-no">${i}</span>${esc(t('sec_q' + i))}</label>
          <input id="rc_a${i}" name="a${i}" autocomplete="off" ${locked ? 'disabled' : ''}></div>`).join('')}
        <div class="form-error" id="rcErr" ${message || locked ? '' : 'hidden'}>${ic('circle-exclamation')} <span>${esc(locked ? t('err_sec_locked', { m: locked }) : message)}</span></div>
        <button class="btn btn-gold block" type="submit" ${locked ? 'disabled' : ''}>${ic('shield-halved')} ${esc(t('recover_verify'))}</button>
      </form>
      <button class="btn btn-ghost block" id="rcBack">${esc(t('back_to_login'))}</button>
      <button class="link-btn" id="rcErase">${esc(t('recover_erase'))}</button>`);
    $('#rcBack', root).onclick = onBack;
    $('#rcErase', root).onclick = erase;
    $('#rcForm', root).onsubmit = async (e) => {
      e.preventDefault();
      const answers = [1, 2, 3].map((i) => e.target['a' + i].value);
      if (answers.some((a) => normalizeAnswer(a).length < 1)) return stepQuestions(t('err_sec_fill'));
      const r = await verifySecurity(answers);
      if (r.ok) return stepNewPassword();
      if (r.locked) return stepQuestions(t('err_sec_locked', { m: r.locked }));
      return stepQuestions(t('err_sec_wrong', { n: r.left }));
    };
  }

  function stepNewPassword(message = '') {
    card(`
      <h1>${esc(t('recover_new_title'))}</h1>
      <form id="npForm" style="margin-top:14px">
        <div class="fg"><label>${esc(t('new_password'))}</label><input id="np1" type="password" autocomplete="new-password"></div>
        <div class="fg"><label>${esc(t('password_confirm'))}</label><input id="np2" type="password" autocomplete="new-password"></div>
        <div class="form-error" id="npErr" ${message ? '' : 'hidden'}>${ic('circle-exclamation')} <span>${esc(message)}</span></div>
        <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button>
      </form>`);
    $('#npForm', root).onsubmit = async (e) => {
      e.preventDefault();
      const a = $('#np1', root).value, b = $('#np2', root).value;
      if (a.length < 4) return stepNewPassword(t('err_pin_short'));
      if (a !== b) return stepNewPassword(t('err_pin_match'));
      await resetPassword(a);
      toast(t('recover_done'), 'good');
      S.unlocked = true;
      onDone();
    };
  }

  stepQuestions();
}
