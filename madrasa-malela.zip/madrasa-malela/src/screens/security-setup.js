// security-setup.js - fomu ya maswali ya usalama (kwa mtumiaji aliyeingia): kuweka au kubadilisha
import { t } from '../i18n/index.js';
import { $, esc, ic, sheet, toast, field, formData } from '../ui.js';
import { hashPin, normalizeAnswer } from '../auth.js';
import { saveSecurity } from '../security.js';
import { S } from '../state.js';

export function securitySheet(opts = {}) {
  const { requirePassword = false, later = false, onDone } = opts;
  sheet(t(later ? 'sec_setup_title' : 'sec_settings'), `
    <p class="muted">${esc(t('sec_setup_sub'))}</p>
    <form id="secForm" style="margin-top:12px">
      ${requirePassword ? field({ label: t('current_password'), name: 'cur', type: 'password', required: true }) : ''}
      ${[1, 2, 3].map((i) => field({ label: `${i}. ${t('sec_q' + i)}`, name: 'a' + i, required: true, attrs: 'autocomplete="off"' })).join('')}
      <small class="muted">${esc(t('sec_hint'))}</small>
      <div id="secErr" class="form-error" hidden></div>
      <div class="btn-row">
        ${later ? `<button type="button" class="btn btn-ghost" data-later>${esc(t('sec_later'))}</button>` : ''}
        <button class="btn btn-gold" type="submit">${ic('check')} ${esc(t('save'))}</button>
      </div>
    </form>`, (body, close) => {
    const err = $('#secErr', body);
    const later_ = $('[data-later]', body);
    if (later_) later_.onclick = close;
    $('#secForm', body).onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(e.target);
      const answers = [f.a1, f.a2, f.a3];
      err.hidden = true;
      if (requirePassword && (await hashPin(f.cur || '', S.user.salt)) !== S.user.hash) {
        err.textContent = t('err_wrong_password'); err.hidden = false; return;
      }
      if (answers.some((a) => normalizeAnswer(a).length < 2)) {
        err.textContent = t('err_sec_fill'); err.hidden = false; return;
      }
      await saveSecurity(answers);
      toast(t('saved'), 'good');
      close();
      onDone && onDone();
    };
  });
}
