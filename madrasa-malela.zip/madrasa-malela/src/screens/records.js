// records.js - Rekodi: angalia (na sahihisha) mahudhurio ya tarehe yoyote iliyopita
import { t, fmtDay } from '../i18n/index.js';
import { $, $$, esc, ic, emptyState, pageHead } from '../ui.js';
import { dateStr } from '../db/index.js';
import { isWeekend, sessionsForDate, normalizeSession, dayRoster, dayStats, markAttendance, unmarkAttendance } from '../data.js';
import { catTabs, onTabs, onCatTabs } from './_shared.js';

export default async function records(view, { params }) {
  let date = params.get('date') || dateStr();
  let weekend = isWeekend(date);
  let session = normalizeSession(date, sessionsForDate(date)[0]);
  let category = 'all';

  function rosterRow(s) {
    return `<div class="roster-row" data-id="${s.id}">
      <div class="row-icon ${s.status === 'present' ? 'c-green' : s.status === 'absent' ? 'c-red' : ''}">${ic(s.category === 'mtoto' ? 'child' : 'user')}</div>
      <div class="row-main"><b>${esc(s.name)}</b><small>${esc(t('cat_' + s.category))}</small></div>
      <div class="att-btns">
        <button class="att-btn present ${s.status === 'present' ? 'sel' : ''}" data-mark="present">${ic('check')} ${esc(t('present'))}</button>
        <button class="att-btn absent ${s.status === 'absent' ? 'sel' : ''}" data-mark="absent">${ic('xmark')} ${esc(t('absent'))}</button>
      </div>
    </div>`;
  }

  async function toggle(s, status, row) {
    if (s.status === status) { await unmarkAttendance(s.id, date, session); s.status = null; }
    else { await markAttendance(s.id, date, session, status); s.status = status; }
    row.outerHTML = rosterRow(s);
    wireRow(s);
    await updateStats();
  }
  function wireRow(s) {
    const row = view.querySelector(`.roster-row[data-id="${s.id}"]`);
    if (!row) return;
    $$('[data-mark]', row).forEach((btn) => (btn.onclick = () => toggle(s, btn.dataset.mark, row)));
  }
  async function updateStats() {
    const stats = await dayStats(date, session, category);
    $('.totals', view).innerHTML = `<div><small>${esc(t('present'))}</small><b class="c-green">${stats.present}</b></div>
      <div><small>${esc(t('absent'))}</small><b class="c-red">${stats.absent}</b></div>
      <div><small>${esc(t('pending'))}</small><b class="c-amber">${stats.pending}</b></div>`;
  }

  async function draw() {
    weekend = isWeekend(date);
    session = normalizeSession(date, session);
    const roster = await dayRoster(date, session, category);
    const stats = await dayStats(date, session, category);

    view.innerHTML = `
      ${pageHead(t('nav_records'))}
      <div class="fg"><input id="dpick" type="date" value="${esc(date)}" max="${esc(dateStr())}"></div>
      <div class="today-day sm">${ic('calendar-day')} ${esc(fmtDay(date))}</div>
      ${weekend ? `<div class="session-tabs">
        <button class="stab ${session === 'asubuhi' ? 'active' : ''}" data-session="asubuhi">${ic('sun')} ${esc(t('session_asubuhi'))}</button>
        <button class="stab ${session === 'jioni' ? 'active' : ''}" data-session="jioni">${ic('moon')} ${esc(t('session_jioni'))}</button>
      </div>` : ''}
      ${catTabs(category)}
      <div class="totals">
        <div><small>${esc(t('present'))}</small><b class="c-green">${stats.present}</b></div>
        <div><small>${esc(t('absent'))}</small><b class="c-red">${stats.absent}</b></div>
        <div><small>${esc(t('pending'))}</small><b class="c-amber">${stats.pending}</b></div>
      </div>
      <div id="roster">${roster.length ? roster.map(rosterRow).join('') : emptyState('user-graduate', t('no_students'), t('no_students_sub'))}</div>`;

    $('#dpick', view).onchange = (e) => { date = e.target.value || dateStr(); draw(); };
    onCatTabs(view, (k) => { category = k; draw(); });
    $$('[data-session]', view).forEach((b) => (b.onclick = () => { session = b.dataset.session; draw(); }));
    roster.forEach((s) => wireRow(s));
  }

  await draw();
}
