// today.js - Leo: weka mahudhurio ya siku ya sasa kwa mguso mmoja
import { t, fmtDay } from '../i18n/index.js';
import { $, $$, esc, ic, emptyState, debounce } from '../ui.js';
import { dateStr } from '../db/index.js';
import { isWeekend, sessionsForDate, normalizeSession, dayRoster, dayStats, markAttendance, unmarkAttendance } from '../data.js';
import { catTabs, onTabs, onCatTabs } from './_shared.js';

export default async function today(view) {
  const date = dateStr();
  const weekend = isWeekend(date);
  let session = normalizeSession(date, sessionsForDate(date)[0]);
  let category = 'mtoto';
  let q = '';

  function rosterRow(s) {
    return `<div class="roster-row" data-id="${s.id}">
      <div class="row-icon ${s.status === 'present' ? 'c-green' : s.status === 'absent' ? 'c-red' : ''}">${ic(s.category === 'mtoto' ? 'child' : 'user')}</div>
      <div class="row-main"><b>${esc(s.name)}</b><small>${esc(t('cat_' + s.category))}</small></div>
      <div class="att-btns">
        <button class="att-btn present ${s.status === 'present' ? 'sel' : ''}" data-mark="present">${ic('check')} ${esc(t('present'))}</button>
        <button class="att-btn absent ${s.status === 'absent' ? 'sel' : ''}" data-mark="absent">${ic('xmark')} ${esc(t('absent'))}</button>
      </div>
    </div>`;
  }

  async function toggle(s, status, row) {
    if (s.status === status) { await unmarkAttendance(s.id, date, session); s.status = null; }
    else { await markAttendance(s.id, date, session, status); s.status = status; }
    row.outerHTML = rosterRow(s);
    wireRow(s);
    await updateStats();
  }

  function wireRow(s) {
    const row = view.querySelector(`.roster-row[data-id="${s.id}"]`);
    if (!row) return;
    $$('[data-mark]', row).forEach((btn) => (btn.onclick = () => toggle(s, btn.dataset.mark, row)));
  }

  async function updateStats() {
    const stats = await dayStats(date, session, category);
    $('.totals', view).innerHTML = `<div><small>${esc(t('present'))}</small><b class="c-green">${stats.present}</b></div>
      <div><small>${esc(t('absent'))}</small><b class="c-red">${stats.absent}</b></div>
      <div><small>${esc(t('pending'))}</small><b class="c-amber">${stats.pending}</b></div>`;
  }

  async function draw() {
    const roster = await dayRoster(date, session, category);
    const stats = await dayStats(date, session, category);
    const rows = roster.filter((s) => !q || s.name.toLowerCase().includes(q.toLowerCase()));

    view.innerHTML = `
      <div class="today-head">
        <div class="today-day">${ic('calendar-day')} ${esc(fmtDay(date))}</div>
        ${weekend ? `<div class="session-tabs">
          <button class="stab ${session === 'asubuhi' ? 'active' : ''}" data-session="asubuhi">${ic('sun')} ${esc(t('session_asubuhi'))}</button>
          <button class="stab ${session === 'jioni' ? 'active' : ''}" data-session="jioni">${ic('moon')} ${esc(t('session_jioni'))}</button>
        </div>` : `<div class="today-note">${ic('circle-info')} ${esc(t('session_single_note'))}</div>`}
      </div>

      ${catTabs(category)}
      <div class="search-bar">${ic('magnifying-glass')}<input id="q" type="search" placeholder="${esc(t('search'))}" value="${esc(q)}"></div>

      <div class="totals">
        <div><small>${esc(t('present'))}</small><b class="c-green">${stats.present}</b></div>
        <div><small>${esc(t('absent'))}</small><b class="c-red">${stats.absent}</b></div>
        <div><small>${esc(t('pending'))}</small><b class="c-amber">${stats.pending}</b></div>
      </div>

      <div id="roster">${rows.length ? rows.map(rosterRow).join('') : emptyState('user-graduate', t('no_students'), t('no_students_sub'))}</div>`;

    onCatTabs(view, (k) => { category = k; draw(); });
    $$('[data-session]', view).forEach((b) => (b.onclick = () => { session = b.dataset.session; draw(); }));
    $('#q', view).oninput = debounce((e) => { q = e.target.value; draw(); }, 200);
    rows.forEach((s) => wireRow(s));
  }

  await draw();
}
