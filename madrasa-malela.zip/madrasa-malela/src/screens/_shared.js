// _shared.js - vipande vinavyotumika kwenye skrini kadhaa
import { t } from '../i18n/index.js';
import { tabs, esc, $$ } from '../ui.js';
import { dateStr, addDays } from '../db/index.js';

export function rangeFor(key) {
  const today = dateStr();
  const d = new Date();
  switch (key) {
    case 'week': return [dateStr(addDays(d, -6)), today];
    case 'month': return [`${today.slice(0, 7)}-01`, today];
    case 'term': return [dateStr(addDays(d, -89)), today];
    case 'year': return [`${today.slice(0, 4)}-01-01`, today];
    default: return ['0000-01-01', '9999-12-31'];
  }
}

export const rangeTabs = (active, keys = ['week', 'month', 'term', 'all']) =>
  tabs(keys.map((k) => ({ key: k, label: t('range_' + k) })), active);

// tabs za category zinatumia data-cat (si data-tab) ili zisigongane na 'all' ya rangeTabs
export const catTabs = (active) => {
  const items = [{ key: 'all', label: t('cat_all') }, { key: 'mtoto', label: t('cat_mtoto') }, { key: 'mzima', label: t('cat_mzima') }];
  return `<div class="tabs">${items.map((i) => `<button class="tab ${i.key === active ? 'active' : ''}" data-cat="${i.key}">${esc(i.label)}</button>`).join('')}</div>`;
};

export function onTabs(view, cb) {
  $$('[data-tab]', view).forEach((b) => (b.onclick = () => cb(b.dataset.tab)));
}
export function onCatTabs(view, cb) {
  $$('[data-cat]', view).forEach((b) => (b.onclick = () => cb(b.dataset.cat)));
}

export const rateClass = (rate) => (rate === null ? '' : rate >= 80 ? 'c-green' : rate >= 50 ? 'c-amber' : 'c-red');
export const ratePillClass = (rate) => (rate === null ? '' : rate >= 80 ? 'lvl-good' : rate >= 50 ? 'lvl-warn' : 'lvl-danger');
