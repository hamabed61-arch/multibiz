// settings.js - mipangilio: lugha, maswali ya usalama, nenosiri, backup, reset
import { t, LANGS, getLang } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, formData, confirmBox, pageHead } from '../ui.js';
import { setSetting, exportAll, importAll, wipeAll, dateStr } from '../db/index.js';
import { hashPin, newSalt } from '../auth.js';
import { S, bus } from '../state.js';
import { rerender } from '../app.js';
import { shareFile } from '../share.js';
import { securitySheet } from './security-setup.js';

export default async function settings(view) {
  view.innerHTML = `
    ${pageHead(t('nav_settings'))}

    <div class="card"><div class="card-title">${ic('language')} ${esc(t('language'))}</div>
      <div class="lang-list row-list">${LANGS.map((l) => `<button class="lang-btn ${getLang() === l.code ? 'sel' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}</div></div>

    <div class="card"><div class="card-title">${ic('shield-halved')} ${esc(t('sec_settings'))}</div>
      <p class="${S.user.sec ? 'form-ok' : 'form-error'}">${ic(S.user.sec ? 'circle-check' : 'triangle-exclamation')} <span>${esc(t(S.user.sec ? 'sec_status_on' : 'sec_status_off'))}</span></p>
      <button class="btn btn-ghost block" id="secBtn">${ic('key')} ${esc(t('sec_change'))}</button></div>

    <div class="card"><div class="card-title">${ic('user-shield')} ${esc(t('account'))}</div>
      <form id="pwForm">
        ${field({ label: t('current_password'), name: 'cur', type: 'password', required: true })}
        ${field({ label: t('new_password'), name: 'nw', type: 'password', required: true })}
        ${field({ label: t('password_confirm'), name: 'nw2', type: 'password', required: true })}
        <button class="btn btn-ghost block" type="submit">${ic('key')} ${esc(t('change_password'))}</button></form></div>

    <div class="card"><div class="card-title">${ic('database')} ${esc(t('backup'))}</div>
      <p class="muted">${esc(t('backup_sub'))}</p>
      <div class="btn-row wrap"><button class="btn btn-gold" id="bkExport">${ic('file-export')} ${esc(t('backup_export'))}</button>
        <button class="btn btn-ghost" id="bkImport">${ic('file-import')} ${esc(t('backup_restore'))}</button></div>
      <input type="file" id="bkFile" accept=".json,application/json" hidden></div>

    <div class="card"><button class="btn btn-danger block" id="resetAll">${ic('triangle-exclamation')} ${esc(t('reset_app'))}</button>
      <p class="muted center-text">Madrasa Malela 1.0 • ${esc(t('app_offline'))}</p></div>`;

  $$('[data-lang]', view).forEach((b) => (b.onclick = async () => {
    const { setLang } = await import('../i18n/index.js');
    setLang(b.dataset.lang);
    await setSetting('lang', b.dataset.lang);
    S.user.lang = b.dataset.lang;
    rerender();
  }));

  $('#secBtn', view).onclick = () => securitySheet({ requirePassword: true, onDone: rerender });

  $('#pwForm', view).onsubmit = async (e) => {
    e.preventDefault();
    const f = formData(e.target);
    if ((await hashPin(f.cur, S.user.salt)) !== S.user.hash) return toast(t('err_wrong_password'), 'danger');
    if (f.nw.length < 4) return toast(t('err_pin_short'), 'danger');
    if (f.nw !== f.nw2) return toast(t('err_pin_match'), 'danger');
    const salt = newSalt();
    const hash = await hashPin(f.nw, salt);
    await setSetting('pin_salt', salt);
    await setSetting('pin_hash', hash);
    S.user.salt = salt; S.user.hash = hash;
    e.target.reset();
    toast(t('saved'), 'good');
  };

  $('#bkExport', view).onclick = async () => {
    try {
      const data = await exportAll();
      await shareFile(`madrasa-malela-backup-${dateStr()}.json`, JSON.stringify(data));
      toast(t('backup_done'), 'good');
    } catch (err) { toast(String(err.message || err), 'danger'); }
  };
  $('#bkImport', view).onclick = () => $('#bkFile', view).click();
  $('#bkFile', view).onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!(await confirmBox(t('restore_confirm')))) return;
      await importAll(data);
      toast(t('restore_done'), 'good');
      setTimeout(() => location.reload(), 900);
    } catch (err) { toast(t('err_backup_file'), 'danger'); }
  };

  $('#resetAll', view).onclick = async () => {
    if (await confirmBox(t('reset_warning'), { okText: t('reset_app') })) { await wipeAll(); location.reload(); }
  };
  void bus;
}
