// i18n/index.js - lugha tatu: Kiswahili (sw), English (en), العربية (ar, RTL)
import sw from './sw.js';
import en from './en.js';
import ar from './ar.js';

const DICTS = { sw, en, ar };
export const LANGS = [
  { code: 'sw', name: 'Kiswahili', dir: 'ltr', locale: 'sw-TZ-u-nu-latn' },
  { code: 'en', name: 'English', dir: 'ltr', locale: 'en-GB-u-nu-latn' },
  { code: 'ar', name: 'العربية', dir: 'rtl', locale: 'ar-u-nu-latn' }
];

let lang = 'sw';
export const getLang = () => lang;
export const isRtl = () => lang === 'ar';
const info = () => LANGS.find((l) => l.code === lang) || LANGS[0];

export function setLang(code) {
  lang = DICTS[code] ? code : 'sw';
  const html = document.documentElement;
  html.lang = lang;
  html.dir = info().dir;
  try { localStorage.setItem('mm_lang', lang); } catch (e) { /* ignore */ }
}

export function initialLang() {
  try { return localStorage.getItem('mm_lang') || 'sw'; } catch (e) { return 'sw'; }
}

export function t(key, params) {
  let s = DICTS[lang][key];
  if (s === undefined) s = DICTS.en[key];
  if (s === undefined) return key;
  if (params) for (const k of Object.keys(params)) s = s.split('{' + k + '}').join(params[k]);
  return s;
}

export function num(n, digits = 0) {
  const v = Number(n) || 0;
  return new Intl.NumberFormat(info().locale, { maximumFractionDigits: digits }).format(v);
}

export function fmtDate(str, withTime = false) {
  if (!str) return '';
  const d = new Date(String(str).length <= 10 ? str + 'T00:00:00' : String(str).replace(' ', 'T'));
  if (isNaN(d)) return str;
  const opts = withTime
    ? { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }
    : { day: '2-digit', month: 'short', year: 'numeric' };
  return new Intl.DateTimeFormat(info().locale, opts).format(d);
}

export function fmtDay(str) {
  const d = new Date(String(str).length <= 10 ? str + 'T00:00:00' : String(str).replace(' ', 'T'));
  return new Intl.DateTimeFormat(info().locale, { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' }).format(d);
}

export function fmtDayShort(str) {
  const d = new Date(String(str).length <= 10 ? str + 'T00:00:00' : String(str).replace(' ', 'T'));
  return new Intl.DateTimeFormat(info().locale, { weekday: 'short', day: '2-digit', month: 'short' }).format(d);
}
