export default {
  // general
  yes: 'نعم', confirm: 'تأكيد', cancel: 'إلغاء', save: 'حفظ', saved: 'تم الحفظ', delete: 'حذف', edit: 'تعديل',
  back: 'رجوع', next: 'التالي', finish: 'إنهاء', search: 'بحث…', phone: 'الهاتف', category: 'الفئة', history: 'السجل',
  full_name: 'الاسم الكامل', present: 'حاضر', absent: 'غائب', pending: 'لم يُسجَّل',

  // app
  app_tagline: 'نظام حضور مدرسة مليلة — بدون إنترنت، على هاتفك.', app_sub: 'الحضور', app_offline: 'يعمل بدون إنترنت',
  choose_language: 'اختر لغتك', language: 'اللغة', about_version: 'الإصدار {v}',

  // onboarding
  ob_account_title: 'أنشئ حسابك', ob_account_sub: 'تبقى بياناتك على هذا الهاتف. لا حاجة للإنترنت.',
  password: 'كلمة المرور', password_confirm: 'تأكيد كلمة المرور', password_hint: '4 أحرف على الأقل. احفظها جيداً — لا يمكن استرجاعها.',
  err_name: 'يرجى إدخال الاسم.', err_pin_short: 'يجب أن تتكوّن كلمة المرور من 4 أحرف على الأقل.', err_pin_match: 'كلمتا المرور غير متطابقتين.',

  // أسئلة الأمان
  sec_title: 'استعادة كلمة المرور', sec_sub: 'أجب عن 3 أسئلة أمان. ستستخدمها إذا نسيت كلمة المرور.',
  sec_q1: 'ما هو اسمك المستعار (لقبك)؟', sec_q2: 'ما هو الاسم الثالث لوالدتك؟', sec_q3: 'أين وُلدت؟',
  sec_hint: 'لا فرق بين الأحرف الكبيرة والصغيرة. تذكّر إجاباتك كما كتبتها.', err_sec_fill: 'يرجى الإجابة عن الأسئلة الثلاثة.',
  recover_title: 'إعادة تعيين كلمة المرور', recover_sub: 'أجب عن أسئلة الأمان لإعادة تعيين كلمة المرور.', recover_verify: 'تحقق من الإجابات',
  err_sec_wrong: 'إجابة واحدة أو أكثر غير صحيحة. المحاولات المتبقية: {n}.', err_sec_locked: 'محاولات خاطئة كثيرة. حاول مجدداً بعد {m} دقيقة.',
  recover_none: 'لم تضبط أسئلة الأمان على هذا الهاتف. يمكنك استعادة نسخة احتياطية أو مسح كل البيانات والبدء من جديد.',
  recover_new_title: 'اختر كلمة مرور جديدة', recover_done: 'تم تغيير كلمة المرور. أهلاً بعودتك!', recover_erase: 'لا تستطيع الإجابة؟ امسح كل البيانات',
  back_to_login: 'العودة لتسجيل الدخول', sec_setup_title: 'فعّل استعادة كلمة المرور', sec_setup_sub: 'أضف 3 أسئلة أمان لتتمكن من إعادة تعيين كلمة المرور إذا نسيتها.',
  sec_later: 'لاحقاً', sec_settings: 'أسئلة الأمان', sec_status_on: 'أسئلة الأمان مفعّلة.', sec_status_off: 'غير مفعّلة — لن تتمكن من استعادة كلمة مرور منسية.',
  sec_change: 'ضبط / تغيير الأسئلة',

  // login
  hello_user: 'مرحباً، {name}', enter_password: 'أدخل كلمة المرور لفتح التطبيق', unlock: 'فتح',
  forgot_password: 'نسيت كلمة المرور؟', err_wrong_password: 'كلمة المرور غير صحيحة.', reset_app: 'مسح كل البيانات وإعادة الضبط',
  reset_warning: 'سيؤدي هذا إلى مسح جميع البيانات على هذا الهاتف (الطلاب والحضور…). يمكنك استعادتها لاحقاً من نسخة احتياطية إن وُجدت. هل تريد المتابعة؟',

  // navigation
  nav_main: 'الرئيسية', nav_manage: 'الإدارة', nav_today: 'اليوم', nav_students: 'الطلاب', nav_records: 'السجلات',
  nav_reports: 'التقارير', nav_settings: 'الإعدادات', nav_about: 'حول التطبيق', lock_app: 'قفل التطبيق', account_owner: 'المعلّم المسؤول',

  // session/day
  session_siku: 'حصة اليوم', session_asubuhi: 'صباحاً', session_jioni: 'مساءً',
  session_single_note: 'يوم من أيام الأسبوع: حصة حضور واحدة فقط.',

  // students
  cat_all: 'الجميع', cat_mtoto: 'الأطفال', cat_mzima: 'البالغون',
  no_students: 'لا يوجد طلاب', no_students_sub: 'اضغط + لإضافة أول طالب.',
  add_student: 'إضافة طالب', delete_confirm: 'حذف {name}؟ سيتم حذف سجلات حضوره أيضاً.',

  // reports
  n_sessions: '{n} حصة', rep_overview: 'نظرة عامة', rep_sessions: 'الحصص', rep_rate: 'متوسط الحضور',
  rep_daily: 'الاتجاه اليومي', rep_by_student: 'حسب الطالب', rep_no_data: 'لا بيانات',
  range_week: '7 أيام', range_month: 'هذا الشهر', range_term: '3 أشهر', range_year: 'هذه السنة', range_all: 'الكل',

  // settings
  account: 'الحساب والأمان', current_password: 'كلمة المرور الحالية', new_password: 'كلمة المرور الجديدة', change_password: 'تغيير كلمة المرور',
  backup: 'النسخ الاحتياطي والاستعادة', backup_sub: 'احفظ نسخة من جميع بياناتك في مكان آمن (واتساب، درايف، البريد).',
  backup_export: 'تصدير نسخة احتياطية', backup_restore: 'استعادة من ملف', backup_done: 'النسخة الاحتياطية جاهزة',
  restore_confirm: 'استعادة هذه النسخة؟ سيتم استبدال جميع البيانات الموجودة على هذا الهاتف.', restore_done: 'تمت استعادة النسخة', err_backup_file: 'ملف النسخة الاحتياطية غير صالح.'
};
