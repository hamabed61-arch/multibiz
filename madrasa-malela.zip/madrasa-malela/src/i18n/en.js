export default {
  // general
  yes: 'Yes', confirm: 'Confirm', cancel: 'Cancel', save: 'Save', saved: 'Saved', delete: 'Delete', edit: 'Edit',
  back: 'Back', next: 'Next', finish: 'Finish', search: 'Search…', phone: 'Phone', category: 'Category', history: 'History',
  full_name: 'Full name', present: 'Present', absent: 'Absent', pending: 'Pending',

  // app
  app_tagline: 'Madrasa Malela attendance system — offline, on your phone.', app_sub: 'Attendance', app_offline: 'Works offline',
  choose_language: 'Choose your language', language: 'Language', about_version: 'Version {v}',

  // onboarding
  ob_account_title: 'Create your account', ob_account_sub: 'Your data stays on this phone. No internet needed.',
  password: 'Password', password_confirm: 'Confirm password', password_hint: 'At least 4 characters. Remember it — it cannot be recovered.',
  err_name: 'Please enter a name.', err_pin_short: 'Password must be at least 4 characters.', err_pin_match: 'Passwords do not match.',

  // security questions
  sec_title: 'Password recovery', sec_sub: 'Answer 3 security questions. You will use them if you forget your password.',
  sec_q1: 'What is your nickname?', sec_q2: "What is your mother's third name?", sec_q3: 'Where were you born?',
  sec_hint: 'Answers are not case-sensitive. Remember them exactly as you type them.', err_sec_fill: 'Please answer all three questions.',
  recover_title: 'Reset password', recover_sub: 'Answer your security questions to reset your password.', recover_verify: 'Verify answers',
  err_sec_wrong: 'One or more answers are wrong. {n} attempt(s) left.', err_sec_locked: 'Too many wrong attempts. Try again in {m} minute(s).',
  recover_none: "You haven't set recovery questions on this phone. You can restore a backup or erase all data and start again.",
  recover_new_title: 'Choose a new password', recover_done: 'Password changed. Welcome back!', recover_erase: "Can't answer? Erase all data",
  back_to_login: 'Back to login', sec_setup_title: 'Set up password recovery', sec_setup_sub: 'Add 3 security questions so you can reset your password if you forget it.',
  sec_later: 'Later', sec_settings: 'Recovery questions', sec_status_on: 'Recovery questions are set.', sec_status_off: "Not set — you won't be able to reset a forgotten password.",
  sec_change: 'Set / change questions',

  // login
  hello_user: 'Hello, {name}', enter_password: 'Enter your password to open the app', unlock: 'Unlock',
  forgot_password: 'Forgot password?', err_wrong_password: 'Wrong password.', reset_app: 'Erase all data & reset',
  reset_warning: 'This erases ALL data on this phone (students, attendance…). Restore from a backup afterwards if you have one. Continue?',

  // navigation
  nav_main: 'Main', nav_manage: 'Manage', nav_today: 'Today', nav_students: 'Students', nav_records: 'Records',
  nav_reports: 'Reports', nav_settings: 'Settings', nav_about: 'About', lock_app: 'Lock app', account_owner: 'Head Teacher',

  // session/day
  session_siku: 'Daily session', session_asubuhi: 'Morning', session_jioni: 'Evening',
  session_single_note: 'Weekday: one attendance session only.',

  // students
  cat_all: 'All', cat_mtoto: 'Children', cat_mzima: 'Adults',
  no_students: 'No students', no_students_sub: 'Tap + to add the first student.',
  add_student: 'Add student', delete_confirm: 'Delete {name}? Their attendance records will be deleted too.',

  // reports
  n_sessions: '{n} sessions', rep_overview: 'Overview', rep_sessions: 'Sessions', rep_rate: 'Average attendance',
  rep_daily: 'Daily trend', rep_by_student: 'By student', rep_no_data: 'No data',
  range_week: '7 days', range_month: 'This month', range_term: '3 months', range_year: 'This year', range_all: 'All',

  // settings
  account: 'Account & security', current_password: 'Current password', new_password: 'New password', change_password: 'Change password',
  backup: 'Backup & restore', backup_sub: 'Save a copy of all your data. Keep it safe (WhatsApp, Drive, email).',
  backup_export: 'Export backup', backup_restore: 'Restore from file', backup_done: 'Backup ready',
  restore_confirm: 'Restore this backup? It REPLACES all data currently on this phone.', restore_done: 'Backup restored', err_backup_file: 'Invalid backup file.'
};
