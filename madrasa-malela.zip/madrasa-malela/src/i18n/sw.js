export default {
  // general
  yes: 'Ndiyo', confirm: 'Thibitisha', cancel: 'Ghairi', save: 'Hifadhi', saved: 'Imehifadhiwa', delete: 'Futa', edit: 'Hariri',
  back: 'Rudi', next: 'Endelea', finish: 'Maliza', search: 'Tafuta…', phone: 'Simu', category: 'Aina', history: 'Historia',
  full_name: 'Jina kamili', present: 'Yupo', absent: 'Hayupo', pending: 'Bado',

  // app
  app_tagline: 'Mfumo wa mahudhurio ya Madrasa Malela — bila internet, ndani ya simu.', app_sub: 'Mahudhurio', app_offline: 'Inafanya kazi bila internet',
  choose_language: 'Chagua lugha yako', language: 'Lugha', about_version: 'Toleo {v}',

  // onboarding
  ob_account_title: 'Tengeneza akaunti yako', ob_account_sub: 'Data yako inabaki kwenye simu hii. Huhitaji internet.',
  password: 'Nenosiri', password_confirm: 'Thibitisha nenosiri', password_hint: 'Angalau herufi 4. Ulikumbuke — haliwezi kurudishwa.',
  err_name: 'Tafadhali andika jina.', err_pin_short: 'Nenosiri liwe na angalau herufi 4.', err_pin_match: 'Manenosiri hayafanani.',

  // maswali ya usalama
  sec_title: 'Kurejesha nenosiri', sec_sub: 'Jibu maswali 3 ya usalama. Utayatumia ukisahau nenosiri.',
  sec_q1: 'Jina lako la utani ni lipi?', sec_q2: 'Jina la tatu la mama yako ni lipi?', sec_q3: 'Ulizaliwa wapi (sehemu uliyozaliwa)?',
  sec_hint: 'Herufi kubwa au ndogo hazijalishi. Zikumbuke kama ulivyoandika.', err_sec_fill: 'Tafadhali jibu maswali yote matatu.',
  recover_title: 'Weka nenosiri jipya', recover_sub: 'Jibu maswali yako ya usalama ili kuweka nenosiri jipya.', recover_verify: 'Thibitisha majibu',
  err_sec_wrong: 'Jibu moja au zaidi si sahihi. Umebakiwa na majaribio {n}.', err_sec_locked: 'Umejaribu mara nyingi mno. Jaribu tena baada ya dakika {m}.',
  recover_none: 'Hujaweka maswali ya usalama kwenye simu hii. Unaweza kurejesha backup au kufuta data yote na kuanza upya.',
  recover_new_title: 'Chagua nenosiri jipya', recover_done: 'Nenosiri limebadilishwa. Karibu tena!', recover_erase: 'Huwezi kujibu? Futa data yote',
  back_to_login: 'Rudi kuingia', sec_setup_title: 'Weka njia ya kurejesha nenosiri', sec_setup_sub: 'Weka maswali 3 ya usalama ili uweze kuweka nenosiri jipya ukilisahau.',
  sec_later: 'Baadaye', sec_settings: 'Maswali ya usalama', sec_status_on: 'Maswali ya usalama yamewekwa.', sec_status_off: 'Hayajawekwa — hutaweza kurejesha nenosiri ukilisahau.',
  sec_change: 'Weka / badilisha maswali',

  // login
  hello_user: 'Habari, {name}', enter_password: 'Weka nenosiri lako kufungua app', unlock: 'Fungua',
  forgot_password: 'Umesahau nenosiri?', err_wrong_password: 'Nenosiri si sahihi.', reset_app: 'Futa data yote na uanze upya',
  reset_warning: 'Hii itafuta data ZOTE za simu hii (wanafunzi, mahudhurio…). Kama una backup, utaweza kuirudisha baadaye. Endelea?',

  // navigation
  nav_main: 'Kuu', nav_manage: 'Usimamizi', nav_today: 'Leo', nav_students: 'Wanafunzi', nav_records: 'Rekodi',
  nav_reports: 'Ripoti', nav_settings: 'Mipangilio', nav_about: 'Kuhusu', lock_app: 'Funga app', account_owner: 'Mwalimu Mkuu',

  // session/siku
  session_siku: 'Kipindi cha siku', session_asubuhi: 'Asubuhi', session_jioni: 'Jioni',
  session_single_note: 'Siku ya wiki: kipindi kimoja tu cha mahudhurio.',

  // wanafunzi
  cat_all: 'Wote', cat_mtoto: 'Watoto', cat_mzima: 'Watu wazima',
  no_students: 'Hakuna wanafunzi', no_students_sub: 'Bonyeza + kuongeza mwanafunzi wa kwanza.',
  add_student: 'Ongeza mwanafunzi', delete_confirm: 'Una uhakika unataka kumfuta {name}? Rekodi zake za mahudhurio pia zitafutwa.',

  // ripoti
  n_sessions: 'vipindi {n}', rep_overview: 'Muhtasari', rep_sessions: 'Vipindi', rep_rate: 'Wastani wa mahudhurio',
  rep_daily: 'Mwenendo wa kila siku', rep_by_student: 'Kwa kila mwanafunzi', rep_no_data: 'Bado',
  range_week: 'Wiki 7', range_month: 'Mwezi huu', range_term: 'Miezi 3', range_year: 'Mwaka huu', range_all: 'Zote',

  // settings
  account: 'Akaunti na usalama', current_password: 'Nenosiri la sasa', new_password: 'Nenosiri jipya', change_password: 'Badilisha nenosiri',
  backup: 'Backup na kurejesha', backup_sub: 'Hifadhi nakala ya data yako yote. Iweke salama (WhatsApp, Drive, barua pepe).',
  backup_export: 'Toa backup', backup_restore: 'Rejesha kutoka faili', backup_done: 'Backup iko tayari',
  restore_confirm: 'Rejesha backup hii? ITAFUTA na kubadilisha data yote iliyopo kwenye simu hii.', restore_done: 'Backup imerejeshwa', err_backup_file: 'Faili ya backup si sahihi.'
};
