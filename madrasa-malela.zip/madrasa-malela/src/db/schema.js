// schema.js - muundo wa database (SQLite). Ongeza migration mpya mwishoni mwa orodha.

export const TABLES = ['settings', 'students', 'attendance'];

export const MIGRATIONS = [
  // ── v1 ──
  `
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);

  CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, category TEXT NOT NULL, phone TEXT,
    active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_students_cat ON students (category, active);

  CREATE TABLE IF NOT EXISTS attendance (
    id TEXT PRIMARY KEY, student_id TEXT NOT NULL, attendance_date TEXT NOT NULL,
    session TEXT NOT NULL, status TEXT NOT NULL,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_att_uniq ON attendance (student_id, attendance_date, session);
  CREATE INDEX IF NOT EXISTS idx_att_date ON attendance (attendance_date, session);
  `
];
