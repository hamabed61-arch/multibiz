// driver-native.js - SQLite halisi ndani ya simu (@capacitor-community/sqlite)
import { CapacitorSQLite, SQLiteConnection } from '@capacitor-community/sqlite';

const DB_NAME = 'madrasamalela';

function clean(params) {
  return (params || []).map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
}

export async function create() {
  const sqlite = new SQLiteConnection(CapacitorSQLite);
  let db = null;
  let inTx = false;

  return {
    async open() {
      const consistency = await sqlite.checkConnectionsConsistency();
      const isConn = (await sqlite.isConnection(DB_NAME, false)).result;
      if (consistency.result && isConn) {
        db = await sqlite.retrieveConnection(DB_NAME, false);
      } else {
        db = await sqlite.createConnection(DB_NAME, false, 'no-encryption', 1, false);
      }
      await db.open();
    },
    async exec(sql) {
      await db.execute(sql, !inTx);
    },
    async run(sql, params) {
      const r = await db.run(sql, clean(params), !inTx);
      return { changes: r.changes?.changes ?? 0, lastId: r.changes?.lastId };
    },
    async all(sql, params) {
      const r = await db.query(sql, clean(params));
      return (r.values || []).filter((row) => !row.ios_columns);
    },
    async begin() { await db.beginTransaction(); inTx = true; },
    async commit() { await db.commitTransaction(); inTx = false; },
    async rollback() { try { await db.rollbackTransaction(); } finally { inTx = false; } }
  };
}
