// app.js - ganda la app (sidebar, topbar) na router
import { t } from './i18n/index.js';
import { $, $$, esc, ic, brandLogo } from './ui.js';
import { S } from './state.js';

import today from './screens/today.js';
import students from './screens/students.js';
import records from './screens/records.js';
import reports from './screens/reports.js';
import settings from './screens/settings.js';
import about from './screens/about.js';

const ROUTES = {
  '/leo': { r: today, title: 'nav_today' },
  '/wanafunzi': { r: students, title: 'nav_students' },
  '/rekodi': { r: records, title: 'nav_records' },
  '/ripoti': { r: reports, title: 'nav_reports' },
  '/settings': { r: settings, title: 'nav_settings' },
  '/about': { r: about, title: 'nav_about' }
};

const NAV = [
  { label: 'nav_main', items: [
    { path: '/leo', icon: 'calendar-check', text: 'nav_today' },
    { path: '/rekodi', icon: 'clock-rotate-left', text: 'nav_records' },
    { path: '/ripoti', icon: 'chart-line', text: 'nav_reports' }
  ] },
  { label: 'nav_manage', items: [
    { path: '/wanafunzi', icon: 'users', text: 'nav_students' }
  ] }
];

let wired = false;

export function mountShell(root, onLock) {
  root.innerHTML = `
    <div class="sidebar-overlay" id="overlay"></div>
    <aside class="sidebar" id="sidebar"></aside>
    <header class="topbar" id="topbar">
      <button class="hamburger" id="hamburger" aria-label="menu"><span></span><span></span><span></span></button>
      <div class="topbar-breadcrumb"><span class="bc-page" id="pageName"></span></div>
      <div class="topbar-right"><div class="topbar-chip"><span class="chip-dot"></span><span>${esc(S.user.name)}</span></div></div>
    </header>
    <main class="main"><div class="content-wrap" id="view"></div></main>`;
  $('#hamburger').onclick = () => toggleSidebar();
  $('#overlay').onclick = () => toggleSidebar(false);
  if (!wired) {
    wired = true;
    window.addEventListener('hashchange', renderRoute);
  }
  S.onLock = onLock;
  renderSidebar();
  renderRoute();
}

function toggleSidebar(force) {
  const open = force ?? !$('#sidebar').classList.contains('active');
  $('#sidebar').classList.toggle('active', open);
  $('#overlay').classList.toggle('show', open);
  $('#hamburger').classList.toggle('open', open);
}

function currentPath() {
  const h = location.hash.replace(/^#/, '') || '/leo';
  return h.split('?')[0];
}

function renderSidebar() {
  const cur = currentPath();
  const initials = (S.user.name || '?').trim().charAt(0).toUpperCase();
  $('#sidebar').innerHTML = `
    <div class="sidebar-brand">
      ${brandLogo()}
      <div class="brand-text"><div class="brand-name">Madrasa <span>Malela</span></div><div class="brand-sub">${esc(t('app_sub'))}</div></div>
    </div>
    <div class="sidebar-user">
      <div class="user-avatar">${esc(initials)}</div>
      <div class="user-details"><div class="user-name">${esc(S.user.name)}</div><div class="user-role">${esc(t('account_owner'))}</div></div>
      <div class="user-status"></div>
    </div>
    <nav class="sidebar-nav">
      ${NAV.map((g) => `
        <div class="nav-label">${esc(t(g.label))}</div>
        ${g.items.map((i) => `<a class="nav-item ${cur === i.path ? 'active' : ''}" href="#${i.path}">
          <span class="nav-icon">${ic(i.icon)}</span>${esc(t(i.text))}</a>`).join('')}`).join('')}
    </nav>
    <div class="sidebar-footer">
      <a class="nav-item ${cur === '/settings' ? 'active' : ''}" href="#/settings"><span class="nav-icon">${ic('gear')}</span>${esc(t('nav_settings'))}</a>
      <a class="nav-item ${cur === '/about' ? 'active' : ''}" href="#/about"><span class="nav-icon">${ic('circle-info')}</span>${esc(t('nav_about'))}</a>
      <button class="btn-logout" id="lockBtn">${ic('lock')} ${esc(t('lock_app'))}</button>
    </div>`;
  $$('.nav-item', $('#sidebar')).forEach((a) => a.addEventListener('click', () => toggleSidebar(false)));
  $('#lockBtn').onclick = () => { S.unlocked = false; S.onLock && S.onLock(); };
}

export async function renderRoute() {
  if (!S.unlocked || !$('#view')) return;
  const path = currentPath();
  const route = ROUTES[path] || ROUTES['/leo'];
  const params = new URLSearchParams((location.hash.split('?')[1]) || '');
  $('#pageName').textContent = t(route.title);
  renderSidebar();
  const view = $('#view');
  view.innerHTML = '';
  view.classList.remove('slide'); void view.offsetWidth; view.classList.add('slide');
  window.scrollTo(0, 0);
  try {
    await route.r(view, { params, path });
  } catch (e) {
    console.error(e);
    view.innerHTML = `<div class="form-error">${esc(String(e.message || e))}</div>`;
  }
}

export async function rerender() { renderSidebar(); await renderRoute(); }
