// data.js - mantiki ya mahudhurio: wanafunzi, session za siku, kuweka/kusoma mahudhurio, ripoti
import { all, one, val, run, tx, uid, now, dateStr, addDays } from './db/index.js';

const like = (q) => `%${String(q).trim().toLowerCase()}%`;

// ═══════════ SIKU NA SESSION ═══════════
// Wiki (Jumatatu-Ijumaa): session moja "siku". Wikendi (Jumamosi/Jumapili): "asubuhi" na "jioni".
export function isWeekend(dateStr_) {
  const d = new Date(dateStr_ + 'T00:00:00').getDay();
  return d === 0 || d === 6;
}
export const sessionsForDate = (dateStr_) => (isWeekend(dateStr_) ? ['asubuhi', 'jioni'] : ['siku']);
export function normalizeSession(dateStr_, wanted) {
  const opts = sessionsForDate(dateStr_);
  return opts.includes(wanted) ? wanted : opts[0];
}

// ═══════════ WANAFUNZI ═══════════
export async function listStudents(category, q = '', includeInactive = false) {
  const args = [];
  let where = '1=1';
  if (category && category !== 'all') { where += ' AND category = ?'; args.push(category); }
  if (!includeInactive) where += ' AND active = 1';
  if (q) { where += ' AND LOWER(name) LIKE ?'; args.push(like(q)); }
  return all(`SELECT * FROM students WHERE ${where} ORDER BY name COLLATE NOCASE`, args);
}

export const getStudent = (id) => one('SELECT * FROM students WHERE id = ?', [id]);

export async function saveStudent(f, id = null) {
  if (id) {
    await run('UPDATE students SET name=?, category=?, phone=?, updated_at=? WHERE id=?', [f.name, f.category, f.phone || null, now(), id]);
    return id;
  }
  const nid = uid();
  await run('INSERT INTO students (id, name, category, phone, active, created_at, updated_at) VALUES (?,?,?,?,1,?,?)',
    [nid, f.name, f.category, f.phone || null, now(), now()]);
  return nid;
}

export async function deleteStudent(id) {
  await tx(async () => {
    await run('DELETE FROM attendance WHERE student_id = ?', [id]);
    await run('DELETE FROM students WHERE id = ?', [id]);
  });
}

export const countStudents = (category) => val(category && category !== 'all'
  ? 'SELECT COUNT(*) FROM students WHERE active=1 AND category=?'
  : 'SELECT COUNT(*) FROM students WHERE active=1', category && category !== 'all' ? [category] : []);

// ═══════════ KUWEKA MAHUDHURIO (siku moja) ═══════════
export async function markAttendance(studentId, date, session, status) {
  const existing = await one('SELECT id FROM attendance WHERE student_id=? AND attendance_date=? AND session=?', [studentId, date, session]);
  if (existing) {
    await run('UPDATE attendance SET status=?, updated_at=? WHERE id=?', [status, now(), existing.id]);
  } else {
    await run('INSERT INTO attendance (id, student_id, attendance_date, session, status, created_at, updated_at) VALUES (?,?,?,?,?,?,?)',
      [uid(), studentId, date, session, status, now(), now()]);
  }
}

export async function unmarkAttendance(studentId, date, session) {
  await run('DELETE FROM attendance WHERE student_id=? AND attendance_date=? AND session=?', [studentId, date, session]);
}

// Wanafunzi wa kundi fulani + status yao ya siku/session hiyo (null = hajasajiliwa bado)
export async function dayRoster(date, session, category) {
  const students = await listStudents(category);
  const rows = await all('SELECT student_id, status FROM attendance WHERE attendance_date=? AND session=?', [date, session]);
  const byId = Object.fromEntries(rows.map((r) => [r.student_id, r.status]));
  return students.map((s) => ({ ...s, status: byId[s.id] ?? null }));
}

export async function dayStats(date, session, category) {
  const roster = await dayRoster(date, session, category);
  const present = roster.filter((s) => s.status === 'present').length;
  const absent = roster.filter((s) => s.status === 'absent').length;
  return { total: roster.length, present, absent, pending: roster.length - present - absent };
}

// Alama za mwanafunzi mmoja (kadhaa za hivi karibuni)
export async function studentHistory(studentId, limit = 60) {
  return all('SELECT attendance_date, session, status FROM attendance WHERE student_id=? ORDER BY attendance_date DESC, session DESC LIMIT ?', [studentId, limit]);
}

// ═══════════ RIPOTI ═══════════
export async function rangeTotals(from, to, category) {
  const args = [from, to];
  let where = 'a.attendance_date BETWEEN ? AND ?';
  if (category && category !== 'all') { where += ' AND s.category = ?'; args.push(category); }
  const row = await one(
    `SELECT COUNT(*) AS total,
            SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) AS absent
     FROM attendance a JOIN students s ON s.id = a.student_id WHERE ${where}`, args);
  const total = row?.total || 0;
  const present = row?.present || 0;
  const absent = row?.absent || 0;
  return { total, present, absent, rate: total > 0 ? Math.round((present / total) * 100) : null };
}

// Mfululizo wa kila siku: {d, present, absent, rate}
export async function dailySeries(from, to, category) {
  const args = [from, to];
  let where = 'a.attendance_date BETWEEN ? AND ?';
  if (category && category !== 'all') { where += ' AND s.category = ?'; args.push(category); }
  const rows = await all(
    `SELECT a.attendance_date AS d,
            SUM(CASE WHEN a.status='present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN a.status='absent' THEN 1 ELSE 0 END) AS absent
     FROM attendance a JOIN students s ON s.id = a.student_id WHERE ${where} GROUP BY a.attendance_date`, args);
  const map = Object.fromEntries(rows.map((r) => [r.d, r]));
  const out = [];
  for (let d = new Date(from + 'T00:00:00'); dateStr(d) <= to; d = addDays(d, 1)) {
    const r = map[dateStr(d)];
    const present = r?.present || 0, absent = r?.absent || 0, tot = present + absent;
    out.push({ d: dateStr(d), present, absent, rate: tot > 0 ? Math.round((present / tot) * 100) : null });
  }
  return out;
}

// Kila mwanafunzi: idadi ya vipindi alivyosajiliwa, aliokuwepo, na asilimia yake (chini kwenda juu = wanaokosa zaidi kwanza)
export async function studentStats(from, to, category) {
  const students = await listStudents(category);
  const rows = await all(
    `SELECT student_id, status, COUNT(*) AS n FROM attendance WHERE attendance_date BETWEEN ? AND ? GROUP BY student_id, status`, [from, to]);
  const byStudent = {};
  for (const r of rows) { (byStudent[r.student_id] ??= { present: 0, absent: 0 })[r.status] = r.n; }
  return students.map((s) => {
    const c = byStudent[s.id] || { present: 0, absent: 0 };
    const total = c.present + c.absent;
    return { ...s, present: c.present, absent: c.absent, total, rate: total > 0 ? Math.round((c.present / total) * 100) : null };
  }).sort((a, b) => (a.rate ?? 101) - (b.rate ?? 101) || a.name.localeCompare(b.name));
}
