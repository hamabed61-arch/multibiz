// state.js - hali ya app inayoshirikiwa
import { getSetting } from './db/index.js';

export const S = { user: null, unlocked: false, onLock: null };
export const bus = new EventTarget();
export const nav = (path) => { location.hash = '#' + path; };

export async function loadUser() {
  const name = await getSetting('user_name');
  if (!name) return null;
  const secSalt = await getSetting('sec_salt');
  return {
    name,
    phone: await getSetting('user_phone', ''),
    salt: await getSetting('pin_salt'),
    hash: await getSetting('pin_hash'),
    lang: await getSetting('lang', 'sw'),
    sec: secSalt ? { salt: secSalt, hashes: [await getSetting('sec_a1'), await getSetting('sec_a2'), await getSetting('sec_a3')] } : null
  };
}
