// main.js - mwanzo wa app
import { initDb } from './db/index.js';
import { setLang, initialLang } from './i18n/index.js';
import { S, loadUser } from './state.js';
import { startOnboarding } from './screens/onboarding.js';
import { showLogin } from './screens/login.js';
import { mountShell } from './app.js';

import('./fonts.js').catch(() => {});

const root = document.getElementById('app');

async function enter() {
  S.unlocked = true;
  mountShell(root, lock);
}

function lock() {
  S.unlocked = false;
  showLogin(root, enter, restart);
}

async function restart() {
  S.user = null;
  S.unlocked = false;
  startOnboarding(root, enter);
}

async function boot() {
  setLang(initialLang());
  try {
    await initDb();
  } catch (e) {
    root.innerHTML = `<pre class="form-error" style="margin:20px">${String(e.message || e)}</pre>`;
    return;
  }
  S.user = await loadUser();
  if (!S.user) return startOnboarding(root, enter);
  setLang(S.user.lang || initialLang());
  showLogin(root, enter, restart);
}

boot();
