# MultiBiz — usimamizi wa biashara (offline, SQLite)

Mfumo wa mtumiaji mmoja unaofanya kazi **bila internet na bila domain**. Data zote ziko kwenye SQLite ndani ya simu.
Unasimamia biashara moja au nyingi (duka, famasi, kuku, mifugo, kilimo, samaki, saluni, mgahawa, gereji, ushauri, au nyingine).
Lugha: **Kiswahili, English, العربية** (RTL).

## Kupata APK kupitia GitHub (bila kompyuta yenye Android Studio)

1. Tengeneza repository mpya kwenye GitHub, kisha pakia (upload) faili zote za folda hii (pamoja na `.github`).
   *Njia rahisi kwa simu:* pakia `multibiz.zip` (kama ilivyo) na `.github/workflows/android.yml` tu — workflow inatoa zip yenyewe.
2. Nenda **Actions → Build Android APK**. Inaanza yenyewe unapopakia; au bonyeza **Run workflow**.
3. Ikimaliza (dakika ~5–10), fungua run hiyo → **Artifacts → MultiBiz-apk** → pakua `MultiBiz.apk`.
4. Kwenye simu: fungua APK na uruhusu "install unknown apps" ukiombwa.
5. Toleo lenye jina: weka tag `v1.0.0` — APK itawekwa pia kwenye **Releases**.

APK hii ni ya *debug* (inafungwa moja kwa moja). Kwa Play Store utahitaji keystore ya release.

## Logo na poster ya About

Zimeshawekwa kwenye `public/brand/`: `logo.png` (Scanika — sidebar, usajili, login) na `about.jpg` (poster ya ukurasa wa **Kuhusu**).
Ukitaka kuzibadilisha, weka picha zenye majina yale yale. Zikikosekana, app inatumia icon ya kawaida na inaruka poster.

## Mtiririko wa mtumiaji

Lugha → Akaunti (jina, simu, nenosiri) → **Biashara moja au nyingi + aina** → Maelezo (jina, mahali, sarafu) → Modules → Dashibodi.
Modules huchaguliwa kulingana na aina ya biashara na zinaweza kubadilishwa wakati wowote (Settings).

## Alerts na arifa (nyekundu = hatari, dhahabu = tahadhari, kijani = nzuri)

| Rangi | Mifano |
|---|---|
| Nyekundu | Stock imeisha / inakaribia kuisha (biashara zinazonunua na kuuza), dawa imeisha muda, mauzo yameshuka, matumizi yamezidi mauzo, hasara ya mwezi, vifo vingi (kuku/mifugo/samaki), uzalishaji umeshuka |
| Dhahabu | Bidhaa itaisha ndani ya siku 7 kwa kasi ya mauzo, muda wa bidhaa unakaribia kuisha, matumizi yamepanda, madeni ni makubwa |
| Kijani | Mauzo yamepanda, faida nzuri ya mwezi, siku bora ya mauzo, uzalishaji umepanda |

Alerts huhesabiwa app inapofunguliwa na baada ya kila badiliko la data (mauzo, ununuzi, matumizi, stock…).
Kila alert mpya hutumwa kama notification ya Android (Settings → Notifications kuzima/kujaribu).
Kwenye alert ya stock kuna kitufe cha **Nunua stock** kinachokupeleka moja kwa moja kwenye fomu ya ununuzi.

## Kujaribu kwenye kompyuta (hiari)

```
python3 dev/server.py        # kisha fungua http://localhost:5173
```
Hii inatumia SQLite ya Python kwa majaribio ya UI tu (`dev/dev.sqlite`). Kwenye simu, app inatumia `@capacitor-community/sqlite`.

## Muundo

```
index.html, vite.config.js, capacitor.config.json, package.json
.github/workflows/android.yml   ← ujenzi wa APK
src/
  main.js, app.js, state.js     ← kuanza, ganda (sidebar/topbar), hali
  db/                           ← schema.js (migrations), index.js, driver-native.js (simu), driver-dev.js (kompyuta)
  data.js                       ← mantiki ya biashara (mauzo, stock, madeni, ripoti)
  alerts.js, notify.js          ← injini ya alerts + notifications
  templates.js                  ← aina za biashara na modules zao
  i18n/ (sw, en, ar)            ← tafsiri
  screens/                      ← skrini zote
  styles.css, icons.css         ← muonekano (unafuata FinTrack) na icons za ndani
tools/  gen-icons.py, check-i18n.py
```

- **Kuongeza aina ya biashara:** `src/templates.js` (TYPES) + tafsiri `type_<jina>` kwenye i18n. Kisha `python3 tools/check-i18n.py`.
- **Kuongeza lugha:** nakili `src/i18n/en.js`, ongeza kwenye `LANGS` ndani ya `src/i18n/index.js`.
- **Data & sync ya baadaye:** kila rekodi ina `id` ya UUID na `updated_at`, na kila jedwali lina `business_id`, hivyo sync ya cloud inaweza kuongezwa bila kubadilisha muundo.

## Mipaka ya toleo hili

- Tarehe ya kuisha muda ni ya bidhaa nzima (si kwa batch); logo ya biashara haijaongezwa.
- Notification hutumwa app inapofanya kazi/inapofunguliwa (hakuna kazi ya nyuma).
- Nenosiri likipotea data haiwezi kurudishwa isipokuwa kwa backup (Settings → Backup).
- Icon ya app ni ya kawaida ya Capacitor; ibadilishe kwa `@capacitor/assets` ukipenda.
