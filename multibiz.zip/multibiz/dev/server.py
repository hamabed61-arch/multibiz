#!/usr/bin/env python3
"""
dev/server.py - seva ya majaribio kwenye kompyuta (HAIHUSIKI na APK).
Inaonyesha app kwenye browser na kutumia SQLite halisi ya Python kupitia /__sql.

  python3 dev/server.py            -> http://localhost:5173
  MB_DB=/tmp/x.sqlite PORT=5199 python3 dev/server.py
"""
import http.server, json, os, sqlite3, threading

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.environ.get("MB_DB", os.path.join(ROOT, "dev", "dev.sqlite"))
PORT = int(os.environ.get("PORT", "5173"))
LOCK = threading.Lock()
CON = None


def connect():
    global CON
    CON = sqlite3.connect(DB_PATH, check_same_thread=False, isolation_level=None)
    CON.row_factory = sqlite3.Row


connect()


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **k):
        super().__init__(*a, directory=ROOT, **k)

    def translate_path(self, path):
        p = super().translate_path(path)
        if not os.path.exists(p):  # public/ inanakiliwa kwenye mzizi wakati wa build (Vite)
            alt = os.path.join(ROOT, "public", os.path.relpath(p, ROOT))
            if os.path.exists(alt):
                return alt
        return p

    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    def log_message(self, *a):
        pass

    def _json(self, obj, code=200):
        data = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        global CON
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0)) or 0) or "{}")
        op, sql, params = body.get("op"), body.get("sql", ""), body.get("params") or []
        with LOCK:
            try:
                if self.path == "/__reset":
                    CON.close()
                    for ext in ("", "-journal"):
                        if os.path.exists(DB_PATH + ext):
                            os.remove(DB_PATH + ext)
                    connect()
                    return self._json({"ok": True})
                if op == "exec":
                    single = sql.strip().rstrip(";")
                    if ";" not in single:      # BEGIN/COMMIT/ROLLBACK: executescript ingeweza kuvunja transaction
                        CON.execute(single)
                    else:
                        CON.executescript(sql)
                    return self._json({"ok": True})
                if op == "run":
                    cur = CON.execute(sql, params)
                    return self._json({"changes": cur.rowcount, "lastId": cur.lastrowid})
                if op == "all":
                    rows = [dict(r) for r in CON.execute(sql, params).fetchall()]
                    return self._json({"values": rows})
                return self._json({"error": "bad op"}, 400)
            except Exception as e:  # noqa
                return self._json({"error": str(e)}, 500)


if __name__ == "__main__":
    print(f"MultiBiz dev server: http://localhost:{PORT}   (db: {DB_PATH})")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
