#!/usr/bin/env python3
"""
tools/gen-icons.py - hutengeneza src/icons.css (icons za Font Awesome Free kama SVG za ndani, zinafanya kazi bila internet).
Inasoma majina ya icons yaliyotumika kwenye src/*.js, kisha inatafuta SVG zake kwenye folda ya Font Awesome.

  python3 tools/gen-icons.py /path/to/fontawesome     (folda yenye solid/ regular/ brands/)
"""
import glob, os, re, sys, shutil

FA = sys.argv[1] if len(sys.argv) > 1 else '/usr/local/lib/python3.12/dist-packages/material/templates/.icons/fontawesome'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = "\n".join(open(f, encoding='utf-8').read() for f in glob.glob(f'{ROOT}/src/**/*.js', recursive=True))

available = {os.path.basename(p)[:-4] for p in glob.glob(f'{FA}/solid/*.svg')}
literals = set(re.findall(r"['\"`]([a-z][a-z0-9-]*)['\"`]", src))
used = sorted(literals & available)

# ukaguzi: kila jina ndani ya ic('...') lazima liwepo
needed = set()
for call in re.findall(r"\bic\(([^)]*)\)", src):
    needed |= set(re.findall(r"'([a-z][a-z0-9-]*)'", call))
needed |= set(re.findall(r"icon:\s*'([a-z][a-z0-9-]*)'", src))
missing = sorted(n for n in needed if n not in available and n not in ('', ))
missing = [m for m in missing if m not in ('expense', 'sale', 'ok', 'service', 'purchase') and not m.startswith('lvl')]
if missing:
    print("HAKUNA icons hizi:", missing); sys.exit(1)

def datauri(path):
    svg = open(path, encoding='utf-8').read()
    svg = re.sub(r'<!--.*?-->', '', svg, flags=re.S).strip().replace('"', "'")
    for a, b in (('%', '%25'), ('<', '%3C'), ('>', '%3E'), ('#', '%23'), ('\n', '')):
        svg = svg.replace(a, b)
    return f'url("data:image/svg+xml,{svg}")'

rules = [f'.fa-{n}::before{{-webkit-mask-image:{datauri(f"{FA}/solid/{n}.svg")};mask-image:{datauri(f"{FA}/solid/{n}.svg")}}}' for n in used]
css = '''/* icons.css - icons za ndani (hazihitaji internet). Font Awesome Free 6 (CC BY 4.0) - angalia ICONS-LICENSE.txt.
   Matumizi: <i class="fas fa-plus"></i>. Tengeneza upya: python3 tools/gen-icons.py <fontawesome-dir> */
.fas,.far{display:inline-block;font-style:normal;line-height:1}
.fas::before,.far::before{content:"";display:inline-block;width:1em;height:1em;vertical-align:-.125em;
  background-color:currentColor;-webkit-mask-repeat:no-repeat;mask-repeat:no-repeat;
  -webkit-mask-position:center;mask-position:center;-webkit-mask-size:contain;mask-size:contain}
''' + "\n".join(rules) + "\n"
open(f'{ROOT}/src/icons.css', 'w', encoding='utf-8').write(css)
lic = f'{FA}/LICENSE.txt'
if os.path.exists(lic): shutil.copy(lic, f'{ROOT}/src/ICONS-LICENSE.txt')
print(f"icons: {len(used)}  ({len(css)//1024} KB)")
