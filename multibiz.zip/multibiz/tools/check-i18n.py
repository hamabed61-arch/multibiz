#!/usr/bin/env python3
"""tools/check-i18n.py - hukagua kuwa kila ufunguo wa tafsiri unaotumika kwenye code upo kwa lugha zote 3."""
import re, glob, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src = "\n".join(open(f, encoding='utf-8').read() for f in glob.glob(f'{ROOT}/src/**/*.js', recursive=True) if '/i18n/' not in f)
dicts = {l: set(re.findall(r"\b([a-z][a-z0-9_]*):\s*['\"]", open(f'{ROOT}/src/i18n/{l}.js', encoding='utf-8').read())) for l in ('en', 'sw', 'ar')}

used = set(re.findall(r"\bt\('([a-z0-9_]+)'", src))
used |= set(re.findall(r"(?:title|label|text):\s*'([a-z0-9_]+_[a-z0-9_]+)'", src))
used |= set(re.findall(r"'((?:nav|stat|debts|no|err|filter|mod|cat|type|unit|method|mv|range|group|al|add|m|count)_[a-z0-9_]+)'", src))
# ufunguo wenye t(cond ? 'a' : 'b')
for call in re.findall(r"\bt\(([^()]*\?[^()]*)\)", src):
    used |= set(re.findall(r"'([a-z][a-z0-9_]+)'", call))

# familia za dynamic
from itertools import product
fam = {
  'type_': ['shop','supermarket','electronics','hardware','pharmacy','medical_store','farming','livestock','poultry','fish','salon','restaurant','garage','consultancy','other'],
  'group_': ['retail','health','agri','services','other'],
  'mod_': ['sales','inventory','purchases','expenses','customers','suppliers','debts','employees','reports','production','expiry'],
  'cat_': ['rent','salary','transport','utilities','airtime','tax','supplies','repairs','feed','other'],
  'unit_': ['pcs','kg','litre','box','bag','tray','dozen','meter','hour','service','flock','herd','pond','field'],
  'method_': ['cash','mobile','bank'], 'mv_': ['opening','purchase','sale','adjust','return'],
  'range_': ['today','week','month','year','all'],
  'm_': ['eggs','feed_kg','mortality','milk','deaths','harvest_kg'], 'count_': ['birds','animals','fish','acres'],
  'al_': ['out_of_stock','low_stock','running_out','expired','expiring','sales_up','sales_down','expenses_exceed','expenses_up','profit_negative','profit_good','best_day','debts_high','loss_high','produce_down','produce_up','lvl_danger','lvl_warn','lvl_good'],
  'sec_q': ['1','2','3'],
  'no_units_': ['flock','herd','pond','field'], 'add_unit_': ['flock','herd','pond','field'],
}
need = {k for k in used if not k.endswith('_') and re.fullmatch(r"[a-z0-9_]+", k) and k not in ('debts_high', 'sec_q')}
for p, vals in fam.items(): need |= {p + v for v in vals}
# 'used' inaweza kuwa na maneno yasiyo funguo (mfano 'add_line' ni ufunguo; 'nav_main' ni ufunguo) - kagua tu yenye '_' au yanayojulikana
missing = {l: sorted(k for k in need if k not in d and ('_' in k or k in dicts['en'])) for l, d in dicts.items()}
bad = False
for l, m in missing.items():
    if m: bad = True; print(f'[{l}] HAKUNA:', m)
print('OK - tafsiri zote zipo' if not bad else 'IMEKUTWA KUKOSEKANA')
sys.exit(1 if bad else 0)
