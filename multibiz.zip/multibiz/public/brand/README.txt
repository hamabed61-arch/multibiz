Picha za brand:
  logo.png  - logo ya Scanika (sidebar, usajili, login)
  about.jpg - poster ya ukurasa wa Kuhusu
Ukibadilisha, tumia majina yale yale.
