// auth.js - PIN/password ya ndani ya kifaa (imehifadhiwa kama hash, si maandishi wazi)
const enc = new TextEncoder();
const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

export function newSalt() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return toHex(a);
}

export async function hashPin(pin, salt) {
  if (crypto.subtle) {
    const key = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 100000 }, key, 256);
    return toHex(bits);
  }
  // mbadala (mazingira yasiyo salama) - hash rahisi
  let h = 5381;
  for (const c of salt + pin) h = ((h << 5) + h + c.charCodeAt(0)) | 0;
  return 'x' + (h >>> 0).toString(16);
}
