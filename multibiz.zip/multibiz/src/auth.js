// auth.js - PIN/password ya ndani ya kifaa (imehifadhiwa kama hash, si maandishi wazi)
const enc = new TextEncoder();
const toHex = (buf) => [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');

export function newSalt() {
  const a = new Uint8Array(16);
  crypto.getRandomValues(a);
  return toHex(a);
}

export async function hashPin(pin, salt) {
  if (crypto.subtle) {
    const key = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt: enc.encode(salt), iterations: 100000 }, key, 256);
    return toHex(bits);
  }
  // mbadala (mazingira yasiyo salama) - hash rahisi
  let h = 5381;
  for (const c of salt + pin) h = ((h << 5) + h + c.charCodeAt(0)) | 0;
  return 'x' + (h >>> 0).toString(16);
}

// Majibu ya maswali ya usalama: sawazisha (herufi ndogo, bila alama/nafasi za ziada) kabla ya kuhifadhi hash
export function normalizeAnswer(str) {
  let x = String(str || '').normalize('NFKD').replace(/[\u0300-\u036f\u064b-\u065f\u0670]/g, '').toLowerCase();
  x = x.replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه');
  return x.replace(/[^\p{L}\p{N}\s]/gu, '').replace(/\s+/g, ' ').trim();
}

export const hashAnswers = (answers, salt) => Promise.all(answers.map((a, i) => hashPin(normalizeAnswer(a), `${salt}:${i}`)));
