// employees.js - wafanyakazi (mtumiaji mmoja: hapa ni orodha na malipo ya mshahara)
import { t, num } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, formData, toNum, money, emptyState, pageHead, confirmBox } from '../ui.js';
import { listEmployees, saveEmployee, deleteEmployee, paySalary } from '../data.js';
import { hasModule } from '../templates.js';
import { afterChange } from '../state.js';
import { fab, kv } from './_shared.js';

export default async function employees(view, { biz }) {
  const cur = biz.currency;
  async function draw() {
    const list = await listEmployees(biz.id);
    const payroll = list.filter((e) => e.active).reduce((a, e) => a + e.salary, 0);
    view.innerHTML = `
      ${pageHead(t('nav_employees'))}
      <div class="totals one"><div><small>${esc(t('monthly_payroll'))}</small><b class="c-gold">${esc(money(payroll, cur))}</b></div></div>
      ${list.length ? list.map((e) => `
        <button class="row ${e.active ? '' : 'void'}" data-id="${e.id}"><div class="row-icon c-purple">${ic('user-tie')}</div>
          <div class="row-main"><b>${esc(e.name)}</b><small>${esc(e.role || '—')}${e.phone ? ' • ' + esc(e.phone) : ''}</small></div>
          <div class="row-end"><b class="row-amt">${esc(num(e.salary))}</b>${e.active ? '' : `<small class="c-red">${esc(t('inactive'))}</small>`}</div></button>`).join('')
        : emptyState('user-tie', t('no_employees'))}
      ${fab()}`;
    $('#fab', view).onclick = () => form(null);
    $$('.row', view).forEach((b) => (b.onclick = () => open(list.find((e) => e.id === b.dataset.id))));
  }

  function form(e) {
    sheet(e ? t('edit') : t('add_employee'), `<form id="emForm">
      ${field({ label: t('name'), name: 'name', value: e?.name, required: true })}
      <div class="fg-row">${field({ label: t('role'), name: 'role', value: e?.role })}${field({ label: t('phone'), name: 'phone', type: 'tel', value: e?.phone })}</div>
      ${field({ label: t('salary'), name: 'salary', type: 'number', value: e?.salary ?? '' })}
      ${e ? `<label class="chip-toggle ${e.active ? 'on' : ''}"><input type="checkbox" name="active" ${e.active ? 'checked' : ''}> ${esc(t('active'))}</label>` : ''}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
      $('#emForm', body).onsubmit = async (ev) => {
        ev.preventDefault();
        const f = formData(ev.target);
        await saveEmployee(biz.id, { name: f.name, role: f.role, phone: f.phone, salary: toNum(f.salary), active: e ? !!f.active : true }, e?.id);
        toast(t('saved'), 'good'); close(); draw();
      };
    });
  }

  function open(e) {
    sheet(e.name, `${kv(t('role'), esc(e.role || '—'))}${kv(t('salary'), esc(money(e.salary, cur)))}
      <div class="btn-row wrap">
        ${hasModule(biz, 'expenses') && e.salary > 0 ? `<button class="btn btn-gold" id="emPay">${ic('money-bill-wave')} ${esc(t('pay_salary'))}</button>` : ''}
        <button class="btn btn-ghost" id="emEdit">${ic('pen')} ${esc(t('edit'))}</button>
        <button class="btn btn-danger" id="emDel">${ic('trash-can')} ${esc(t('delete'))}</button></div>`, (body, close) => {
      const pay = $('#emPay', body);
      if (pay) pay.onclick = async () => {
        if (!(await confirmBox(t('pay_salary_confirm', { name: e.name, amt: money(e.salary, cur) }), { danger: false }))) return;
        await paySalary(biz.id, e, e.salary);
        toast(t('saved'), 'good'); close(); await afterChange();
      };
      $('#emEdit', body).onclick = () => { close(); form(e); };
      $('#emDel', body).onclick = async () => { if (await confirmBox(t('delete_confirm'))) { await deleteEmployee(e.id); close(); draw(); } };
    });
  }
  await draw();
}
