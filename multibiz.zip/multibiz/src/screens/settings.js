// settings.js - mipangilio: lugha, arifa, akaunti, biashara, modules, backup
import { t, LANGS, getLang } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, formData, money, confirmBox, pageHead } from '../ui.js';
import { getSetting, setSetting, exportAll, importAll, wipeAll, dateStr } from '../db/index.js';
import { updateBusiness, saveModules, deleteBusiness, createBusiness } from '../data.js';
import { MODULES, TYPES, GROUPS, typesOfGroup, CURRENCIES, typeInfo } from '../templates.js';
import { hashPin, newSalt } from '../auth.js';
import { S, bus, loadBusinesses, changeLanguage, afterChange, nav } from '../state.js';
import { shareFile } from '../share.js';
import { ensurePermission, pushNotification } from '../notify.js';

export function openAddBusiness(onCreated) {
  sheet(t('add_business'), `<form id="abForm">
    <div class="fg"><label>${esc(t('business_type'))}</label><select name="type" id="abType">
      ${GROUPS.map((g) => `<optgroup label="${esc(t('group_' + g))}">${typesOfGroup(g).map((k) => `<option value="${k}">${esc(t('type_' + k))}</option>`).join('')}</optgroup>`).join('')}
    </select></div>
    ${field({ label: t('business_name'), name: 'name', required: true })}
    <div id="abCustom" hidden>${field({ label: t('custom_type'), name: 'custom_type' })}</div>
    ${field({ label: t('location'), name: 'location' })}
    <div class="fg-row">${selectField({ label: t('currency'), name: 'currency', value: S.biz?.currency || 'TZS', options: CURRENCIES.map((c) => ({ value: c, label: c })) })}${field({ label: t('phone'), name: 'phone', type: 'tel' })}</div>
    <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
    const form = $('#abForm', body);
    form.type.onchange = () => { $('#abCustom', body).hidden = form.type.value !== 'other'; };
    form.onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(form);
      if (f.type === 'other' && !f.custom_type) return toast(t('err_custom_type'), 'danger');
      const id = await createBusiness({ type: f.type, name: f.name, custom_type: f.custom_type, location: f.location, phone: f.phone, currency: f.currency });
      await loadBusinesses();
      toast(t('saved'), 'good');
      close();
      onCreated && onCreated(id);
    };
  });
}

export default async function settings(view, { biz }) {
  const notify = (await getSetting('notify', '1')) !== '0';

  view.innerHTML = `
    ${pageHead(t('nav_settings'))}

    <div class="card"><div class="card-title">${ic('language')} ${esc(t('language'))}</div>
      <div class="lang-list row-list">${LANGS.map((l) => `<button class="lang-btn ${getLang() === l.code ? 'sel' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}</div></div>

    <div class="card"><div class="card-title">${ic('bell')} ${esc(t('notifications'))}</div>
      <label class="switch-row"><span>${esc(t('notify_on'))}<small>${esc(t('notify_sub'))}</small></span>
        <input type="checkbox" id="notifyToggle" ${notify ? 'checked' : ''}></label>
      <button class="btn btn-ghost block" id="notifyTest">${ic('paper-plane')} ${esc(t('notify_test'))}</button></div>

    <div class="card"><div class="card-title">${ic('building')} ${esc(biz.name)}</div>
      <form id="bizForm">
        ${field({ label: t('business_name'), name: 'name', value: biz.name, required: true })}
        ${biz.type === 'other' ? field({ label: t('custom_type'), name: 'custom_type', value: biz.custom_type }) : ''}
        ${field({ label: t('location'), name: 'location', value: biz.location })}
        <div class="fg-row">${selectField({ label: t('currency'), name: 'currency', value: biz.currency, options: CURRENCIES.map((c) => ({ value: c, label: c })) })}${field({ label: t('phone'), name: 'phone', type: 'tel', value: biz.phone })}</div>
        <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button>
      </form></div>

    <div class="card"><div class="card-title">${ic('puzzle-piece')} ${esc(t('modules'))}</div>
      <p class="muted">${esc(t('modules_sub'))}</p>
      <div class="chips">${MODULES.filter((m) => m.key !== 'production' || typeInfo(biz.type).production).map((m) => {
        const on = JSON.parse(biz.modules).includes(m.key);
        return `<label class="chip-toggle ${on ? 'on' : ''}"><input type="checkbox" data-mod="${m.key}" ${on ? 'checked' : ''}>${ic(m.icon)} ${esc(t('mod_' + m.key))}</label>`;
      }).join('')}</div></div>

    <div class="card"><div class="card-title">${ic('building-user')} ${esc(t('my_businesses'))}</div>
      <button class="btn btn-ghost block" id="addBiz">${ic('plus')} ${esc(t('add_business'))}</button>
      ${S.businesses.length > 1 ? `<button class="btn btn-danger block" id="delBiz">${ic('trash-can')} ${esc(t('delete_business'))}</button>` : ''}</div>

    <div class="card"><div class="card-title">${ic('user-shield')} ${esc(t('account'))}</div>
      <form id="pwForm">
        ${field({ label: t('current_password'), name: 'cur', type: 'password', required: true })}
        ${field({ label: t('new_password'), name: 'nw', type: 'password', required: true })}
        ${field({ label: t('password_confirm'), name: 'nw2', type: 'password', required: true })}
        <button class="btn btn-ghost block" type="submit">${ic('key')} ${esc(t('change_password'))}</button></form></div>

    <div class="card"><div class="card-title">${ic('database')} ${esc(t('backup'))}</div>
      <p class="muted">${esc(t('backup_sub'))}</p>
      <div class="btn-row wrap"><button class="btn btn-gold" id="bkExport">${ic('file-export')} ${esc(t('backup_export'))}</button>
        <button class="btn btn-ghost" id="bkImport">${ic('file-import')} ${esc(t('backup_restore'))}</button></div>
      <input type="file" id="bkFile" accept=".json,application/json" hidden></div>

    <div class="card"><button class="btn btn-danger block" id="resetAll">${ic('triangle-exclamation')} ${esc(t('reset_app'))}</button>
      <p class="muted center-text">MultiBiz 1.0 • ${esc(t('app_offline'))}</p></div>`;

  $$('[data-lang]', view).forEach((b) => (b.onclick = () => changeLanguage(b.dataset.lang)));

  $('#notifyToggle', view).onchange = async (e) => {
    await setSetting('notify', e.target.checked ? '1' : '0');
    if (e.target.checked) await ensurePermission();
  };
  $('#notifyTest', view).onclick = async () => {
    await ensurePermission();
    await pushNotification(`MultiBiz • ${biz.name}`, t('notify_test_body'), 'good');
  };

  $('#bizForm', view).onsubmit = async (e) => {
    e.preventDefault();
    await updateBusiness(biz.id, formData(e.target));
    await loadBusinesses();
    toast(t('saved'), 'good');
    bus.dispatchEvent(new Event('rerender'));
  };

  $$('[data-mod]', view).forEach((cb) => (cb.onchange = async () => {
    const cur = new Set(JSON.parse(S.biz.modules));
    cb.checked ? cur.add(cb.dataset.mod) : cur.delete(cb.dataset.mod);
    await saveModules(biz.id, [...cur]);
    await loadBusinesses();
    cb.closest('.chip-toggle').classList.toggle('on', cb.checked);
    await afterChange();
    bus.dispatchEvent(new Event('rerender'));
  }));

  $('#addBiz', view).onclick = () => openAddBusiness(async (id) => { await setSetting('active_business_id', id); await loadBusinesses(); await afterChange(); nav('/dashboard'); bus.dispatchEvent(new Event('rerender')); });
  const del = $('#delBiz', view);
  if (del) del.onclick = async () => {
    if (!(await confirmBox(t('delete_business_confirm', { name: biz.name })))) return;
    await deleteBusiness(biz.id);
    await setSetting('active_business_id', '');
    await loadBusinesses();
    await afterChange();
    nav('/dashboard');
    bus.dispatchEvent(new Event('rerender'));
  };

  $('#pwForm', view).onsubmit = async (e) => {
    e.preventDefault();
    const f = formData(e.target);
    if ((await hashPin(f.cur, S.user.salt)) !== S.user.hash) return toast(t('err_wrong_password'), 'danger');
    if (f.nw.length < 4) return toast(t('err_pin_short'), 'danger');
    if (f.nw !== f.nw2) return toast(t('err_pin_match'), 'danger');
    const salt = newSalt();
    const hash = await hashPin(f.nw, salt);
    await setSetting('pin_salt', salt);
    await setSetting('pin_hash', hash);
    S.user.salt = salt; S.user.hash = hash;
    e.target.reset();
    toast(t('saved'), 'good');
  };

  $('#bkExport', view).onclick = async () => {
    try {
      const data = await exportAll();
      await shareFile(`multibiz-backup-${dateStr()}.json`, JSON.stringify(data));
      toast(t('backup_done'), 'good');
    } catch (err) { toast(String(err.message || err), 'danger'); }
  };
  $('#bkImport', view).onclick = () => $('#bkFile', view).click();
  $('#bkFile', view).onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (!(await confirmBox(t('restore_confirm')))) return;
      await importAll(data);
      toast(t('restore_done'), 'good');
      setTimeout(() => location.reload(), 900);
    } catch (err) { toast(t('err_backup_file'), 'danger'); }
  };

  $('#resetAll', view).onclick = async () => {
    if (await confirmBox(t('reset_warning'), { okText: t('reset_app') })) { await wipeAll(); location.reload(); }
  };
}
