// onboarding.js - usajili: lugha -> akaunti -> aina ya biashara (moja/nyingi) -> maelezo -> modules
import { t, LANGS, setLang, getLang } from '../i18n/index.js';
import { $, $$, esc, ic, brandLogo } from '../ui.js';
import { TYPES, GROUPS, typesOfGroup, CURRENCIES, MODULES, typeInfo } from '../templates.js';
import { setSetting, tx } from '../db/index.js';
import { createBusiness } from '../data.js';
import { hashPin, newSalt } from '../auth.js';
import { S, loadUser } from '../state.js';
import { ensurePermission } from '../notify.js';

const STEPS = ['lang', 'account', 'mode', 'details', 'modules'];

export function startOnboarding(root, onDone) {
  const ob = { step: 'lang', name: '', phone: '', pin: '', pin2: '', mode: 'one', types: [], list: [], error: '' };

  const dots = () => `<div class="ob-dots">${STEPS.map((s, i) => `<i class="${i <= STEPS.indexOf(ob.step) ? 'on' : ''}"></i>`).join('')}</div>`;

  function frame(title, sub, body, { back = true, next = t('next') } = {}) {
    root.innerHTML = `
      <div class="ob">
        <div class="ob-card">
          ${dots()}
          <h1>${esc(title)}</h1>
          ${sub ? `<p class="ob-sub">${esc(sub)}</p>` : ''}
          <div class="ob-body">${body}</div>
          ${ob.error ? `<div class="form-error">${ic('circle-exclamation')} ${esc(ob.error)}</div>` : ''}
          <div class="btn-row ob-nav">
            ${back ? `<button class="btn btn-ghost" data-back>${esc(t('back'))}</button>` : ''}
            ${next ? `<button class="btn btn-gold" data-next>${esc(next)}</button>` : ''}
          </div>
        </div>
      </div>`;
    const b = $('[data-back]', root);
    if (b) b.onclick = () => { ob.error = ''; go(STEPS[STEPS.indexOf(ob.step) - 1]); };
    const n = $('[data-next]', root);
    if (n) n.onclick = onNext;
    return root;
  }

  function go(step) { ob.step = step; render(); }
  function fail(msg) { ob.error = msg; render(); }

  // ───────── steps ─────────
  function stepLang() {
    root.innerHTML = `
      <div class="ob">
        <div class="ob-card center">
          ${dots()}
          ${brandLogo('big')}
          <h1 class="brand-title">Multi<span>Biz</span></h1>
          <p class="ob-sub">${esc(t('app_tagline'))}</p>
          <p class="ob-label">${esc(t('choose_language'))}</p>
          <div class="lang-list">
            ${LANGS.map((l) => `<button class="lang-btn ${getLang() === l.code ? 'sel' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}
          </div>
        </div>
      </div>`;
    $$('[data-lang]', root).forEach((b) => (b.onclick = () => { setLang(b.dataset.lang); go('account'); }));
  }

  function stepAccount() {
    frame(t('ob_account_title'), t('ob_account_sub'), `
      <div class="fg"><label>${esc(t('full_name'))} <b>*</b></label><input id="ob_name" value="${esc(ob.name)}" autocomplete="name"></div>
      <div class="fg"><label>${esc(t('phone'))}</label><input id="ob_phone" type="tel" value="${esc(ob.phone)}" autocomplete="tel"></div>
      <div class="fg"><label>${esc(t('password'))} <b>*</b></label><input id="ob_pin" type="password" value="${esc(ob.pin)}" autocomplete="new-password"><small>${esc(t('password_hint'))}</small></div>
      <div class="fg"><label>${esc(t('password_confirm'))} <b>*</b></label><input id="ob_pin2" type="password" value="${esc(ob.pin2)}" autocomplete="new-password"></div>`);
  }

  function stepMode() {
    const sel = new Set(ob.types);
    const group = (g) => `
      <div class="type-group"><div class="nav-label">${esc(t('group_' + g))}</div>
        <div class="type-grid">${typesOfGroup(g).map((k) => `
          <button class="type-card ${sel.has(k) ? 'sel' : ''}" data-type="${k}">${ic(TYPES[k].icon)}<span>${esc(t('type_' + k))}</span>${sel.has(k) ? `<em>${ic('check')}</em>` : ''}</button>`).join('')}
        </div></div>`;
    frame(t('ob_mode_title'), t('ob_mode_sub'), `
      <div class="mode-cards">
        <button class="mode-card ${ob.mode === 'one' ? 'sel' : ''}" data-mode="one">${ic('store')}<b>${esc(t('mode_one'))}</b><small>${esc(t('mode_one_sub'))}</small></button>
        <button class="mode-card ${ob.mode === 'many' ? 'sel' : ''}" data-mode="many">${ic('boxes-stacked')}<b>${esc(t('mode_many'))}</b><small>${esc(t('mode_many_sub'))}</small></button>
      </div>
      <p class="ob-label">${esc(ob.mode === 'one' ? t('choose_type_one') : t('choose_type_many'))}</p>
      ${GROUPS.map(group).join('')}`);
    $$('[data-mode]', root).forEach((b) => (b.onclick = () => {
      ob.mode = b.dataset.mode;
      if (ob.mode === 'one' && ob.types.length > 1) ob.types = ob.types.slice(0, 1);
      render();
    }));
    $$('[data-type]', root).forEach((b) => (b.onclick = () => {
      const k = b.dataset.type;
      if (ob.mode === 'one') ob.types = [k];
      else ob.types = ob.types.includes(k) ? ob.types.filter((x) => x !== k) : [...ob.types, k];
      ob.error = '';
      const y = window.scrollY;
      render();
      window.scrollTo(0, y);
    }));
  }

  function bizCard(b, i) {
    return `
      <div class="biz-card" data-i="${i}">
        <div class="biz-card-head">${ic(typeInfo(b.type).icon)}<b>${esc(t('type_' + b.type))}</b>
          ${ob.list.length > 1 ? `<button class="icon-btn" data-remove="${i}" aria-label="remove">${ic('trash-can')}</button>` : ''}</div>
        <div class="fg"><label>${esc(t('business_name'))} <b>*</b></label><input data-k="name" value="${esc(b.name)}"></div>
        ${b.type === 'other' ? `<div class="fg"><label>${esc(t('custom_type'))} <b>*</b></label><input data-k="custom_type" value="${esc(b.custom_type)}"></div>` : ''}
        <div class="fg"><label>${esc(t('location'))}</label><input data-k="location" value="${esc(b.location)}"></div>
        <div class="fg-row">
          <div class="fg"><label>${esc(t('currency'))}</label><select data-k="currency">${CURRENCIES.map((c) => `<option ${c === b.currency ? 'selected' : ''}>${c}</option>`).join('')}</select></div>
          <div class="fg"><label>${esc(t('phone'))}</label><input data-k="phone" type="tel" value="${esc(b.phone)}"></div>
        </div>
      </div>`;
  }

  function stepDetails() {
    // jenga list kutoka aina zilizochaguliwa (kwa kuhifadhi zilizokuwepo)
    const old = ob.list;
    const list = [];
    for (const type of ob.types) {
      const i = old.findIndex((b) => b.type === type && !list.includes(b));
      list.push(i >= 0 ? old[i] : mkBiz(type));
    }
    for (const b of old) if (!list.includes(b) && b.extra) list.push(b);
    ob.list = list;
    frame(t('ob_details_title'), t('ob_details_sub'), `
      ${list.map(bizCard).join('')}
      ${ob.mode === 'many' ? `<div class="add-biz"><select id="ob_add_type">${Object.keys(TYPES).map((k) => `<option value="${k}">${esc(t('type_' + k))}</option>`).join('')}</select>
        <button class="btn btn-ghost" data-addbiz>${ic('plus')} ${esc(t('add_business'))}</button></div>` : ''}`);
    $$('[data-remove]', root).forEach((b) => (b.onclick = () => { readDetails(); ob.list.splice(+b.dataset.remove, 1); ob.types = ob.list.map((x) => x.type); render(); }));
    const add = $('[data-addbiz]', root);
    if (add) add.onclick = () => { readDetails(); const b = mkBiz($('#ob_add_type', root).value); b.extra = true; ob.list.push(b); ob.types = ob.list.map((x) => x.type); render(); };
  }

  function mkBiz(type) {
    return { type, name: type === 'other' ? '' : t('type_' + type), custom_type: '', location: '', currency: 'TZS', phone: '', modules: [...typeInfo(type).modules], extra: false };
  }

  function readDetails() {
    $$('.biz-card', root).forEach((card) => {
      const b = ob.list[+card.dataset.i];
      if (!b) return;
      $$('[data-k]', card).forEach((el) => { b[el.dataset.k] = el.value.trim(); });
    });
  }

  function stepModules() {
    frame(t('ob_modules_title'), t('ob_modules_sub'), ob.list.map((b, i) => `
      <div class="biz-card" data-i="${i}">
        <div class="biz-card-head">${ic(typeInfo(b.type).icon)}<b>${esc(b.name)}</b></div>
        <div class="chips">${MODULES.filter((m) => m.key !== 'production' || typeInfo(b.type).production)
          .map((m) => `<label class="chip-toggle ${b.modules.includes(m.key) ? 'on' : ''}"><input type="checkbox" data-mod="${m.key}" ${b.modules.includes(m.key) ? 'checked' : ''}>${ic(m.icon)} ${esc(t('mod_' + m.key))}</label>`).join('')}
        </div>
      </div>`).join(''), { next: t('finish') });
    $$('[data-mod]', root).forEach((cb) => (cb.onchange = () => {
      const b = ob.list[+cb.closest('.biz-card').dataset.i];
      b.modules = cb.checked ? [...new Set([...b.modules, cb.dataset.mod])] : b.modules.filter((m) => m !== cb.dataset.mod);
      cb.closest('.chip-toggle').classList.toggle('on', cb.checked);
    }));
  }

  // ───────── navigation ─────────
  async function onNext() {
    ob.error = '';
    if (ob.step === 'account') {
      ob.name = $('#ob_name', root).value.trim();
      ob.phone = $('#ob_phone', root).value.trim();
      ob.pin = $('#ob_pin', root).value;
      ob.pin2 = $('#ob_pin2', root).value;
      if (!ob.name) return fail(t('err_name'));
      if (ob.pin.length < 4) return fail(t('err_pin_short'));
      if (ob.pin !== ob.pin2) return fail(t('err_pin_match'));
      return go('mode');
    }
    if (ob.step === 'mode') {
      if (!ob.types.length) return fail(t('err_choose_type'));
      return go('details');
    }
    if (ob.step === 'details') {
      readDetails();
      for (const b of ob.list) {
        if (!b.name) return fail(t('err_biz_name'));
        if (b.type === 'other' && !b.custom_type) return fail(t('err_custom_type'));
      }
      return go('modules');
    }
    if (ob.step === 'modules') return finish();
  }

  async function finish() {
    const btn = $('[data-next]', root);
    if (btn) btn.disabled = true;
    try {
      const salt = newSalt();
      const hash = await hashPin(ob.pin, salt);
      await tx(async () => {
        await setSetting('user_name', ob.name);
        await setSetting('user_phone', ob.phone);
        await setSetting('pin_salt', salt);
        await setSetting('pin_hash', hash);
        await setSetting('lang', getLang());
        await setSetting('notify', '1');
        let first = null;
        for (const b of ob.list) {
          const id = await createBusiness({ type: b.type, name: b.name, custom_type: b.custom_type, location: b.location, phone: b.phone, currency: b.currency, modules: b.modules });
          first = first || id;
        }
        await setSetting('active_business_id', first);
      });
      S.user = await loadUser();
      S.unlocked = true;
      ensurePermission();
      onDone();
    } catch (e) {
      console.error(e);
      if (btn) btn.disabled = false;
      fail(String(e.message || e));
    }
  }

  function render() {
    ({ lang: stepLang, account: stepAccount, mode: stepMode, details: stepDetails, modules: stepModules })[ob.step]();
  }
  render();
}
