// expenses.js - matumizi
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, formData, toNum, money, emptyState, pageHead, confirmBox } from '../ui.js';
import { listExpenses, addExpense, deleteExpense } from '../data.js';
import { EXPENSE_CATS } from '../templates.js';
import { dateStr } from '../db/index.js';
import { afterChange } from '../state.js';
import { rangeFor, rangeTabs, onTabs, fab, errText } from './_shared.js';

export function expenseForm(biz, onDone, preset = {}) {
  sheet(t('add_expense'), `<form id="exForm">
    ${selectField({ label: t('category'), name: 'category', value: preset.category || 'other', options: EXPENSE_CATS.map((c) => ({ value: c, label: t('cat_' + c) })) })}
    ${field({ label: t('amount'), name: 'amount', type: 'number', value: preset.amount ?? '', required: true })}
    ${field({ label: t('date'), name: 'date', type: 'date', value: dateStr() })}
    ${field({ label: t('note'), name: 'note', value: preset.note || '' })}
    <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
    $('#exForm', body).onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(e.target);
      try {
        await addExpense(biz.id, { category: f.category, amount: toNum(f.amount), note: f.note, date: f.date });
        toast(t('saved'), 'good'); close(); await afterChange(); onDone && onDone();
      } catch (err) { toast(errText(err), 'danger'); }
    };
  });
}

export default async function expenses(view, { biz, params }) {
  let range = 'month';
  async function draw() {
    const [from, to] = rangeFor(range);
    const list = await listExpenses(biz.id, from, to);
    const total = list.reduce((a, e) => a + e.amount, 0);
    view.innerHTML = `
      ${pageHead(t('nav_expenses'))}
      ${rangeTabs(range)}
      <div class="totals one"><div><small>${esc(t('total'))}</small><b class="c-red">${esc(money(total, biz.currency))}</b></div></div>
      ${list.length ? list.map((e) => `
        <button class="row" data-id="${e.id}"><div class="row-icon c-red">${ic('wallet')}</div>
          <div class="row-main"><b>${esc(t('cat_' + e.category))}</b><small>${esc(fmtDate(e.created_at))}${e.note ? ' • ' + esc(e.note) : ''}</small></div>
          <div class="row-amt neg">− ${esc(num(e.amount))}</div></button>`).join('') : emptyState('wallet', t('no_expenses'))}
      ${fab()}`;
    onTabs(view, (k) => { range = k; draw(); });
    $('#fab', view).onclick = () => expenseForm(biz, draw);
    $$('.row[data-id]', view).forEach((b) => (b.onclick = async () => {
      if (await confirmBox(t('delete_confirm'))) { await deleteExpense(b.dataset.id); await afterChange(); draw(); }
    }));
  }
  await draw();
  if (params.get('new')) expenseForm(biz, draw);
}
