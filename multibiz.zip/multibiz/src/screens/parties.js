// parties.js - wateja na wasambazaji (kwa pamoja: kind = 'customer' | 'supplier')
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, textArea, formData, money, emptyState, pageHead, debounce, confirmBox } from '../ui.js';
import { listParties, getParty, saveParty, deleteParty, partyHistory } from '../data.js';
import { hasModule } from '../templates.js';
import { afterChange } from '../state.js';
import { fab, kv, paymentSheet, errText } from './_shared.js';

export function partyForm(biz, kind, party, onDone) {
  sheet(party ? t('edit') : kind === 'customer' ? t('add_customer') : t('add_supplier'), `<form id="paForm">
    ${field({ label: t('name'), name: 'name', value: party?.name, required: true })}
    ${field({ label: t('phone'), name: 'phone', type: 'tel', value: party?.phone })}
    ${field({ label: t('address'), name: 'address', value: party?.address })}
    ${textArea({ label: t('note'), name: 'note', value: party?.note })}
    <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
    $('#paForm', body).onsubmit = async (e) => {
      e.preventDefault();
      try {
        const id = await saveParty(kind, biz.id, formData(e.target), party?.id);
        toast(t('saved'), 'good'); close(); await afterChange(); onDone && onDone(id);
      } catch (err) { toast(errText(err), 'danger'); }
    };
  });
}

export default async function parties(view, { biz }, kind) {
  let q = '';
  const isCust = kind === 'customer';
  async function draw() {
    const list = await listParties(kind, biz.id, q);
    $('#plist', view).innerHTML = list.length ? list.map((p) => `
      <button class="row" data-id="${p.id}"><div class="row-icon ${isCust ? 'c-purple' : 'c-blue'}">${ic(isCust ? 'user' : 'truck-field')}</div>
        <div class="row-main"><b>${esc(p.name)}</b><small>${esc(p.phone || '—')}</small></div>
        <div class="row-end">${p.balance > 0.009 ? `<span class="badge-pill lvl-danger">${esc(num(p.balance))}</span>` : `<small class="c-green">${ic('check')}</small>`}</div></button>`).join('')
      : emptyState(isCust ? 'users' : 'handshake', t(isCust ? 'no_customers' : 'no_suppliers'));
    $$('.row', view).forEach((b) => (b.onclick = () => open(b.dataset.id)));
  }
  view.innerHTML = `${pageHead(t(isCust ? 'nav_customers' : 'nav_suppliers'))}
    <div class="search-bar">${ic('magnifying-glass')}<input id="q" type="search" placeholder="${esc(t('search'))}"></div>
    <div id="plist"></div>${fab()}`;
  $('#q', view).oninput = debounce((e) => { q = e.target.value; draw(); }, 200);
  $('#fab', view).onclick = () => partyForm(biz, kind, null, draw);
  await draw();

  async function open(id) {
    const p = await getParty(kind, id);
    const hist = await partyHistory(kind, id);
    const canPay = hasModule(biz, 'debts') && p.balance > 0.009;
    sheet(p.name, `
      ${p.phone ? `<a class="btn btn-ghost block" href="tel:${esc(p.phone)}">${ic('phone')} ${esc(p.phone)}</a>` : ''}
      ${p.address ? kv(t('address'), esc(p.address)) : ''}
      ${kv(t('balance'), esc(money(p.balance, biz.currency)), p.balance > 0.009 ? 'c-red' : 'c-green')}
      <div class="btn-row wrap">
        ${canPay ? `<button class="btn btn-gold" id="paPay">${ic('hand-holding-dollar')} ${esc(t(isCust ? 'receive_payment' : 'make_payment'))}</button>` : ''}
        <button class="btn btn-ghost" id="paEdit">${ic('pen')} ${esc(t('edit'))}</button>
        <button class="btn btn-danger" id="paDel">${ic('trash-can')} ${esc(t('delete'))}</button>
      </div>
      ${hist.length ? `<div class="card-title sm">${esc(t('history'))}</div>` + hist.map((h) => `
        <div class="row slim"><div class="row-main"><b>${esc(h.t === 'payment' ? t('payment') : h.t === 'sale' ? t('sale_no', { n: h.ref }) : t('purchase'))}</b><small>${esc(fmtDate(h.created_at, true))}</small></div>
        <div class="row-amt ${h.t === 'payment' ? 'pos' : ''}">${esc(num(h.amount))}${h.t !== 'payment' && h.amount - h.paid > 0.009 ? `<small class="c-red"> (${esc(num(h.amount - h.paid))})</small>` : ''}</div></div>`).join('') : ''}`,
    (body, close) => {
      const pay = $('#paPay', body);
      if (pay) pay.onclick = () => { close(); paymentSheet(biz, kind, p, draw); };
      $('#paEdit', body).onclick = () => { close(); partyForm(biz, kind, p, draw); };
      $('#paDel', body).onclick = async () => {
        if (!(await confirmBox(t('delete_confirm')))) return;
        try { await deleteParty(kind, id); close(); await afterChange(); draw(); } catch (e) { toast(errText(e), 'danger'); }
      };
    });
  }
}
