// purchases.js - ununuzi wa bidhaa kutoka kwa wasambazaji (unaongeza stock)
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, formData, toNum, money, emptyState, pageHead } from '../ui.js';
import { listPurchases, getPurchase, createPurchase, listProducts, listParties } from '../data.js';
import { hasModule } from '../templates.js';
import { afterChange, nav } from '../state.js';
import { rangeFor, rangeTabs, onTabs, fab, kv, errText, methodOptions } from './_shared.js';

export default async function purchases(view, { biz }) {
  let range = 'month';
  async function draw() {
    const [from, to] = rangeFor(range);
    const list = await listPurchases(biz.id, from, to);
    const total = list.reduce((a, p) => a + p.total, 0);
    const debt = list.reduce((a, p) => a + (p.total - p.paid), 0);
    view.innerHTML = `
      ${pageHead(t('nav_purchases'))}
      ${rangeTabs(range)}
      <div class="totals"><div><small>${esc(t('total'))}</small><b class="c-blue">${esc(money(total, biz.currency))}</b></div>
        <div><small>${esc(t('purchase'))}</small><b>${list.length}</b></div>
        <div><small>${esc(t('on_credit'))}</small><b class="${debt > 0 ? 'c-red' : ''}">${esc(num(debt))}</b></div></div>
      ${list.length ? list.map((p) => `
        <button class="row" data-id="${p.id}"><div class="row-icon c-blue">${ic('truck')}</div>
          <div class="row-main"><b>${esc(p.supplier_name || t('no_supplier'))}</b><small>${esc(fmtDate(p.created_at, true))}</small></div>
          <div class="row-end"><b class="row-amt">${esc(num(p.total))}</b>${p.total - p.paid > 0.009 ? `<small class="c-red">${esc(t('on_credit'))}</small>` : ''}</div></button>`).join('')
        : emptyState('truck', t('no_purchases'))}
      ${fab()}`;
    onTabs(view, (k) => { range = k; draw(); });
    $('#fab', view).onclick = () => nav('/purchases/new');
    $$('.row[data-id]', view).forEach((b) => (b.onclick = async () => {
      const p = await getPurchase(b.dataset.id);
      sheet(t('purchase'), `
        ${kv(t('supplier'), esc(p.supplier_name || '—'))}${kv(t('date'), esc(fmtDate(p.created_at, true)))}
        ${p.items.map((i) => `<div class="rc-line"><span>${esc(i.name)} <small>× ${esc(num(i.qty))} @ ${esc(num(i.unit_cost))}</small></span><b>${esc(num(i.qty * i.unit_cost))}</b></div>`).join('')}
        <div class="rc-sep"></div>${kv(t('total'), esc(money(p.total, biz.currency)), 'c-gold')}${kv(t('paid'), esc(money(p.paid, biz.currency)))}
        ${p.total - p.paid > 0.009 ? kv(t('balance'), esc(money(p.total - p.paid, biz.currency)), 'c-red') : ''}`);
    }));
  }
  await draw();
}

export async function purchaseNew(view, { biz, params }) {
  const cur = biz.currency;
  const expiryOn = hasModule(biz, 'expiry');
  const products = (await listProducts(biz.id)).filter((p) => p.track_stock);
  const suppliers = hasModule(biz, 'suppliers') ? await listParties('supplier', biz.id) : [];
  if (!products.length) {
    view.innerHTML = `${pageHead(t('nav_purchases'))}${emptyState('box-open', t('no_products'), t('no_products_sub'))}<a class="btn btn-gold block" href="#/products?new=1">${ic('plus')} ${esc(t('add_product'))}</a>`;
    return;
  }
  const lines = [];
  const pre = params.get('product');
  const first = products.find((p) => p.id === pre) || products[0];
  lines.push({ product_id: first.id, qty: 1, cost: first.buy_price, expiry: '' });

  const total = () => lines.reduce((a, l) => a + l.qty * l.cost, 0);
  // 'change' inaweza kuja wakati DOM inaondolewa; tumia redraw isiyo ya papo hapo ili kuepuka hitilafu ya re-entrancy
  let rt = null;
  const redraw = () => { clearTimeout(rt); rt = setTimeout(() => draw(), 0); };
  function draw() {
    $('#lines', view).innerHTML = lines.map((l, i) => {
      const p = products.find((x) => x.id === l.product_id);
      return `<div class="card pl" data-i="${i}">
        <div class="fg"><label>${esc(t('product'))}</label><select data-k="product_id">${products.map((x) => `<option value="${x.id}" ${x.id === l.product_id ? 'selected' : ''}>${esc(x.name)} (${esc(num(x.stock))})</option>`).join('')}</select></div>
        <div class="fg-row"><div class="fg"><label>${esc(t('qty'))}</label><input data-k="qty" type="number" inputmode="decimal" step="any" value="${l.qty}"></div>
          <div class="fg"><label>${esc(t('unit_cost'))}</label><input data-k="cost" type="number" inputmode="decimal" step="any" value="${l.cost}"></div></div>
        ${expiryOn ? `<div class="fg"><label>${esc(t('expiry_date'))}</label><input data-k="expiry" type="date" value="${esc(l.expiry)}"></div>` : ''}
        <div class="pl-foot"><b>${esc(num(l.qty * l.cost))}</b>${lines.length > 1 ? `<button class="icon-btn" data-del>${ic('trash-can')}</button>` : ''}</div>
        ${p ? '' : ''}</div>`;
    }).join('');
    $('#ptotal', view).textContent = money(total(), cur);
    if (!$('#paid', view).dataset.touched) $('#paid', view).value = total();
    $$('.pl', view).forEach((card) => {
      const l = lines[+card.dataset.i];
      $$('[data-k]', card).forEach((el) => (el.onchange = () => {
        const k = el.dataset.k;
        if (k === 'product_id') { l.product_id = el.value; l.cost = products.find((x) => x.id === el.value).buy_price; }
        else if (k === 'expiry') l.expiry = el.value;
        else l[k] = toNum(el.value);
        redraw();
      }));
      const del = $('[data-del]', card);
      if (del) del.onclick = () => { lines.splice(+card.dataset.i, 1); draw(); };
    });
  }

  view.innerHTML = `
    ${pageHead(t('nav_purchases'))}
    <form id="puForm">
      ${suppliers.length || hasModule(biz, 'suppliers') ? selectField({ label: t('supplier'), name: 'supplier_id', options: [{ value: '', label: t('no_supplier') }, ...suppliers.map((s) => ({ value: s.id, label: s.name }))] }) : ''}
      <div id="lines"></div>
      <button type="button" class="btn btn-ghost block" id="addLine">${ic('plus')} ${esc(t('add_line'))}</button>
      <div class="card">${kv(t('total'), '<span id="ptotal"></span>', 'c-gold')}
        <div class="fg"><label>${esc(t('amount_paid'))}</label><input id="paid" name="paid" type="number" inputmode="decimal" step="any"></div>
        ${selectField({ label: t('method'), name: 'method', options: methodOptions() })}
        ${field({ label: t('note'), name: 'note' })}</div>
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save_purchase'))}</button>
    </form>`;
  $('#paid', view).oninput = (e) => { e.target.dataset.touched = '1'; };
  $('#addLine', view).onclick = () => { const p = products[0]; lines.push({ product_id: p.id, qty: 1, cost: p.buy_price, expiry: '' }); draw(); };
  $('#puForm', view).onsubmit = async (e) => {
    e.preventDefault();
    const f = formData(e.target);
    try {
      await createPurchase(biz.id, {
        supplier_id: f.supplier_id || null, paid: f.paid === '' ? undefined : toNum(f.paid), note: f.note,
        items: lines.map((l) => ({ product_id: l.product_id, name: products.find((p) => p.id === l.product_id).name, qty: l.qty, cost: l.cost, expiry: l.expiry || null }))
      });
      toast(t('saved'), 'good');
      await afterChange();
      nav('/purchases');
    } catch (err) { toast(errText(err), 'danger'); }
  };
  draw();
}
