// debts.js - madeni: wanaonidai (wateja) na ninaowadai (wasambazaji)
import { t, num } from '../i18n/index.js';
import { $$, esc, ic, money, emptyState, pageHead, tabs } from '../ui.js';
import { listParties, debtTotals } from '../data.js';
import { hasModule } from '../templates.js';
import { paymentSheet } from './_shared.js';

export default async function debts(view, { biz }) {
  const kinds = [hasModule(biz, 'customers') && 'customer', (hasModule(biz, 'suppliers') || hasModule(biz, 'purchases')) && 'supplier'].filter(Boolean);
  let kind = kinds[0] || 'customer';
  async function draw() {
    const totals = await debtTotals(biz.id);
    const list = (await listParties(kind, biz.id)).filter((p) => p.balance > 0.009).sort((a, b) => b.balance - a.balance);
    const total = kind === 'customer' ? totals.owedToMe : totals.iOwe;
    view.innerHTML = `
      ${pageHead(t('nav_debts'))}
      ${kinds.length > 1 ? tabs(kinds.map((k) => ({ key: k, label: t(k === 'customer' ? 'debts_owed_to_me' : 'debts_i_owe') })), kind) : ''}
      <div class="totals one"><div><small>${esc(t(kind === 'customer' ? 'debts_owed_to_me' : 'debts_i_owe'))}</small><b class="c-red">${esc(money(total, biz.currency))}</b></div></div>
      ${list.length ? list.map((p) => `
        <div class="row"><div class="row-icon c-red">${ic('hand-holding-dollar')}</div>
          <div class="row-main"><b>${esc(p.name)}</b><small>${esc(p.phone || '')}</small></div>
          <div class="row-end"><b class="row-amt neg">${esc(num(p.balance))}</b><button class="btn btn-mini" data-pay="${p.id}">${esc(t(kind === 'customer' ? 'receive_payment' : 'make_payment'))}</button></div></div>`).join('')
        : emptyState('circle-check', t('no_debts'))}`;
    $$('[data-tab]', view).forEach((b) => (b.onclick = () => { kind = b.dataset.tab; draw(); }));
    $$('[data-pay]', view).forEach((b) => (b.onclick = () => paymentSheet(biz, kind, list.find((p) => p.id === b.dataset.pay), draw)));
  }
  await draw();
}
