// _shared.js - vipande vinavyotumika na skrini nyingi
import { t } from '../i18n/index.js';
import { esc, ic, sheet, toast, field, selectField, textArea, formData, toNum, money, tabs, $, $$ } from '../ui.js';
import { dateStr, addDays } from '../db/index.js';
import { recordPayment } from '../data.js';
import { PAY_METHODS } from '../templates.js';
import { afterChange } from '../state.js';

export function rangeFor(key) {
  const today = dateStr();
  const d = new Date();
  switch (key) {
    case 'today': return [today, today];
    case 'week': return [dateStr(addDays(d, -6)), today];
    case 'month': return [`${today.slice(0, 7)}-01`, today];
    case 'year': return [`${today.slice(0, 4)}-01-01`, today];
    default: return ['0000-01-01', '9999-12-31'];
  }
}

export const rangeTabs = (active, keys = ['today', 'week', 'month', 'all']) =>
  tabs(keys.map((k) => ({ key: k, label: t('range_' + k) })), active);

// tabs kuwa clickable: attach(view, cb)
export function onTabs(view, cb) {
  $$('[data-tab]', view).forEach((b) => (b.onclick = () => cb(b.dataset.tab)));
}

export const fab = (id = 'fab', icon = 'plus') => `<button class="fab-btn" id="${id}" aria-label="add">${ic(icon)}</button>`;

export function methodOptions() {
  return PAY_METHODS.map((m) => ({ value: m, label: t('method_' + m) }));
}

export function errText(e) {
  const map = {
    insufficient: 'err_insufficient', empty_cart: 'err_empty_cart', credit_needs_customer: 'err_credit_customer',
    credit_needs_supplier: 'err_credit_supplier', bad_amount: 'err_amount', over_balance: 'err_over_balance', has_balance: 'err_has_balance'
  };
  const k = map[e.code];
  return k ? t(k, { d: e.detail ?? '' }) : String(e.message || e);
}

// fomu ya kupokea/kulipa deni
export function paymentSheet(biz, kind, party, onDone) {
  const title = kind === 'customer' ? t('receive_payment') : t('make_payment');
  sheet(title, `
    <div class="pay-head"><b>${esc(party.name)}</b><span class="badge-pill lvl-danger">${esc(t('balance'))}: ${esc(money(party.balance, biz.currency))}</span></div>
    <form id="payForm">
      ${field({ label: t('amount'), name: 'amount', type: 'number', value: party.balance, required: true })}
      ${selectField({ label: t('method'), name: 'method', options: methodOptions() })}
      ${field({ label: t('note'), name: 'note' })}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button>
    </form>`, (body, close) => {
    $('#payForm', body).onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(e.target);
      try {
        await recordPayment(biz.id, kind, party.id, toNum(f.amount), f.method, f.note);
        toast(t('saved'), 'good');
        close();
        await afterChange();
        onDone && onDone();
      } catch (err) { toast(errText(err), 'danger'); }
    };
  });
}

// mistari ya jumla (label - value)
export const kv = (label, value, cls = '') => `<div class="kv"><span>${esc(label)}</span><b class="${cls}">${value}</b></div>`;
