// sale-new.js - mauzo mapya (POS): chagua bidhaa -> kikapu -> malipo
import { t, num } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, textArea, formData, toNum, money, emptyState, pageHead, debounce } from '../ui.js';
import { listProducts, listParties, createSale } from '../data.js';
import { hasModule } from '../templates.js';
import { afterChange } from '../state.js';
import { methodOptions, errText, kv } from './_shared.js';
import { showReceipt } from './sales.js';

export default async function saleNew(view, { biz }) {
  const cur = biz.currency;
  const products = hasModule(biz, 'inventory') ? await listProducts(biz.id) : [];
  const customers = hasModule(biz, 'customers') ? await listParties('customer', biz.id) : [];
  const cart = [];
  let q = '';
  let seq = 0;

  let rt = null;
  const redraw = () => { clearTimeout(rt); rt = setTimeout(() => { drawCart(); drawList(); }, 0); };
  const subtotal = () => cart.reduce((a, l) => a + l.qty * l.price, 0);
  const stockLeft = (p) => p.stock - cart.filter((l) => l.product_id === p.id).reduce((a, l) => a + l.qty, 0);

  function add(p) {
    if (p.track_stock && stockLeft(p) < 1) return toast(t('err_insufficient', { d: p.name }), 'danger');
    const ex = cart.find((l) => l.product_id === p.id);
    if (ex) ex.qty += 1;
    else cart.push({ key: ++seq, product_id: p.id, name: p.name, qty: 1, price: p.sell_price, cost: p.buy_price, track: !!p.track_stock, stock: p.stock });
    drawCart();
    drawList();
  }

  function drawList() {
    const lower = q.toLowerCase();
    const rows = products.filter((p) => !lower || p.name.toLowerCase().includes(lower) || (p.category || '').toLowerCase().includes(lower));
    $('#plist', view).innerHTML = rows.length ? rows.map((p) => {
      const left = p.track_stock ? stockLeft(p) : null;
      const out = p.track_stock && left <= 0;
      return `<button class="row pick ${out ? 'disabled' : ''}" data-id="${p.id}">
        <div class="row-icon ${out ? 'c-red' : 'c-blue'}">${ic(p.kind === 'service' ? 'hand-sparkles' : 'box')}</div>
        <div class="row-main"><b>${esc(p.name)}</b><small>${esc(money(p.sell_price, cur))}</small></div>
        <div class="row-end">${p.track_stock ? `<span class="stock-pill ${out ? 'lvl-danger' : left <= p.low_stock ? 'lvl-warn' : 'lvl-good'}">${esc(num(left))}</span>` : ''}<span class="add-mark">${ic('plus')}</span></div></button>`;
    }).join('') : (products.length ? emptyState('magnifying-glass', t('no_results')) : '');
    $$('.pick', view).forEach((b) => (b.onclick = () => add(products.find((p) => p.id === b.dataset.id))));
  }

  function drawCart() {
    const box = $('#cart', view);
    box.innerHTML = cart.length ? cart.map((l) => `
      <div class="cart-line" data-k="${l.key}">
        <div class="cl-name"><b>${esc(l.name)}</b>
          <input class="cl-price" type="number" inputmode="decimal" step="any" value="${l.price}" data-price aria-label="price"></div>
        <div class="qty"><button type="button" data-dec>−</button><input type="number" inputmode="decimal" step="any" value="${l.qty}" data-qty><button type="button" data-inc>+</button></div>
        <div class="cl-total">${esc(num(l.qty * l.price))}</div>
        <button class="icon-btn" data-del aria-label="remove">${ic('xmark')}</button>
      </div>`).join('') : `<p class="muted center-text">${esc(t('cart_empty'))}</p>`;
    $('#subtotal', view).textContent = money(subtotal(), cur);
    $('#checkout', view).disabled = !cart.length;
    $$('.cart-line', box).forEach((row) => {
      const l = cart.find((x) => x.key === +row.dataset.k);
      const setQty = (v) => {
        v = Math.max(0, v);
        if (l.track && v > l.stock) { toast(t('err_insufficient', { d: `${l.name} (${num(l.stock)})` }), 'danger'); v = l.stock; }
        if (v === 0) cart.splice(cart.indexOf(l), 1); else l.qty = v;
        redraw();
      };
      $('[data-inc]', row).onclick = () => setQty(l.qty + 1);
      $('[data-dec]', row).onclick = () => setQty(l.qty - 1);
      $('[data-qty]', row).onchange = (e) => setQty(toNum(e.target.value));
      $('[data-price]', row).onchange = (e) => { l.price = toNum(e.target.value); redraw(); };
      $('[data-del]', row).onclick = () => { cart.splice(cart.indexOf(l), 1); drawCart(); drawList(); };
    });
  }

  view.innerHTML = `
    ${pageHead(t('nav_new_sale'), `<button class="btn btn-ghost sm" id="customItem">${ic('pen')} ${esc(t('custom_item'))}</button>`)}
    ${products.length ? `<div class="search-bar">${ic('magnifying-glass')}<input id="q" type="search" placeholder="${esc(t('search'))}"></div>` : ''}
    <div id="plist"></div>
    ${!products.length ? emptyState('box-open', t('no_products'), hasModule(biz, 'inventory') ? t('no_products_sub') : t('custom_item_hint')) : ''}
    <div class="card cart-card"><div class="card-title">${ic('cart-shopping')} ${esc(t('cart'))}</div><div id="cart"></div></div>
    <div class="checkout-bar"><div><small>${esc(t('subtotal'))}</small><b id="subtotal"></b></div>
      <button class="btn btn-gold" id="checkout">${ic('check')} ${esc(t('checkout'))}</button></div>`;
  const qi = $('#q', view);
  if (qi) qi.oninput = debounce((e) => { q = e.target.value; drawList(); }, 150);
  $('#customItem', view).onclick = () => customItem();
  $('#checkout', view).onclick = () => checkout();
  drawList();
  drawCart();

  function customItem() {
    sheet(t('custom_item'), `<form id="ciForm">
      ${field({ label: t('name'), name: 'name', required: true })}
      <div class="fg-row">${field({ label: t('price'), name: 'price', type: 'number', required: true })}${field({ label: t('qty'), name: 'qty', type: 'number', value: 1, required: true })}</div>
      <button class="btn btn-gold block" type="submit">${ic('plus')} ${esc(t('add'))}</button></form>`, (body, close) => {
      $('#ciForm', body).onsubmit = (e) => {
        e.preventDefault();
        const f = formData(e.target);
        cart.push({ key: ++seq, product_id: null, name: f.name, qty: toNum(f.qty) || 1, price: toNum(f.price), cost: 0, track: false });
        close(); drawCart();
      };
    });
  }

  function checkout() {
    const sub = subtotal();
    sheet(t('checkout'), `
      <form id="coForm">
        ${kv(t('subtotal'), esc(money(sub, cur)))}
        ${field({ label: t('discount'), name: 'discount', type: 'number', value: '' })}
        ${kv(t('total'), `<span id="coTotal">${esc(money(sub, cur))}</span>`, 'c-gold')}
        ${customers.length || hasModule(biz, 'customers') ? selectField({ label: t('customer'), name: 'customer_id', options: [{ value: '', label: t('walk_in') }, ...customers.map((c) => ({ value: c.id, label: c.name }))] }) : ''}
        ${field({ label: t('amount_paid'), name: 'paid', type: 'number', value: sub })}
        <div class="kv" id="coBal" hidden><span>${esc(t('balance'))} (${esc(t('on_credit'))})</span><b class="c-red" id="coBalV"></b></div>
        ${selectField({ label: t('method'), name: 'method', options: methodOptions() })}
        ${field({ label: t('note'), name: 'note' })}
        <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('complete_sale'))}</button>
      </form>`, (body, close) => {
      const form = $('#coForm', body);
      let paidTouched = false;
      const recalc = () => {
        const disc = Math.min(Math.max(toNum(form.discount.value), 0), sub);
        const total = sub - disc;
        $('#coTotal', body).textContent = money(total, cur);
        if (!paidTouched) form.paid.value = total;
        const bal = total - Math.min(toNum(form.paid.value), total);
        $('#coBal', body).hidden = bal < 0.009;
        $('#coBalV', body).textContent = money(bal, cur);
      };
      form.discount.oninput = recalc;
      form.paid.oninput = () => { paidTouched = true; recalc(); };
      form.onsubmit = async (e) => {
        e.preventDefault();
        const f = formData(form);
        try {
          const disc = toNum(f.discount);
          const res = await createSale(biz.id, {
            items: cart.map((l) => ({ product_id: l.product_id, name: l.name, qty: l.qty, price: l.price, cost: l.cost, track: l.track })),
            discount: disc, paid: f.paid === '' ? undefined : toNum(f.paid), customer_id: f.customer_id || null, method: f.method, note: f.note
          });
          close();
          toast(t('sale_saved'), 'good');
          await afterChange();
          await showReceipt(biz, res.id, () => {});
          cart.length = 0;
          const fresh = await listProducts(biz.id);
          products.splice(0, products.length, ...fresh);
          drawCart(); drawList();
        } catch (err) { toast(errText(err), 'danger'); }
      };
    });
  }
}
