// dashboard.js - muhtasari wa biashara (unabadilika kulingana na modules na aina ya biashara)
import { t, fmtDate, num, fmtDay } from '../i18n/index.js';
import { esc, ic, money, emptyState } from '../ui.js';
import { dateStr, addDays, val } from '../db/index.js';
import { summary, stockStats, debtTotals, dailySeries, recentActivity, productionTotals, countRows } from '../data.js';
import { listAlerts, alertText } from '../alerts.js';
import { hasModule, productionOf, typeInfo } from '../templates.js';
import { nav } from '../state.js';

const LVL_ICON = { danger: 'triangle-exclamation', warn: 'circle-exclamation', good: 'circle-check' };
export const alertCard = (a, biz, extra = '') => `
  <div class="alert-card lvl-${a.level}">
    <span class="ac-icon">${ic(LVL_ICON[a.level])}</span>
    <div class="ac-body"><div class="ac-text">${esc(alertText(a, biz))}</div>${extra}</div>
  </div>`;

export default async function dashboard(view, { biz }) {
  const has = (k) => hasModule(biz, k);
  const cur = biz.currency;
  const today = dateStr();
  const day = await summary(biz.id, today, today);
  const stock = has('inventory') ? await stockStats(biz.id) : null;
  const debt = has('debts') ? await debtTotals(biz.id) : null;
  const series = has('sales') ? await dailySeries(biz.id, dateStr(addDays(new Date(), -6)), today) : null;
  const recent = await recentActivity(biz.id, 6);
  const alerts = (await listAlerts(biz.id)).slice(0, 3);
  const prod = has('production') ? productionOf(biz) : null;

  const cards = [];
  if (has('sales')) cards.push({ ic: 'coins', c: 'green', label: 'stat_sales', v: money(day.revenue, cur), tag: t('n_sales', { n: day.salesCount }) });
  if (has('expenses')) cards.push({ ic: 'wallet', c: 'red', label: 'stat_expenses', v: money(day.expenses, cur) });
  if (has('sales') || has('expenses')) cards.push({ ic: 'scale-balanced', c: day.net >= 0 ? 'gold' : 'red', label: 'stat_profit', v: money(day.net, cur), vc: day.net >= 0 ? 'pos' : 'neg' });
  if (stock) cards.push({ ic: 'boxes-stacked', c: 'blue', label: 'stat_stock_value', v: money(stock.value, cur),
    tag: stock.low + stock.out > 0 ? t('n_low', { n: stock.low + stock.out }) : '', tagc: 'red' });
  if (debt) {
    cards.push({ ic: 'hand-holding-dollar', c: 'purple', label: 'stat_owed_to_me', v: money(debt.owedToMe, cur) });
    if (has('suppliers') || has('purchases')) cards.push({ ic: 'file-invoice-dollar', c: 'red', label: 'stat_i_owe', v: money(debt.iOwe, cur) });
  }

  const quick = [
    has('sales') && ['/sales/new', 'cart-plus', 'nav_new_sale'],
    has('purchases') && ['/purchases/new', 'truck', 'nav_purchases'],
    has('expenses') && ['/expenses?new=1', 'wallet', 'nav_add_expense'],
    has('inventory') && ['/products?new=1', 'box', 'nav_add_product'],
    prod && ['/production', typeInfo(biz.type).icon, 'nav_production']
  ].filter(Boolean);

  // uzalishaji
  let prodHtml = '';
  if (prod) {
    const tot = Object.fromEntries((await productionTotals(biz.id, today, today)).map((r) => [r.metric, r.value]));
    const count = await val('SELECT COALESCE(SUM(count),0) FROM production_units WHERE business_id = ? AND active = 1', [biz.id]);
    const lost = await val(`SELECT COALESCE(SUM(value),0) FROM production_logs WHERE business_id = ? AND metric = 'loss'`, [biz.id]);
    const isArea = prod.count === 'acres';
    const items = [[t('count_' + prod.count), num(isArea ? count : Math.max(0, count - lost), 0)]];
    for (const [key, name] of prod.metrics) items.push([t('m_' + name), num(tot[key] || 0, 1)]);
    prodHtml = `<div class="card"><div class="card-title">${ic(typeInfo(biz.type).icon)} ${esc(t('production_today'))}</div>
      <div class="mini-stats">${items.map(([l, v]) => `<div><b>${v}</b><small>${esc(l)}</small></div>`).join('')}</div></div>`;
  }

  const max = series ? Math.max(1, ...series.map((s) => s.v)) : 1;
  view.innerHTML = `
    <div class="greet"><div class="greet-sub">${esc(t('type_' + biz.type))}${biz.location ? ' • ' + esc(biz.location) : ''}</div>
      <h1>${esc(biz.name)}</h1><div class="greet-date">${ic('calendar-day')} ${esc(fmtDate(today))}</div></div>

    ${quick.length ? `<div class="quick">${quick.map(([p, i, l]) => `<a class="qa" href="#${p}">${ic(i)}<span>${esc(t(l))}</span></a>`).join('')}</div>` : ''}

    ${alerts.length ? `<div class="card"><div class="card-title">${ic('bell')} ${esc(t('nav_alerts'))}<a class="link" href="#/alerts">${esc(t('view_all'))}</a></div>
      ${alerts.map((a) => alertCard(a, biz)).join('')}</div>` : ''}

    <div class="stat-grid">${cards.map((c) => `
      <div class="stat-card"><div class="sc-glow bg-${c.c}"></div>
        <div class="sc-icon bg-${c.c}-dim c-${c.c}">${ic(c.ic)}</div>
        <div class="sc-label">${esc(t(c.label))}</div>
        <div class="sc-value ${c.vc || ''}">${esc(c.v)}</div>
        ${c.tag ? `<span class="sc-tag ${c.tagc ? 'lvl-danger' : ''}">${esc(c.tag)}</span>` : ''}
      </div>`).join('')}</div>

    ${prodHtml}

    ${series ? `<div class="card"><div class="card-title">${ic('chart-column')} ${esc(t('sales_7d'))}</div>
      <div class="bars">${series.map((s) => `<div class="bar-col"><div class="bar" style="height:${Math.max(3, (s.v / max) * 100)}%" title="${esc(money(s.v, cur))}"></div><small>${esc(fmtDay(s.d).split(' ')[0])}</small></div>`).join('')}</div></div>` : ''}

    <div class="card"><div class="card-title">${ic('clock-rotate-left')} ${esc(t('recent_activity'))}</div>
      ${recent.length ? recent.map((r) => `
        <div class="row"><div class="row-icon ${r.t === 'sale' ? 'c-green' : r.t === 'expense' ? 'c-red' : 'c-blue'}">${ic(r.t === 'sale' ? 'circle-plus' : r.t === 'expense' ? 'circle-minus' : 'truck')}</div>
          <div class="row-main"><b>${esc(r.t === 'sale' ? t('sale_no', { n: r.ref }) : r.t === 'expense' ? t('cat_' + r.ref) : t('purchase'))}</b><small>${esc(fmtDate(r.created_at, true))}</small></div>
          <div class="row-amt ${r.t === 'sale' ? 'pos' : 'neg'}">${r.t === 'sale' ? '+' : '−'} ${esc(num(r.amount))}</div></div>`).join('')
        : emptyState('inbox', t('no_activity'))}
    </div>`;
  void nav; void countRows;
}
