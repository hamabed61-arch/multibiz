// sales.js - orodha ya mauzo + risiti
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, money, emptyState, pageHead, confirmBox } from '../ui.js';
import { listSales, getSale, voidSale } from '../data.js';
import { shareText } from '../share.js';
import { afterChange } from '../state.js';
import { rangeFor, rangeTabs, onTabs, fab, kv, errText } from './_shared.js';

export function receiptText(biz, s) {
  const lines = s.items.map((i) => `${i.name} x${num(i.qty)} @ ${num(i.unit_price)} = ${num(i.qty * i.unit_price)}`);
  return [
    `${biz.name}${biz.phone ? ' • ' + biz.phone : ''}`,
    `${t('receipt')} #${s.receipt_no} — ${fmtDate(s.created_at, true)}`,
    s.customer_name ? `${t('customer')}: ${s.customer_name}` : '',
    '-----------------',
    ...lines,
    '-----------------',
    s.discount > 0 ? `${t('discount')}: ${num(s.discount)}` : '',
    `${t('total')}: ${biz.currency} ${num(s.total)}`,
    `${t('paid')}: ${biz.currency} ${num(s.paid)}`,
    s.total - s.paid > 0.009 ? `${t('balance')}: ${biz.currency} ${num(s.total - s.paid)}` : '',
    t('thank_you')
  ].filter(Boolean).join('\n');
}

export async function showReceipt(biz, id, onChange) {
  const s = await getSale(id);
  const bal = s.total - s.paid;
  sheet(`${t('receipt')} #${s.receipt_no}`, `
    <div class="receipt">
      <div class="rc-head"><b>${esc(biz.name)}</b><small>${esc(fmtDate(s.created_at, true))}${s.customer_name ? ' • ' + esc(s.customer_name) : ''}</small>
        ${s.status === 'void' ? `<span class="badge-pill lvl-danger">${esc(t('voided'))}</span>` : ''}</div>
      ${s.items.map((i) => `<div class="rc-line"><span>${esc(i.name)} <small>× ${esc(num(i.qty))}</small></span><b>${esc(num(i.qty * i.unit_price))}</b></div>`).join('')}
      <div class="rc-sep"></div>
      ${s.discount > 0 ? kv(t('discount'), '− ' + esc(num(s.discount))) : ''}
      ${kv(t('total'), esc(money(s.total, biz.currency)), 'c-gold')}
      ${kv(t('paid') + ' (' + t('method_' + s.method) + ')', esc(money(s.paid, biz.currency)))}
      ${bal > 0.009 ? kv(t('balance'), esc(money(bal, biz.currency)), 'c-red') : ''}
    </div>
    <div class="btn-row wrap">
      <button class="btn btn-gold" id="rcShare">${ic('share-nodes')} ${esc(t('share'))}</button>
      ${s.status === 'ok' ? `<button class="btn btn-danger" id="rcVoid">${ic('rotate-left')} ${esc(t('void_sale'))}</button>` : ''}
    </div>`, (body, close) => {
    $('#rcShare', body).onclick = async () => { const r = await shareText(t('receipt'), receiptText(biz, s)); if (r === 'copied') toast(t('copied'), 'good'); };
    const v = $('#rcVoid', body);
    if (v) v.onclick = async () => {
      if (!(await confirmBox(t('void_confirm')))) return;
      try { await voidSale(id); toast(t('saved'), 'good'); close(); await afterChange(); onChange && onChange(); } catch (e) { toast(errText(e), 'danger'); }
    };
  });
}

export default async function sales(view, { biz }) {
  let range = 'today';
  async function draw() {
    const [from, to] = rangeFor(range);
    const list = await listSales(biz.id, from, to);
    const ok = list.filter((s) => s.status === 'ok');
    const total = ok.reduce((a, s) => a + s.total, 0);
    const credit = ok.reduce((a, s) => a + (s.total - s.paid), 0);
    view.innerHTML = `
      ${pageHead(t('nav_sales'))}
      ${rangeTabs(range)}
      <div class="totals"><div><small>${esc(t('total'))}</small><b class="c-green">${esc(money(total, biz.currency))}</b></div>
        <div><small>${esc(t('n_sales', { n: ok.length }))}</small><b>${ok.length}</b></div>
        <div><small>${esc(t('on_credit'))}</small><b class="${credit > 0 ? 'c-red' : ''}">${esc(num(credit))}</b></div></div>
      ${list.length ? list.map((s) => `
        <button class="row sale-row ${s.status === 'void' ? 'void' : ''}" data-id="${s.id}">
          <div class="row-icon c-green">${ic('receipt')}</div>
          <div class="row-main"><b>${esc(t('sale_no', { n: s.receipt_no }))}${s.customer_name ? ' • ' + esc(s.customer_name) : ''}</b><small>${esc(fmtDate(s.created_at, true))}</small></div>
          <div class="row-end"><b class="row-amt pos">${esc(num(s.total))}</b>
            ${s.status === 'void' ? `<small class="c-red">${esc(t('voided'))}</small>` : s.total - s.paid > 0.009 ? `<small class="c-red">${esc(t('on_credit'))}</small>` : ''}</div>
        </button>`).join('') : emptyState('receipt', t('no_sales'))}
      ${fab('fab', 'cart-plus')}`;
    onTabs(view, (k) => { range = k; draw(); });
    $$('.sale-row', view).forEach((b) => (b.onclick = () => showReceipt(biz, b.dataset.id, draw)));
    $('#fab', view).onclick = () => { location.hash = '#/sales/new'; };
  }
  await draw();
}
