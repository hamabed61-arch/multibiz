// reports.js - ripoti: mauzo, matumizi, faida, cash flow, stock, madeni, uzalishaji
import { t, num, fmtDay } from '../i18n/index.js';
import { $, esc, ic, money, unitLabel } from '../ui.js';
import { summary, dailySeries, topProducts, expenseBreakdown, stockStats, debtTotals, productionTotals, listProducts } from '../data.js';
import { hasModule, productionOf } from '../templates.js';
import { rangeFor, rangeTabs, onTabs, kv } from './_shared.js';

export default async function reports(view, { biz }) {
  let range = 'week';
  const cur = biz.currency;
  const has = (k) => hasModule(biz, k);
  async function draw() {
    const [from, to] = rangeFor(range);
    const s = await summary(biz.id, from, to);
    const series = has('sales') && range !== 'year' && range !== 'today' ? await dailySeries(biz.id, from, to) : null;
    const top = has('sales') ? await topProducts(biz.id, from, to) : [];
    const exp = has('expenses') ? await expenseBreakdown(biz.id, from, to) : [];
    const stock = has('inventory') ? await stockStats(biz.id) : null;
    const lowList = stock ? (await listProducts(biz.id)).filter((p) => p.track_stock && p.has_moves && p.stock <= p.low_stock) : [];
    const debt = has('debts') ? await debtTotals(biz.id) : null;
    const prod = has('production') ? productionOf(biz) : null;
    const ptot = prod ? Object.fromEntries((await productionTotals(biz.id, from, to)).map((r) => [r.metric, r.value])) : {};
    const max = series ? Math.max(1, ...series.map((x) => x.v)) : 1;
    const margin = s.revenue > 0 ? (s.net / s.revenue) * 100 : 0;

    view.innerHTML = `
      <div class="page-head"><h2>${esc(t('nav_reports'))}</h2></div>
      ${rangeTabs(range, ['today', 'week', 'month', 'year'])}

      <div class="card"><div class="card-title">${ic('scale-balanced')} ${esc(t('profit_loss'))}</div>
        ${kv(t('rep_revenue'), esc(money(s.revenue, cur)))}
        ${kv(t('rep_cogs'), '− ' + esc(money(s.cogs, cur)))}
        ${kv(t('rep_gross'), esc(money(s.gross, cur)), s.gross >= 0 ? 'c-green' : 'c-red')}
        ${kv(t('stat_expenses'), '− ' + esc(money(s.expenses, cur)))}
        <div class="rc-sep"></div>
        ${kv(t('rep_net'), esc(money(s.net, cur)), s.net >= 0 ? 'c-green big' : 'c-red big')}
        ${s.revenue > 0 ? `<small class="muted">${esc(t('rep_margin'))}: ${esc(num(margin, 1))}%</small>` : ''}
      </div>

      <div class="card"><div class="card-title">${ic('money-bill-transfer')} ${esc(t('cash_flow'))}</div>
        ${kv(t('cash_in'), esc(money(s.cashIn, cur)), 'c-green')}${kv(t('cash_out'), esc(money(s.cashOut, cur)), 'c-red')}
        <div class="rc-sep"></div>${kv(t('cash_net'), esc(money(s.cashFlow, cur)), s.cashFlow >= 0 ? 'c-green' : 'c-red')}
        ${s.purchases > 0 ? kv(t('nav_purchases'), esc(money(s.purchases, cur))) : ''}
      </div>

      ${series ? `<div class="card"><div class="card-title">${ic('chart-column')} ${esc(t('daily_sales'))}</div>
        <div class="bars ${series.length > 14 ? 'dense' : ''}">${series.map((x) => `<div class="bar-col"><div class="bar" style="height:${Math.max(3, (x.v / max) * 100)}%" title="${esc(money(x.v, cur))}"></div>${series.length <= 14 ? `<small>${esc(fmtDay(x.d).split(' ')[0])}</small>` : ''}</div>`).join('')}</div></div>` : ''}

      ${top.length ? `<div class="card"><div class="card-title">${ic('trophy')} ${esc(t('top_products'))}</div>
        ${top.map((p, i) => `<div class="row slim"><div class="row-rank">${i + 1}</div><div class="row-main"><b>${esc(p.name)}</b><small>× ${esc(num(p.qty))}</small></div><div class="row-amt">${esc(num(p.revenue))}</div></div>`).join('')}</div>` : ''}

      ${exp.length ? `<div class="card"><div class="card-title">${ic('receipt')} ${esc(t('expense_breakdown'))}</div>
        ${exp.map((e) => `<div class="pct-row"><div class="pct-label"><span>${esc(t('cat_' + e.category))}</span><b>${esc(num(e.total))}</b></div>
          <div class="pct-track"><div class="pct-fill" style="width:${Math.min(100, (e.total / Math.max(1, s.expenses)) * 100)}%"></div></div></div>`).join('')}</div>` : ''}

      ${stock ? `<div class="card"><div class="card-title">${ic('boxes-stacked')} ${esc(t('stock_valuation'))}</div>
        ${kv(t('stock_at_cost'), esc(money(stock.value, cur)))}${kv(t('stock_at_retail'), esc(money(stock.retail, cur)))}
        ${kv(t('expected_profit'), esc(money(stock.retail - stock.value, cur)), 'c-green')}
        ${lowList.length ? `<div class="card-title sm">${esc(t('filter_low'))}</div>${lowList.map((p) => `<div class="row slim"><div class="row-main"><b>${esc(p.name)}</b></div><span class="stock-pill lvl-danger">${esc(num(p.stock))} ${esc(unitLabel(p.unit))}</span></div>`).join('')}` : ''}
      </div>` : ''}

      ${debt ? `<div class="card"><div class="card-title">${ic('hand-holding-dollar')} ${esc(t('nav_debts'))}</div>
        ${kv(t('stat_owed_to_me'), esc(money(debt.owedToMe, cur)), 'c-purple')}${kv(t('stat_i_owe'), esc(money(debt.iOwe, cur)), 'c-red')}</div>` : ''}

      ${prod ? `<div class="card"><div class="card-title">${ic('seedling')} ${esc(t('nav_production'))}</div>
        ${prod.metrics.map(([k, n]) => kv(t('m_' + n), esc(num(ptot[k] || 0, 1)))).join('')}</div>` : ''}`;
    onTabs(view, (k) => { range = k; draw(); });
  }
  await draw();
}
