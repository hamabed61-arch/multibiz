// about.js - Kuhusu app: poster (publi./brand/about.jpg) + maelezo mafupi
import { t } from '../i18n/index.js';
import { esc, pageHead, brandLogo } from '../ui.js';

export default async function about(view) {
  view.innerHTML = `
    ${pageHead(t('nav_about'))}
    <div class="about-poster"><img src="./brand/about.jpg" alt="" onerror="this.parentNode.remove()"></div>
    <div class="card center-text">
      ${brandLogo('big')}
      <h3 class="brand-title">Multi<span>Biz</span></h3>
      <p class="muted">${esc(t('app_tagline'))}</p>
      <p class="muted">${esc(t('about_version', { v: '1.0.0' }))} • ${esc(t('app_offline'))}</p>
    </div>`;
}
