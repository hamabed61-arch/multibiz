// products.js - bidhaa/huduma na stock
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, selectField, formData, toNum, money, emptyState, pageHead, debounce, confirmBox, unitLabel } from '../ui.js';
import { listProducts, getProduct, saveProduct, archiveProduct, setStock, stockMovements } from '../data.js';
import { hasModule, UNITS, typeInfo } from '../templates.js';
import { dateStr } from '../db/index.js';
import { afterChange } from '../state.js';
import { fab, errText, kv } from './_shared.js';

const SERVICE_TYPES = ['salon', 'consultancy'];

export default async function products(view, { biz, params }) {
  let q = '';
  let filter = 'all';
  const cur = biz.currency;
  const expiryOn = hasModule(biz, 'expiry');

  async function draw() {
    const list = await listProducts(biz.id, { q });
    const today = dateStr();
    const flag = (p) => {
      if (!p.track_stock) return null;
      if (p.has_moves && p.stock <= 0) return 'out';
      if (p.has_moves && p.stock <= p.low_stock) return 'low';
      return null;
    };
    const expiring = (p) => expiryOn && p.expiry_date && p.expiry_date <= dateStr(new Date(Date.now() + 30 * 864e5));
    const rows = list.filter((p) => filter === 'all' || (filter === 'low' && flag(p)) || (filter === 'expiry' && expiring(p)));
    const lowCount = list.filter((p) => flag(p)).length;

    $('#plist', view).innerHTML = rows.length ? rows.map((p) => {
      const f = flag(p);
      const exp = expiring(p) ? (p.expiry_date < today ? 'lvl-danger' : 'lvl-warn') : '';
      return `<button class="row product-row" data-id="${p.id}">
        <div class="row-icon ${f ? 'c-red' : 'c-blue'}">${ic(p.kind === 'service' ? 'hand-sparkles' : 'box')}</div>
        <div class="row-main"><b>${esc(p.name)}</b>
          <small>${esc(money(p.sell_price, cur))}${p.category ? ' • ' + esc(p.category) : ''}${expiryOn && p.expiry_date ? ` • <span class="${exp}">${esc(fmtDate(p.expiry_date))}</span>` : ''}</small></div>
        <div class="row-end">${p.track_stock
          ? `<span class="stock-pill ${f ? 'lvl-danger' : 'lvl-good'}">${esc(num(p.stock))} ${esc(unitLabel(p.unit))}</span>${f ? `<small class="c-red">${esc(t(f === 'out' ? 'out_of_stock' : 'low_stock'))}</small>` : ''}`
          : `<span class="stock-pill">${esc(t('service'))}</span>`}</div>
      </button>`;
    }).join('') : emptyState('box-open', t('no_products'), t('no_products_sub'));
    $$('.product-row', view).forEach((b) => (b.onclick = () => openProduct(b.dataset.id)));
    $$('[data-filter]', view).forEach((b) => b.classList.toggle('active', b.dataset.filter === filter));
    const lc = $('#lowCount', view);
    if (lc) { lc.textContent = lowCount || ''; lc.hidden = !lowCount; }
  }

  view.innerHTML = `
    ${pageHead(t('nav_products'))}
    <div class="search-bar">${ic('magnifying-glass')}<input id="q" type="search" placeholder="${esc(t('search'))}"></div>
    <div class="tabs">
      <button class="tab active" data-filter="all">${esc(t('filter_all'))}</button>
      <button class="tab" data-filter="low">${esc(t('filter_low'))} <b class="badge inline lvl-danger" id="lowCount"></b></button>
      ${expiryOn ? `<button class="tab" data-filter="expiry">${esc(t('filter_expiry'))}</button>` : ''}
    </div>
    <div id="plist"></div>${fab()}`;
  $('#q', view).oninput = debounce((e) => { q = e.target.value; draw(); }, 200);
  $$('[data-filter]', view).forEach((b) => (b.onclick = () => { filter = b.dataset.filter; draw(); }));
  $('#fab', view).onclick = () => productForm(biz, null, () => draw());
  await draw();
  if (params.get('new')) productForm(biz, null, () => draw());

  async function openProduct(id) {
    const p = await getProduct(id);
    const moves = await stockMovements(id);
    sheet(p.name, `
      ${kv(t('sell_price'), esc(money(p.sell_price, cur)))}
      ${p.track_stock ? kv(t('buy_price'), esc(money(p.buy_price, cur))) : ''}
      ${p.track_stock ? kv(t('in_stock'), `${esc(num(p.stock))} ${esc(unitLabel(p.unit))}`, p.stock <= p.low_stock ? 'c-red' : 'c-green') : ''}
      ${p.track_stock ? kv(t('low_stock_level'), esc(num(p.low_stock))) : ''}
      ${expiryOn && p.expiry_date ? kv(t('expiry_date'), esc(fmtDate(p.expiry_date))) : ''}
      <div class="btn-row wrap">
        <button class="btn btn-gold" id="pEdit">${ic('pen')} ${esc(t('edit'))}</button>
        ${p.track_stock ? `<button class="btn btn-ghost" id="pAdj">${ic('sliders')} ${esc(t('adjust_stock'))}</button>` : ''}
        <button class="btn btn-danger" id="pDel">${ic('box-archive')} ${esc(t('archive'))}</button>
      </div>
      ${p.track_stock && moves.length ? `<div class="card-title sm">${esc(t('stock_history'))}</div>` + moves.slice(0, 10).map((m) => `
        <div class="row slim"><div class="row-main"><b>${esc(t('mv_' + m.type))}</b><small>${esc(fmtDate(m.created_at, true))}</small></div>
        <div class="row-amt ${m.qty >= 0 ? 'pos' : 'neg'}">${m.qty >= 0 ? '+' : ''}${esc(num(m.qty))}</div></div>`).join('') : ''}`,
    (body, close) => {
      $('#pEdit', body).onclick = () => { close(); productForm(biz, p, () => draw()); };
      const adj = $('#pAdj', body);
      if (adj) adj.onclick = () => { close(); adjustForm(biz, p, () => draw()); };
      $('#pDel', body).onclick = async () => {
        if (await confirmBox(t('archive_confirm', { name: p.name }))) { await archiveProduct(id); close(); await afterChange(); draw(); }
      };
    });
  }
}

export function productForm(biz, p, onDone) {
  const isNew = !p;
  const expiryOn = hasModule(biz, 'expiry');
  const kind0 = p ? p.kind : (SERVICE_TYPES.includes(biz.type) ? 'service' : 'product');
  sheet(isNew ? t('add_product') : t('edit_product'), `
    <form id="pForm">
      ${field({ label: t('name'), name: 'name', value: p?.name, required: true })}
      ${selectField({ label: t('kind'), name: 'kind', value: kind0, options: [{ value: 'product', label: t('kind_product') }, { value: 'service', label: t('kind_service') }] })}
      <div class="fg-row">
        ${field({ label: t('category'), name: 'category', value: p?.category })}
        ${selectField({ label: t('unit'), name: 'unit', value: p?.unit || 'pcs', options: UNITS.map((u) => ({ value: u, label: t('unit_' + u) })) })}
      </div>
      <div class="fg-row">
        ${field({ label: t('sell_price'), name: 'sell_price', type: 'number', value: p?.sell_price ?? '', required: true })}
        <div data-stock>${field({ label: t('buy_price'), name: 'buy_price', type: 'number', value: p?.buy_price ?? '' })}</div>
      </div>
      <div data-stock class="fg-row">
        ${isNew ? field({ label: t('opening_qty'), name: 'opening_qty', type: 'number', value: '' }) : ''}
        ${field({ label: t('low_stock_level'), name: 'low_stock', type: 'number', value: p?.low_stock ?? 5 })}
      </div>
      ${expiryOn ? `<div data-stock>${field({ label: t('expiry_date'), name: 'expiry_date', type: 'date', value: p?.expiry_date })}</div>` : ''}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button>
    </form>`, (body, close) => {
    const form = $('#pForm', body);
    const sync = () => $$('[data-stock]', form).forEach((el) => (el.hidden = form.kind.value === 'service'));
    form.kind.onchange = sync;
    sync();
    form.onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(form);
      try {
        await saveProduct(biz.id, {
          name: f.name, kind: f.kind, category: f.category, unit: f.unit,
          sell_price: toNum(f.sell_price), buy_price: toNum(f.buy_price), low_stock: f.low_stock === '' ? 5 : toNum(f.low_stock),
          opening_qty: toNum(f.opening_qty), expiry_date: f.expiry_date || null
        }, p?.id);
        toast(t('saved'), 'good');
        close();
        await afterChange();
        onDone && onDone();
      } catch (err) { toast(errText(err), 'danger'); }
    };
  });
}

function adjustForm(biz, p, onDone) {
  sheet(t('adjust_stock'), `
    <p class="muted">${esc(p.name)} — ${esc(t('in_stock'))}: <b>${esc(num(p.stock))}</b></p>
    <form id="aForm">
      ${field({ label: t('new_count'), name: 'qty', type: 'number', value: p.stock, required: true })}
      ${field({ label: t('note'), name: 'note', placeholder: t('adjust_reason') })}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button>
    </form>`, (body, close) => {
    $('#aForm', body).onsubmit = async (e) => {
      e.preventDefault();
      const f = formData(e.target);
      await setStock(biz.id, p.id, toNum(f.qty), f.note);
      toast(t('saved'), 'good');
      close();
      await afterChange();
      onDone && onDone();
    };
  });
}
