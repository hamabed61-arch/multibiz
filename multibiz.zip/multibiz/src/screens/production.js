// production.js - kuku, mifugo, samaki, kilimo: makundi/mashamba/mabwawa na kumbukumbu za kila siku
import { t, num, fmtDate } from '../i18n/index.js';
import { $, $$, esc, ic, sheet, toast, field, textArea, formData, toNum, emptyState, pageHead, confirmBox } from '../ui.js';
import { listUnits, saveUnit, deleteUnit, addLog, unitLogs } from '../data.js';
import { productionOf, typeInfo } from '../templates.js';
import { dateStr } from '../db/index.js';
import { afterChange } from '../state.js';
import { fab, kv } from './_shared.js';

export default async function production(view, { biz }) {
  const prod = productionOf(biz);
  const isArea = prod.count === 'acres';
  const icon = typeInfo(biz.type).icon;
  const alive = (u) => (isArea ? u.count : Math.max(0, u.count - u.lost));

  async function draw() {
    const units = await listUnits(biz.id);
    view.innerHTML = `
      ${pageHead(t('nav_production'))}
      ${units.length ? units.map((u) => `
        <div class="card unit ${u.active ? '' : 'void'}" data-id="${u.id}">
          <div class="unit-head"><div class="row-icon c-green">${ic(icon)}</div>
            <div class="row-main"><b>${esc(u.name)}</b><small>${esc(t('unit_' + prod.unit))} • ${esc(fmtDate(u.started_at))}</small></div>
            <div class="row-end"><b>${esc(num(alive(u), 0))}</b><small>${esc(t('count_' + prod.count))}</small></div></div>
          <div class="mini-stats">
            ${prod.metrics.filter(([key]) => key !== 'feed').map(([key, name]) => `<div><b>${esc(num(key === 'produce' ? u.produced : u.lost, 1))}</b><small>${esc(t('m_' + name))}</small></div>`).join('')}
          </div>
          <div class="btn-row"><button class="btn btn-gold" data-log="${u.id}">${ic('pen-to-square')} ${esc(t('log_today'))}</button>
            <button class="btn btn-ghost" data-more="${u.id}">${ic('ellipsis')}</button></div>
        </div>`).join('') : emptyState(icon, t('no_units_' + prod.unit), t('no_units_sub'))}
      ${fab()}`;
    $('#fab', view).onclick = () => unitForm(null);
    $$('[data-log]', view).forEach((b) => (b.onclick = () => logForm(units.find((u) => u.id === b.dataset.log))));
    $$('[data-more]', view).forEach((b) => (b.onclick = () => detail(units.find((u) => u.id === b.dataset.more))));
  }

  function unitForm(u) {
    sheet(u ? t('edit') : t('add_unit_' + prod.unit), `<form id="unForm">
      ${field({ label: t('name'), name: 'name', value: u?.name, required: true })}
      <div class="fg-row">${field({ label: t('count_' + prod.count), name: 'count', type: 'number', value: u?.count ?? '', required: true })}
        ${field({ label: t('start_date'), name: 'started_at', type: 'date', value: u?.started_at || dateStr() })}</div>
      ${textArea({ label: t('note'), name: 'note', value: u?.note })}
      ${u ? `<label class="chip-toggle ${u.active ? 'on' : ''}"><input type="checkbox" name="active" ${u.active ? 'checked' : ''}> ${esc(t('active'))}</label>` : ''}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
      $('#unForm', body).onsubmit = async (e) => {
        e.preventDefault();
        const f = formData(e.target);
        await saveUnit(biz.id, { name: f.name, count: toNum(f.count), started_at: f.started_at, note: f.note, active: u ? !!f.active : true }, u?.id);
        toast(t('saved'), 'good'); close(); await afterChange(); draw();
      };
    });
  }

  function logForm(u) {
    sheet(`${t('log_today')} — ${u.name}`, `<form id="lgForm">
      ${field({ label: t('date'), name: 'date', type: 'date', value: dateStr() })}
      ${prod.metrics.map(([key, name]) => field({ label: t('m_' + name), name: key, type: 'number', value: '' })).join('')}
      ${field({ label: t('note'), name: 'note' })}
      <button class="btn btn-gold block" type="submit">${ic('check')} ${esc(t('save'))}</button></form>`, (body, close) => {
      $('#lgForm', body).onsubmit = async (e) => {
        e.preventDefault();
        const f = formData(e.target);
        const m = {};
        for (const [key] of prod.metrics) m[key] = toNum(f[key]);
        if (!Object.values(m).some((v) => v > 0)) return toast(t('err_amount'), 'danger');
        await addLog(biz.id, u.id, f.date || dateStr(), m, f.note);
        toast(t('saved'), 'good'); close(); await afterChange(); draw();
      };
    });
  }

  async function detail(u) {
    const logs = await unitLogs(u.id);
    const byDate = {};
    for (const l of logs) (byDate[l.log_date] = byDate[l.log_date] || {})[l.metric] = l.value;
    sheet(u.name, `
      ${kv(t('count_' + prod.count), esc(num(alive(u), 0)))}
      <div class="btn-row wrap"><button class="btn btn-ghost" id="unEdit">${ic('pen')} ${esc(t('edit'))}</button>
        <button class="btn btn-danger" id="unDel">${ic('trash-can')} ${esc(t('delete'))}</button></div>
      <div class="card-title sm">${esc(t('history'))}</div>
      ${Object.keys(byDate).length ? Object.entries(byDate).map(([d, m]) => `
        <div class="row slim"><div class="row-main"><b>${esc(fmtDate(d))}</b>
          <small>${prod.metrics.filter(([k]) => m[k]).map(([k, n]) => `${esc(t('m_' + n))}: ${esc(num(m[k], 1))}`).join(' • ')}</small></div></div>`).join('') : `<p class="muted">${esc(t('no_activity'))}</p>`}`,
    (body, close) => {
      $('#unEdit', body).onclick = () => { close(); unitForm(u); };
      $('#unDel', body).onclick = async () => { if (await confirmBox(t('delete_confirm'))) { await deleteUnit(u.id); close(); await afterChange(); draw(); } };
    });
  }
  await draw();
}
