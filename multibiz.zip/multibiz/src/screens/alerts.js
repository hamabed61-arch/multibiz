// alerts.js - orodha ya alerts zote (nyekundu = hatari, dhahabu = tahadhari, kijani = nzuri)
import { t, fmtDate } from '../i18n/index.js';
import { esc, ic, emptyState, pageHead } from '../ui.js';
import { listAlerts, markAllRead } from '../alerts.js';
import { hasModule } from '../templates.js';
import { alertCard } from './dashboard.js';
import { afterChange, bus } from '../state.js';

export default async function alertsScreen(view, { biz }) {
  const list = await listAlerts(biz.id);
  const count = (l) => list.filter((a) => a.level === l).length;
  const canRestock = hasModule(biz, 'purchases');
  view.innerHTML = `
    ${pageHead(t('nav_alerts'))}
    <div class="lvl-summary">
      <span class="lvl-pill lvl-danger">${ic('triangle-exclamation')} ${count('danger')} ${esc(t('al_lvl_danger'))}</span>
      <span class="lvl-pill lvl-warn">${ic('circle-exclamation')} ${count('warn')} ${esc(t('al_lvl_warn'))}</span>
      <span class="lvl-pill lvl-good">${ic('circle-check')} ${count('good')} ${esc(t('al_lvl_good'))}</span>
    </div>
    ${list.length ? list.map((a) => {
      const isStock = a.key.startsWith('stock:');
      const pid = a.key.split(':')[1];
      const extra = `<small class="ac-time">${esc(fmtDate(a.updated_at, true))}${a.read ? '' : ' • ' + esc(t('new'))}</small>` +
        (isStock && canRestock ? `<a class="btn btn-mini" href="#/purchases/new?product=${pid}">${ic('truck')} ${esc(t('restock'))}</a>` : '');
      return alertCard(a, biz, extra);
    }).join('') : emptyState('circle-check', t('no_alerts'), t('no_alerts_sub'))}`;
  if (list.some((a) => !a.read)) {
    await markAllRead(biz.id);
    bus.dispatchEvent(new Event('bell'));
  }
  void afterChange;
}
