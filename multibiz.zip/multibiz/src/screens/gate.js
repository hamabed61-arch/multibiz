// gate.js (skrini) - ombi la nenosiri la ufikiaji
import { t, LANGS, setLang, getLang } from '../i18n/index.js';
import { $, esc, ic, brandLogo } from '../ui.js';
import { tryGate, gateLockMinutes } from '../gate.js';

export function showGate(root, onOpen) {
  const locked = gateLockMinutes();
  root.innerHTML = `
    <div class="ob">
      <form class="ob-card center" id="gateForm">
        ${brandLogo('big')}
        <h1>${esc(t('gate_title'))}</h1>
        <p class="ob-sub">${esc(t('gate_sub'))}</p>
        <div class="fg"><input id="gt_pw" type="password" autocomplete="off" placeholder="${esc(t('gate_password'))}" ${locked ? 'disabled' : ''}></div>
        <div class="form-error" id="gt_err" ${locked ? '' : 'hidden'}>${ic('circle-exclamation')} <span>${locked ? esc(t('err_gate_locked', { m: locked })) : ''}</span></div>
        <button class="btn btn-gold block" type="submit" ${locked ? 'disabled' : ''}>${ic('lock-open')} ${esc(t('gate_button'))}</button>
        <div class="lang-mini">${LANGS.map((l) => `<button type="button" class="${getLang() === l.code ? 'on' : ''}" data-lang="${l.code}">${esc(l.name)}</button>`).join('')}</div>
      </form>
    </div>`;
  const err = $('#gt_err', root);
  $('#gateForm', root).onsubmit = async (e) => {
    e.preventDefault();
    const r = await tryGate($('#gt_pw', root).value);
    if (r.ok) return onOpen();
    showGate(root, onOpen);
    const box = $('#gt_err', root);
    box.hidden = false;
    box.querySelector('span').textContent = r.locked ? t('err_gate_locked', { m: r.locked }) : t('err_gate_wrong', { n: r.left });
  };
  root.querySelectorAll('[data-lang]').forEach((b) => (b.onclick = () => { setLang(b.dataset.lang); showGate(root, onOpen); }));
  void err;
}
