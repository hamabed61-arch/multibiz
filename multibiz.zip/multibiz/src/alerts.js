// alerts.js - injini ya alerts: stock kuisha, expiry, na mwenendo wa biashara
// Rangi: danger = nyekundu (hatari), warn = dhahabu (tahadhari), good = kijani (nzuri)
import { all, one, val, run, tx, uid, now, dateStr, addDays, getSetting } from './db/index.js';
import { summary, listProducts, debtTotals } from './data.js';
import { hasModule, productionOf } from './templates.js';
import { t, num, fmtDate } from './i18n/index.js';
import { money, unitLabel } from './ui.js';
import { pushNotification } from './notify.js';

export const RANK = { danger: 0, warn: 1, good: 2 };
const daysBetween = (a, b) => Math.round((new Date(b + 'T00:00:00') - new Date(a + 'T00:00:00')) / 86400000);
const pctChange = (now_, prev) => ((now_ - prev) / prev) * 100;

function mondayOf(d) {
  const x = new Date(d);
  const wd = (x.getDay() + 6) % 7;
  x.setDate(x.getDate() - wd);
  return dateStr(x);
}

// ── hesabu alerts zote zinazopaswa kuwepo sasa ──
export async function computeAlerts(biz) {
  const out = [];
  const add = (key, level, code, params = {}) => out.push({ key, level, code, params });
  const today = dateStr();
  const wk = mondayOf(new Date());
  const ym = today.slice(0, 7);
  const w1 = [dateStr(addDays(new Date(), -6)), today];
  const w0 = [dateStr(addDays(new Date(), -13)), dateStr(addDays(new Date(), -7))];

  // ── stock kuisha & expiry (biashara zinazonunua na kuuza: inventory + sales/purchases) ──
  const trades = hasModule(biz, 'inventory') && (hasModule(biz, 'sales') || hasModule(biz, 'purchases'));
  if (trades) {
    const products = await listProducts(biz.id);
    // kasi ya mauzo ya siku 14 zilizopita (idadi kwa siku) kwa kila bidhaa
    const soldRows = hasModule(biz, 'sales') ? await all(
      `SELECT si.product_id AS pid, SUM(si.qty) AS q FROM sale_items si JOIN sales s ON s.id = si.sale_id
       WHERE s.business_id = ? AND s.status = 'ok' AND si.product_id IS NOT NULL AND date(s.created_at) BETWEEN ? AND ?
       GROUP BY si.product_id`, [biz.id, dateStr(addDays(new Date(), -13)), today]) : [];
    const velocity = Object.fromEntries(soldRows.map((r) => [r.pid, r.q / 14]));

    for (const p of products) {
      if (!p.track_stock) continue;
      if (p.has_moves && p.stock <= 0) add(`stock:${p.id}`, 'danger', 'out_of_stock', { name: p.name });
      else if (p.has_moves && p.stock <= p.low_stock) add(`stock:${p.id}`, 'danger', 'low_stock', { name: p.name, qty: p.stock, unit: p.unit || '' });
      else if (p.has_moves && velocity[p.id] > 0) {
        // bado juu ya kiwango cha chini, lakini kwa kasi ya mauzo ya sasa itaisha ndani ya siku 7
        const days = p.stock / velocity[p.id];
        if (days <= 7) add(`stock:${p.id}`, 'warn', 'running_out', { name: p.name, days: Math.max(1, Math.round(days)) });
      }

      if (hasModule(biz, 'expiry') && p.expiry_date && p.stock > 0) {
        const d = daysBetween(today, p.expiry_date);
        if (d < 0) add(`exp:${p.id}:${p.expiry_date}`, 'danger', 'expired', { name: p.name, date: p.expiry_date });
        else if (d <= 30) add(`exp:${p.id}:${p.expiry_date}`, 'warn', 'expiring', { name: p.name, days: d });
      }
    }
  }

  // ── mwenendo wa mauzo/fedha ──
  if (hasModule(biz, 'sales')) {
    const first = await val('SELECT MIN(date(created_at)) FROM sales WHERE business_id = ?', [biz.id], null);
    const fullHistory = first && first <= w0[0];
    const s1 = await summary(biz.id, w1[0], w1[1]);
    const s0 = await summary(biz.id, w0[0], w0[1]);

    if (fullHistory && s0.revenue > 0) {
      const pct = pctChange(s1.revenue, s0.revenue);
      if (pct >= 10) add(`sales_up:${wk}`, 'good', 'sales_up', { pct: Math.round(pct) });
      else if (pct <= -15) add(`sales_down:${wk}`, 'danger', 'sales_down', { pct: Math.round(Math.abs(pct)) });
    }
    if (s1.expenses > 0 && s1.expenses > s1.revenue) add(`exp_exceed:${wk}`, 'danger', 'expenses_exceed', { amt: s1.expenses - s1.revenue });
    if (fullHistory && s0.expenses > 0 && s1.expenses >= s0.expenses * 1.3) {
      add(`exp_up:${wk}`, 'warn', 'expenses_up', { pct: Math.round(pctChange(s1.expenses, s0.expenses)) });
    }

    // faida ya mwezi huu (baada ya siku 5 za mwezi ili kuepuka kelele)
    if (new Date().getDate() >= 5) {
      const sm = await summary(biz.id, `${ym}-01`, today);
      if (sm.revenue > 0 || sm.expenses > 0) {
        if (sm.net < 0) add(`profit_neg:${ym}`, 'danger', 'profit_negative', { amt: Math.abs(sm.net) });
        else if (sm.revenue > 0 && sm.net / sm.revenue >= 0.15) add(`profit_good:${ym}`, 'good', 'profit_good', { amt: sm.net, pct: Math.round((sm.net / sm.revenue) * 100) });
      }
    }

    // siku bora zaidi ya mwezi uliopita
    const tRev = await val(`SELECT COALESCE(SUM(total),0) FROM sales WHERE business_id = ? AND status = 'ok' AND date(created_at) = ?`, [biz.id, today]);
    if (tRev > 0) {
      const prior = await all(
        `SELECT SUM(total) AS v FROM sales WHERE business_id = ? AND status = 'ok' AND date(created_at) BETWEEN ? AND ? GROUP BY date(created_at)`,
        [biz.id, dateStr(addDays(new Date(), -30)), dateStr(addDays(new Date(), -1))]);
      if (prior.length >= 5 && tRev > Math.max(...prior.map((r) => r.v))) add(`best_day:${today}`, 'good', 'best_day', { amt: tRev });
    }

    // madeni
    if (hasModule(biz, 'debts')) {
      const dt = await debtTotals(biz.id);
      const r30 = (await summary(biz.id, dateStr(addDays(new Date(), -29)), today)).revenue;
      if (dt.owedToMe > 0 && r30 > 0 && dt.owedToMe > r30 * 0.5) add('debts_high', 'warn', 'debts_high', { amt: dt.owedToMe });
    }
  }

  // ── uzalishaji (kuku/mifugo/samaki/kilimo) ──
  const prod = productionOf(biz);
  if (prod && hasModule(biz, 'production')) {
    const hasLoss = prod.metrics.some((m) => m[0] === 'loss');
    if (hasLoss) {
      const count = await val('SELECT COALESCE(SUM(count),0) FROM production_units WHERE business_id = ? AND active = 1', [biz.id]);
      const lostAll = await val(`SELECT COALESCE(SUM(value),0) FROM production_logs WHERE business_id = ? AND metric = 'loss'`, [biz.id]);
      const l3 = await val(`SELECT COALESCE(SUM(value),0) FROM production_logs WHERE business_id = ? AND metric = 'loss' AND log_date BETWEEN ? AND ?`,
        [biz.id, dateStr(addDays(new Date(), -2)), today]);
      const alive = count - lostAll + l3;
      if (l3 > 0 && alive > 0 && (l3 / alive) * 100 >= 2) add(`loss:${wk}`, 'danger', 'loss_high', { n: l3, pct: Math.round((l3 / alive) * 1000) / 10 });
    }
    const firstLog = await val('SELECT MIN(log_date) FROM production_logs WHERE business_id = ?', [biz.id], null);
    if (firstLog && firstLog <= w0[0]) {
      const q = async (r) => val(`SELECT COALESCE(SUM(value),0) FROM production_logs WHERE business_id = ? AND metric = 'produce' AND log_date BETWEEN ? AND ?`, [biz.id, r[0], r[1]]);
      const p1 = await q(w1), p0 = await q(w0);
      if (p0 > 0) {
        const pct = pctChange(p1, p0);
        if (pct <= -15) add(`produce_down:${wk}`, 'danger', 'produce_down', { pct: Math.round(Math.abs(pct)) });
        else if (pct >= 10) add(`produce_up:${wk}`, 'good', 'produce_up', { pct: Math.round(pct) });
      }
    }
  }
  return out;
}

// ── linganisha na table ya alerts; rudisha zile mpya zinazohitaji notification ──
// refreshAlerts zinapangwa foleni: simu mbili kwa wakati mmoja zingejaribu kuingiza alert ileile mara mbili
let refreshChain = Promise.resolve();
export function refreshAlerts(biz) {
  const p = refreshChain.then(() => doRefresh(biz), () => doRefresh(biz));
  refreshChain = p.catch(() => {});
  return p;
}

async function doRefresh(biz) {
  const list = await computeAlerts(biz);
  const existing = await all('SELECT * FROM alerts WHERE business_id = ?', [biz.id]);
  const byKey = Object.fromEntries(existing.map((e) => [e.key, e]));
  const keys = new Set(list.map((a) => a.key));
  const ts = now();
  await tx(async () => {
    for (const a of list) {
      const ex = byKey[a.key];
      const params = JSON.stringify(a.params);
      if (!ex) {
        await run(`INSERT INTO alerts (id, business_id, key, level, code, params, active, read, notified, created_at, updated_at) VALUES (?,?,?,?,?,?,1,0,0,?,?)`,
          [uid(), biz.id, a.key, a.level, a.code, params, ts, ts]);
      } else if (!ex.active || ex.code !== a.code) {
        await run(`UPDATE alerts SET level=?, code=?, params=?, active=1, read=0, notified=0, created_at=?, updated_at=? WHERE id=?`, [a.level, a.code, params, ts, ts, ex.id]);
      } else if (ex.params !== params || ex.level !== a.level) {
        await run(`UPDATE alerts SET level=?, params=?, updated_at=? WHERE id=?`, [a.level, params, ts, ex.id]);
      }
    }
    for (const ex of existing) if (ex.active && !keys.has(ex.key)) await run('UPDATE alerts SET active = 0, updated_at = ? WHERE id = ?', [ts, ex.id]);
  });
  return all('SELECT * FROM alerts WHERE business_id = ? AND active = 1 AND notified = 0', [biz.id]);
}

export async function listAlerts(bizId) {
  const rows = await all('SELECT * FROM alerts WHERE business_id = ? AND active = 1', [bizId]);
  return rows.sort((a, b) => RANK[a.level] - RANK[b.level] || (b.created_at > a.created_at ? 1 : -1));
}

export const unreadCount = (bizId) => val('SELECT COUNT(*) FROM alerts WHERE business_id = ? AND active = 1 AND read = 0', [bizId]);
export const unreadDanger = (bizId) => val(`SELECT COUNT(*) FROM alerts WHERE business_id = ? AND active = 1 AND read = 0 AND level = 'danger'`, [bizId]);
export const markAllRead = (bizId) => run('UPDATE alerts SET read = 1 WHERE business_id = ? AND active = 1', [bizId]);

// ── maandishi (kwa lugha ya sasa) ──
export function alertText(a, biz) {
  const raw = typeof a.params === 'string' ? JSON.parse(a.params || '{}') : a.params || {};
  const p = {};
  for (const [k, v] of Object.entries(raw)) {
    if (k === 'amt') p[k] = money(v, biz?.currency);
    else if (k === 'date') p[k] = fmtDate(v);
    else if (k === 'unit') p[k] = unitLabel(v);
    else if (typeof v === 'number') p[k] = num(v, k === 'pct' ? 1 : 2);
    else p[k] = v;
  }
  return t('al_' + a.code, p);
}

// ── tuma notification kwa alerts mpya ──
export async function notifyNew(biz, rows) {
  if (!rows.length) return;
  const enabled = (await getSetting('notify', '1')) !== '0';
  if (enabled) {
    for (const level of ['danger', 'warn', 'good']) {
      const group = rows.filter((r) => r.level === level);
      if (!group.length) continue;
      if (group.length === 1) {
        await pushNotification(`${t('al_lvl_' + level)} • ${biz.name}`, alertText(group[0], biz), level);
      } else {
        const body = group.slice(0, 3).map((g) => alertText(g, biz)).join(' • ') + (group.length > 3 ? ` +${group.length - 3}` : '');
        await pushNotification(`${t('al_lvl_' + level)} • ${biz.name} (${group.length})`, body, level);
      }
    }
  }
  for (const r of rows) await run('UPDATE alerts SET notified = 1 WHERE id = ?', [r.id]);
}
