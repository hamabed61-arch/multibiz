// share.js - kushiriki risiti / kuhifadhi backup (native: Share + Filesystem; browser: navigator.share / download)
import { isNative } from './db/index.js';

export async function shareText(title, text) {
  if (isNative()) {
    const { Share } = await import('@capacitor/share');
    await Share.share({ title, text, dialogTitle: title });
    return true;
  }
  if (navigator.share) { try { await navigator.share({ title, text }); return true; } catch (e) { /* imefutwa */ } }
  try { await navigator.clipboard.writeText(text); return 'copied'; } catch (e) { return false; }
}

// hifadhi faili (backup JSON) na uruhusu mtumiaji kuituma/kuihifadhi
export async function shareFile(filename, content, mime = 'application/json') {
  if (isNative()) {
    const { Filesystem, Directory, Encoding } = await import('@capacitor/filesystem');
    const { Share } = await import('@capacitor/share');
    const w = await Filesystem.writeFile({ path: filename, data: content, directory: Directory.Cache, encoding: Encoding.UTF8 });
    await Share.share({ title: filename, url: w.uri, dialogTitle: filename });
    return true;
  }
  const blob = new Blob([content], { type: mime });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  return true;
}
