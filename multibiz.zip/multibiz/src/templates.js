// templates.js - aina za biashara na modules zake (modular: kila kitu kinawashwa/kuzimwa)

export const MODULES = [
  // key, icon, group
  { key: 'sales',      icon: 'cart-shopping' },
  { key: 'inventory',  icon: 'boxes-stacked' },
  { key: 'purchases',  icon: 'truck' },
  { key: 'expenses',   icon: 'receipt' },
  { key: 'customers',  icon: 'users' },
  { key: 'suppliers',  icon: 'handshake' },
  { key: 'debts',      icon: 'hand-holding-dollar' },
  { key: 'employees',  icon: 'user-tie' },
  { key: 'reports',    icon: 'chart-line' },
  { key: 'production', icon: 'seedling' },
  { key: 'expiry',     icon: 'hourglass-half' }
];

const RETAIL = ['sales', 'inventory', 'purchases', 'expenses', 'customers', 'suppliers', 'debts', 'employees', 'reports'];
const FARM = ['production', 'sales', 'inventory', 'purchases', 'expenses', 'customers', 'suppliers', 'debts', 'employees', 'reports'];
const SERVICE = ['sales', 'expenses', 'customers', 'debts', 'employees', 'reports'];

// Uzalishaji (kuku, mifugo, kilimo, samaki): vipimo vya kila siku
const PRODUCTION = {
  poultry:   { unit: 'flock', count: 'birds',   metrics: [['produce', 'eggs'], ['feed', 'feed_kg'], ['loss', 'mortality']] },
  livestock: { unit: 'herd',  count: 'animals', metrics: [['produce', 'milk'], ['feed', 'feed_kg'], ['loss', 'deaths']] },
  fish:      { unit: 'pond',  count: 'fish',    metrics: [['produce', 'harvest_kg'], ['feed', 'feed_kg'], ['loss', 'mortality']] },
  farming:   { unit: 'field', count: 'acres',   metrics: [['produce', 'harvest_kg']] }
};

export const TYPES = {
  shop:         { icon: 'store',             group: 'retail',   modules: RETAIL },
  supermarket:  { icon: 'cart-shopping',     group: 'retail',   modules: RETAIL },
  electronics:  { icon: 'microchip',         group: 'retail',   modules: RETAIL },
  hardware:     { icon: 'screwdriver-wrench',group: 'retail',   modules: RETAIL },
  pharmacy:     { icon: 'pills',             group: 'health',   modules: [...RETAIL, 'expiry'] },
  medical_store:{ icon: 'briefcase-medical', group: 'health',   modules: [...RETAIL, 'expiry'] },
  farming:      { icon: 'wheat-awn',         group: 'agri',     modules: FARM, production: 'farming' },
  livestock:    { icon: 'cow',               group: 'agri',     modules: FARM, production: 'livestock' },
  poultry:      { icon: 'egg',               group: 'agri',     modules: FARM, production: 'poultry' },
  fish:         { icon: 'fish',              group: 'agri',     modules: FARM, production: 'fish' },
  salon:        { icon: 'scissors',          group: 'services', modules: [...SERVICE, 'inventory'] },
  restaurant:   { icon: 'utensils',          group: 'services', modules: [...RETAIL] },
  garage:       { icon: 'wrench',            group: 'services', modules: [...RETAIL] },
  consultancy:  { icon: 'briefcase',         group: 'services', modules: SERVICE },
  other:        { icon: 'shapes',            group: 'other',    modules: RETAIL }
};

export const GROUPS = ['retail', 'health', 'agri', 'services', 'other'];
export const typesOfGroup = (g) => Object.keys(TYPES).filter((k) => TYPES[k].group === g);

export const CURRENCIES = ['TZS', 'KES', 'UGX', 'USD', 'EUR', 'SAR', 'AED'];
export const UNITS = ['pcs', 'kg', 'litre', 'box', 'bag', 'tray', 'dozen', 'meter', 'hour', 'service'];
export const EXPENSE_CATS = ['rent', 'salary', 'transport', 'utilities', 'airtime', 'tax', 'supplies', 'repairs', 'feed', 'other'];
export const PAY_METHODS = ['cash', 'mobile', 'bank'];

export const typeInfo = (type) => TYPES[type] || TYPES.other;
export const productionOf = (biz) => PRODUCTION[typeInfo(biz.type).production] || null;
export const hasModule = (biz, key) => !!biz && JSON.parse(biz.modules || '[]').includes(key);
