// gate.js - nenosiri la ufikiaji: app inaomba mara ya kwanza baada ya kusakinishwa (kabla ya usajili/login).
// Nenosiri lenyewe HALIHIFADHIWI hapa - ni hash tu (PBKDF2). Kubadilisha: tengeneza hash mpya (angalia README).
import { hashPin } from './auth.js';

const GATE_SALT = '1da223975e4681a76fdc96cbc0c79660';
const GATE_HASH = '7439e9f252c18eea9e86be7750e2d18ed58e5512a9c9a3bc86cc5d295f6e89f6';
const K_OK = 'mb_gate';
const K_FAIL = 'mb_gate_fail';
const K_LOCK = 'mb_gate_lock';
const MAX_TRIES = 5;
const LOCK_MINUTES = 10;

const get = (k) => { try { return localStorage.getItem(k); } catch (e) { return null; } };
const set = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } };

export const gateOpen = () => get(K_OK) === GATE_HASH;

export function gateLockMinutes() {
  const left = Number(get(K_LOCK) || 0) - Date.now();
  return left > 0 ? Math.ceil(left / 60000) : 0;
}

// -> { ok:true } | { ok:false, left } | { ok:false, locked }
export async function tryGate(password) {
  const locked = gateLockMinutes();
  if (locked) return { ok: false, locked };
  if ((await hashPin(password, GATE_SALT)) === GATE_HASH) {
    set(K_OK, GATE_HASH);
    set(K_FAIL, '0');
    return { ok: true };
  }
  const fails = Number(get(K_FAIL) || 0) + 1;
  if (fails >= MAX_TRIES) {
    set(K_FAIL, '0');
    set(K_LOCK, String(Date.now() + LOCK_MINUTES * 60000));
    return { ok: false, locked: LOCK_MINUTES };
  }
  set(K_FAIL, String(fails));
  return { ok: false, left: MAX_TRIES - fails };
}
