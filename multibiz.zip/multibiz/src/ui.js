// ui.js - vifaa vidogo vya UI vinavyotumika kila mahali
import { t, num } from './i18n/index.js';

export const $ = (sel, el = document) => el.querySelector(sel);
export const $$ = (sel, el = document) => [...el.querySelectorAll(sel)];

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export const ic = (name, cls = '') => `<i class="fas fa-${name} ${cls}"></i>`;
// Logo ya app: weka faili public/brand/logo.png - ikikosekana inaonekana icon ya kawaida
export const brandLogo = (cls = '') => `<div class="brand-logo ${cls}"><img src="./brand/logo.png" alt="" onload="this.parentNode.classList.add('has-img')" onerror="this.remove()">${ic('chart-line')}</div>`;
export const unitLabel = (u) => (u ? t('unit_' + u) : '');
export const money = (n, cur) => `${cur ? cur + ' ' : ''}${num(n, 2)}`;

// ── toast ──
let toastTimer = null;
export function toast(msg, level = 'info') {
  let el = $('#toast');
  if (!el) { el = document.createElement('div'); el.id = 'toast'; document.body.appendChild(el); }
  el.className = 'toast show lvl-' + level;
  el.textContent = msg;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 3200);
}

// ── bottom sheet (dirisha la chini) ──
export function sheet(title, bodyHtml, onMount, onClose) {
  const wrap = document.createElement('div');
  wrap.className = 'sheet-wrap';
  wrap.innerHTML = `
    <div class="sheet-bg"></div>
    <div class="sheet" role="dialog">
      <div class="sheet-head"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="close">${ic('xmark')}</button></div>
      <div class="sheet-body">${bodyHtml}</div>
    </div>`;
  document.body.appendChild(wrap);
  requestAnimationFrame(() => wrap.classList.add('open'));
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    wrap.classList.remove('open');
    setTimeout(() => wrap.remove(), 220);
    if (onClose) onClose();
  };
  wrap.querySelector('.sheet-bg').onclick = close;
  wrap.querySelector('[data-close]').onclick = close;
  if (onMount) onMount(wrap.querySelector('.sheet-body'), close);
  return close;
}

export function confirmBox(message, { danger = true, okText } = {}) {
  return new Promise((resolve) => {
    let answer = false;
    sheet(t('confirm'), `
      <p class="confirm-msg">${esc(message)}</p>
      <div class="btn-row">
        <button class="btn btn-ghost" data-no>${esc(t('cancel'))}</button>
        <button class="btn ${danger ? 'btn-danger' : 'btn-gold'}" data-yes>${esc(okText || t('yes'))}</button>
      </div>`, (body, close) => {
      body.querySelector('[data-no]').onclick = close;
      body.querySelector('[data-yes]').onclick = () => { answer = true; close(); };
    }, () => resolve(answer));
  });
}

// ── fomu ──
export function field({ label, name, type = 'text', value = '', placeholder = '', required = false, attrs = '', hint = '' }) {
  const v = value === null || value === undefined ? '' : value;
  const inputMode = type === 'number' ? ' inputmode="decimal" step="any"' : '';
  return `<div class="fg"><label for="f_${name}">${esc(label)}${required ? ' <b>*</b>' : ''}</label>
    <input id="f_${name}" name="${name}" type="${type}" value="${esc(v)}" placeholder="${esc(placeholder)}"${inputMode} ${required ? 'required' : ''} ${attrs}>
    ${hint ? `<small>${esc(hint)}</small>` : ''}</div>`;
}

export function selectField({ label, name, options, value = '', attrs = '' }) {
  return `<div class="fg"><label for="f_${name}">${esc(label)}</label>
    <select id="f_${name}" name="${name}" ${attrs}>${options
      .map((o) => `<option value="${esc(o.value)}" ${String(o.value) === String(value) ? 'selected' : ''}>${esc(o.label)}</option>`)
      .join('')}</select></div>`;
}

export function textArea({ label, name, value = '', rows = 2 }) {
  return `<div class="fg"><label for="f_${name}">${esc(label)}</label><textarea id="f_${name}" name="${name}" rows="${rows}">${esc(value)}</textarea></div>`;
}

export function formData(form) {
  const out = {};
  new FormData(form).forEach((v, k) => { out[k] = typeof v === 'string' ? v.trim() : v; });
  return out;
}

export const toNum = (v) => { const n = parseFloat(String(v ?? '').replace(/,/g, '')); return isFinite(n) ? n : 0; };

export function emptyState(iconName, text, sub = '') {
  return `<div class="empty">${ic(iconName)}<p>${esc(text)}</p>${sub ? `<small>${esc(sub)}</small>` : ''}</div>`;
}

export function pageHead(title, actionsHtml = '') {
  return `<div class="page-head"><h2>${esc(title)}</h2><div class="page-actions">${actionsHtml}</div></div>`;
}

// tabs: [{key,label}]
export function tabs(items, active) {
  return `<div class="tabs">${items.map((i) => `<button class="tab ${i.key === active ? 'active' : ''}" data-tab="${i.key}">${esc(i.label)}</button>`).join('')}</div>`;
}

export const debounce = (fn, ms = 250) => { let h; return (...a) => { clearTimeout(h); h = setTimeout(() => fn(...a), ms); }; };
