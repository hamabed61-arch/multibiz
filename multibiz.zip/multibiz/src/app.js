// app.js - ganda la app (sidebar, topbar, business switcher) na router
import { t } from './i18n/index.js';
import { $, $$, esc, ic, sheet, toast, brandLogo } from './ui.js';
import { S, bus, nav, loadBusinesses, setActiveBusiness, afterChange } from './state.js';
import { hasModule, typeInfo } from './templates.js';
import { unreadCount, unreadDanger } from './alerts.js';

import dashboard from './screens/dashboard.js';
import alertsScreen from './screens/alerts.js';
import sales from './screens/sales.js';
import saleNew from './screens/sale-new.js';
import purchases, { purchaseNew } from './screens/purchases.js';
import products from './screens/products.js';
import expenses from './screens/expenses.js';
import parties from './screens/parties.js';
import debts from './screens/debts.js';
import employees from './screens/employees.js';
import production from './screens/production.js';
import reports from './screens/reports.js';
import about from './screens/about.js';
import settings from './screens/settings.js';
import { openAddBusiness } from './screens/settings.js';

// path -> { render, module (inahitaji module gani), nav (jina la kichwa) }
const ROUTES = {
  '/dashboard': { r: dashboard, title: 'nav_dashboard' },
  '/alerts': { r: alertsScreen, title: 'nav_alerts' },
  '/sales': { r: sales, mod: 'sales', title: 'nav_sales' },
  '/sales/new': { r: saleNew, mod: 'sales', title: 'nav_new_sale' },
  '/purchases': { r: purchases, mod: 'purchases', title: 'nav_purchases' },
  '/purchases/new': { r: purchaseNew, mod: 'purchases', title: 'nav_purchases' },
  '/products': { r: products, mod: 'inventory', title: 'nav_products' },
  '/expenses': { r: expenses, mod: 'expenses', title: 'nav_expenses' },
  '/customers': { r: (v, c) => parties(v, c, 'customer'), mod: 'customers', title: 'nav_customers' },
  '/suppliers': { r: (v, c) => parties(v, c, 'supplier'), mod: 'suppliers', title: 'nav_suppliers' },
  '/debts': { r: debts, mod: 'debts', title: 'nav_debts' },
  '/employees': { r: employees, mod: 'employees', title: 'nav_employees' },
  '/production': { r: production, mod: 'production', title: 'nav_production' },
  '/reports': { r: reports, mod: 'reports', title: 'nav_reports' },
  '/settings': { r: settings, title: 'nav_settings' },
  '/about': { r: about, title: 'nav_about' }
};

export function navItems(biz) {
  const m = (k) => hasModule(biz, k);
  return [
    { label: 'nav_main', items: [
      { path: '/dashboard', icon: 'gauge-high', text: 'nav_dashboard' },
      { path: '/alerts', icon: 'bell', text: 'nav_alerts', badge: true }
    ] },
    { label: 'nav_trade', items: [
      m('sales') && { path: '/sales/new', icon: 'cart-plus', text: 'nav_new_sale' },
      m('sales') && { path: '/sales', icon: 'receipt', text: 'nav_sales' },
      m('inventory') && { path: '/products', icon: 'boxes-stacked', text: 'nav_products' },
      m('purchases') && { path: '/purchases', icon: 'truck', text: 'nav_purchases' },
      m('production') && { path: '/production', icon: typeInfo(biz.type).icon, text: 'nav_production' }
    ] },
    { label: 'nav_finance', items: [
      m('expenses') && { path: '/expenses', icon: 'wallet', text: 'nav_expenses' },
      m('debts') && { path: '/debts', icon: 'hand-holding-dollar', text: 'nav_debts' },
      m('reports') && { path: '/reports', icon: 'chart-line', text: 'nav_reports' }
    ] },
    { label: 'nav_people', items: [
      m('customers') && { path: '/customers', icon: 'users', text: 'nav_customers' },
      m('suppliers') && { path: '/suppliers', icon: 'handshake', text: 'nav_suppliers' },
      m('employees') && { path: '/employees', icon: 'user-tie', text: 'nav_employees' }
    ] }
  ].map((g) => ({ ...g, items: g.items.filter(Boolean) })).filter((g) => g.items.length);
}

let appRoot = null;
let wired = false;

export function mountShell(root, onLock) {
  appRoot = root;
  root.innerHTML = `
    <div class="sidebar-overlay" id="overlay"></div>
    <aside class="sidebar" id="sidebar"></aside>
    <header class="topbar" id="topbar">
      <button class="hamburger" id="hamburger" aria-label="menu"><span></span><span></span><span></span></button>
      <div class="topbar-breadcrumb"><span class="bc-page" id="pageName"></span></div>
      <div class="topbar-right">
        <button class="icon-btn bell" id="bell" aria-label="alerts">${ic('bell')}<b class="badge" id="bellBadge" hidden></b></button>
        <button class="topbar-chip" id="bizChip"><span class="chip-dot"></span><span id="bizName"></span>${ic('chevron-down')}</button>
      </div>
    </header>
    <main class="main"><div class="content-wrap" id="view"></div></main>`;
  $('#hamburger').onclick = () => toggleSidebar();
  $('#overlay').onclick = () => toggleSidebar(false);
  $('#bell').onclick = () => nav('/alerts');
  $('#bizChip').onclick = openSwitcher;
  if (!wired) {
    wired = true;
    bus.addEventListener('bell', updateBell);
    bus.addEventListener('rerender', () => { if (S.unlocked && $('#view')) { renderSidebar(); renderRoute(); } });
    window.addEventListener('hashchange', renderRoute);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && S.unlocked && S.biz) afterChange(); });
  }
  S.onLock = onLock;
  renderSidebar();
  renderRoute();
}

function toggleSidebar(force) {
  const open = force ?? !$('#sidebar').classList.contains('active');
  $('#sidebar').classList.toggle('active', open);
  $('#overlay').classList.toggle('show', open);
  $('#hamburger').classList.toggle('open', open);
}

function renderSidebar() {
  const biz = S.biz;
  const cur = currentPath();
  const initials = (S.user.name || '?').trim().charAt(0).toUpperCase();
  $('#sidebar').innerHTML = `
    <div class="sidebar-brand">
      ${brandLogo()}
      <div class="brand-text"><div class="brand-name">Multi<span>Biz</span></div><div class="brand-sub">${esc(t('app_sub'))}</div></div>
    </div>
    <div class="sidebar-user">
      <div class="user-avatar">${esc(initials)}</div>
      <div class="user-details"><div class="user-name">${esc(S.user.name)}</div><div class="user-role">${esc(t('account_owner'))}</div></div>
      <div class="user-status"></div>
    </div>
    <nav class="sidebar-nav">
      ${navItems(biz).map((g) => `
        <div class="nav-label">${esc(t(g.label))}</div>
        ${g.items.map((i) => `<a class="nav-item ${cur === i.path ? 'active' : ''}" href="#${i.path}">
          <span class="nav-icon">${ic(i.icon)}</span>${esc(t(i.text))}${i.badge && S.unread ? `<b class="badge inline">${S.unread}</b>` : ''}</a>`).join('')}`).join('')}
    </nav>
    <div class="sidebar-footer">
      <a class="nav-item ${cur === '/settings' ? 'active' : ''}" href="#/settings"><span class="nav-icon">${ic('gear')}</span>${esc(t('nav_settings'))}</a>
      <a class="nav-item ${cur === '/about' ? 'active' : ''}" href="#/about"><span class="nav-icon">${ic('circle-info')}</span>${esc(t('nav_about'))}</a>
      <button class="btn-logout" id="lockBtn">${ic('lock')} ${esc(t('lock_app'))}</button>
    </div>`;
  $$('.nav-item', $('#sidebar')).forEach((a) => a.addEventListener('click', () => toggleSidebar(false)));
  $('#lockBtn').onclick = () => { S.unlocked = false; S.onLock && S.onLock(); };
}

export async function updateBell() {
  if (!S.biz || !$('#bellBadge')) return;
  const n = await unreadCount(S.biz.id);
  const d = await unreadDanger(S.biz.id);
  S.unread = n;
  const b = $('#bellBadge');
  b.hidden = n === 0;
  b.textContent = n > 99 ? '99+' : n;
  b.className = 'badge ' + (d > 0 ? 'lvl-danger' : 'lvl-warn');
  $('#bell').classList.toggle('ring', d > 0);
  const inline = $('.nav-item .badge.inline');
  if (inline) inline.textContent = n;
}

function currentPath() {
  const h = location.hash.replace(/^#/, '') || '/dashboard';
  return h.split('?')[0];
}

export async function renderRoute() {
  if (!S.unlocked || !$('#view')) return;
  let path = currentPath();
  let route = ROUTES[path];
  if (!route || (route.mod && !hasModule(S.biz, route.mod))) { path = '/dashboard'; route = ROUTES[path]; }
  const params = new URLSearchParams((location.hash.split('?')[1]) || '');
  $('#pageName').textContent = t(route.title);
  $('#bizName').textContent = S.biz.name;
  renderSidebar();
  const view = $('#view');
  view.innerHTML = '';
  view.classList.remove('slide'); void view.offsetWidth; view.classList.add('slide');
  window.scrollTo(0, 0);
  try {
    await route.r(view, { params, biz: S.biz, path });
  } catch (e) {
    console.error(e);
    view.innerHTML = `<div class="form-error">${esc(String(e.message || e))}</div>`;
  }
  updateBell();
}

// ── Business switcher ──
async function openSwitcher() {
  const counts = {};
  for (const b of S.businesses) counts[b.id] = await unreadCount(b.id);
  sheet(t('my_businesses'), `
    <div class="switch-list">
      ${S.businesses.map((b) => `
        <button class="switch-item ${b.id === S.biz.id ? 'active' : ''}" data-id="${b.id}">
          <span class="nav-icon">${ic(typeInfo(b.type).icon)}</span>
          <span class="si-text"><b>${esc(b.name)}</b><small>${esc(b.type === 'other' && b.custom_type ? b.custom_type : t('type_' + b.type))}${b.location ? ' • ' + esc(b.location) : ''}</small></span>
          ${counts[b.id] ? `<b class="badge inline">${counts[b.id]}</b>` : ''}
          ${b.id === S.biz.id ? ic('check', 'ok') : ''}
        </button>`).join('')}
    </div>
    <button class="btn btn-gold block" id="swAdd">${ic('plus')} ${esc(t('add_business'))}</button>`, (body, close) => {
    $$('.switch-item', body).forEach((b) => (b.onclick = async () => {
      close();
      if (b.dataset.id !== S.biz.id) { await setActiveBusiness(b.dataset.id); nav('/dashboard'); renderRoute(); }
    }));
    $('#swAdd', body).onclick = () => { close(); openAddBusiness(async (id) => { await setActiveBusiness(id); nav('/dashboard'); renderRoute(); }); };
  });
}
