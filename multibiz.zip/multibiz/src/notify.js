// notify.js - arifa za simu (Android local notifications). Kwenye browser ya majaribio: toast tu.
import { isNative } from './db/index.js';
import { toast } from './ui.js';

const CHANNEL = 'mb_alerts';
let plugin = null;
let seq = 0;

async function lib() {
  if (!plugin) plugin = (await import('@capacitor/local-notifications')).LocalNotifications;
  return plugin;
}

export async function ensurePermission() {
  if (!isNative()) return false;
  try {
    const LN = await lib();
    let p = await LN.checkPermissions();
    if (p.display !== 'granted') p = await LN.requestPermissions();
    if (p.display === 'granted') {
      await LN.createChannel({ id: CHANNEL, name: 'MultiBiz Alerts', description: 'Stock & business alerts', importance: 4, visibility: 1, vibration: true });
    }
    return p.display === 'granted';
  } catch (e) {
    return false;
  }
}

// level: 'danger' | 'warn' | 'good'
export async function pushNotification(title, body, level = 'warn') {
  if (!isNative()) {
    toast(`${title} — ${body}`, level);
    return;
  }
  try {
    const LN = await lib();
    seq += 1;
    await LN.schedule({
      notifications: [{
        id: (Math.floor(Date.now() / 1000) % 2000000000) + seq,
        title, body, channelId: CHANNEL
      }]
    });
  } catch (e) { /* ruhusa haijatolewa - kimya */ }
}
