// main.js - mwanzo wa app
import { initDb } from './db/index.js';
import { setLang, initialLang } from './i18n/index.js';
import { S, loadUser, loadBusinesses, checkAllBusinesses } from './state.js';
import { startOnboarding } from './screens/onboarding.js';
import { showLogin } from './screens/login.js';
import { mountShell } from './app.js';
import { securitySheet } from './screens/security-setup.js';
import { gateOpen } from './gate.js';
import { showGate } from './screens/gate.js';

// fonti (zinafungwa ndani ya APK wakati wa build). Kwenye majaribio ya moja kwa moja bila bundler hazipo - si tatizo.
import('./fonts.js').catch(() => {});

const root = document.getElementById('app');

async function enter() {
  await loadBusinesses();
  S.unlocked = true;
  mountShell(root, lock);
  checkAllBusinesses();
  // akaunti za zamani (zilizotengenezwa kabla ya maswali ya usalama): omba kuyaweka
  if (!S.user.sec) setTimeout(() => securitySheet({ later: true }), 700);
}

function lock() {
  S.unlocked = false;
  showLogin(root, enter, restart);
}

async function restart() {
  S.user = null;
  S.biz = null;
  S.unlocked = false;
  startOnboarding(root, enter);
}

async function boot() {
  setLang(initialLang());
  // nenosiri la ufikiaji: linaombwa mara ya kwanza baada ya kusakinisha
  if (!gateOpen()) return showGate(root, boot);
  try {
    await initDb();
  } catch (e) {
    root.innerHTML = `<pre class="form-error" style="margin:20px">${String(e.message || e)}</pre>`;
    return;
  }
  S.user = await loadUser();
  if (!S.user) return startOnboarding(root, enter);
  setLang(S.user.lang || initialLang());
  showLogin(root, enter, restart);
}

boot();
