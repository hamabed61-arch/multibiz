// security.js - maswali ya usalama (kurejesha nenosiri): kuhifadhi, kuthibitisha, kuweka nenosiri jipya
import { getSetting, setSetting } from './db/index.js';
import { hashPin, newSalt, hashAnswers } from './auth.js';
import { S } from './state.js';

const MAX_TRIES = 5;
const LOCK_MINUTES = 5;

// answers: [jina la utani, jina la tatu la mama, mahali alipozaliwa]
export async function saveSecurity(answers) {
  const salt = newSalt();
  const hashes = await hashAnswers(answers, salt);
  await setSetting('sec_salt', salt);
  await setSetting('sec_a1', hashes[0]);
  await setSetting('sec_a2', hashes[1]);
  await setSetting('sec_a3', hashes[2]);
  await setSetting('sec_fail', '0');
  await setSetting('sec_lock_until', '0');
  if (S.user) S.user.sec = { salt, hashes };
}

export async function lockMinutesLeft() {
  const left = Number(await getSetting('sec_lock_until', '0')) - Date.now();
  return left > 0 ? Math.ceil(left / 60000) : 0;
}

// -> { ok:true } | { ok:false, left:n } | { ok:false, locked:dakika }
export async function verifySecurity(answers) {
  const locked = await lockMinutesLeft();
  if (locked) return { ok: false, locked };
  const sec = S.user.sec;
  const hashes = await hashAnswers(answers, sec.salt);
  if (hashes.every((h, i) => h === sec.hashes[i])) {
    await setSetting('sec_fail', '0');
    return { ok: true };
  }
  const fails = Number(await getSetting('sec_fail', '0')) + 1;
  if (fails >= MAX_TRIES) {
    await setSetting('sec_fail', '0');
    await setSetting('sec_lock_until', String(Date.now() + LOCK_MINUTES * 60000));
    return { ok: false, locked: LOCK_MINUTES };
  }
  await setSetting('sec_fail', String(fails));
  return { ok: false, left: MAX_TRIES - fails };
}

export async function resetPassword(newPin) {
  const salt = newSalt();
  const hash = await hashPin(newPin, salt);
  await setSetting('pin_salt', salt);
  await setSetting('pin_hash', hash);
  S.user.salt = salt;
  S.user.hash = hash;
}
