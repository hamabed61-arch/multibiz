export default {
  // general
  yes: 'Ndiyo', confirm: 'Thibitisha', cancel: 'Ghairi', save: 'Hifadhi', saved: 'Imehifadhiwa', delete: 'Futa', edit: 'Hariri', add: 'Ongeza',
  back: 'Rudi', next: 'Endelea', finish: 'Maliza', search: 'Tafuta…', new: 'Mpya', share: 'Shiriki', copied: 'Imenakiliwa',
  date: 'Tarehe', name: 'Jina', phone: 'Simu', address: 'Anwani', note: 'Maelezo', category: 'Aina', amount: 'Kiasi',
  price: 'Bei', qty: 'Idadi', total: 'Jumla', subtotal: 'Jumla ndogo', discount: 'Punguzo', paid: 'Kilicholipwa', balance: 'Salio',
  method: 'Njia ya malipo', product: 'Bidhaa', supplier: 'Msambazaji', customer: 'Mteja', service: 'Huduma', unit: 'Kipimo',
  kind: 'Aina', active: 'Anafanya kazi', inactive: 'Hafanyi kazi', role: 'Nafasi', salary: 'Mshahara', history: 'Historia', payment: 'Malipo',
  purchase: 'Ununuzi', receipt: 'Risiti', thank_you: 'Asante kwa kununua kwetu!',

  // app
  nav_about: 'Kuhusu', about_version: 'Toleo {v}',
  app_tagline: 'Simamia biashara moja au nyingi — bila internet, ndani ya simu yako.', app_sub: 'Msimamizi wa biashara', app_offline: 'Inafanya kazi bila internet',
  choose_language: 'Chagua lugha yako', language: 'Lugha',

  // onboarding
  ob_account_title: 'Tengeneza akaunti yako', ob_account_sub: 'Data yako inabaki kwenye simu hii. Huhitaji internet.',
  full_name: 'Jina kamili', password: 'Nenosiri', password_confirm: 'Thibitisha nenosiri', password_hint: 'Angalau herufi 4.',
  err_name: 'Tafadhali andika jina lako.', err_pin_short: 'Nenosiri liwe na angalau herufi 4.', err_pin_match: 'Manenosiri hayafanani.',
  ob_mode_title: 'Unafanya biashara gani?', ob_mode_sub: 'Chagua biashara moja au kadhaa. Unaweza kuongeza nyingine baadaye.',
  mode_one: 'Biashara moja', mode_one_sub: 'Ninafanya biashara moja tu', mode_many: 'Biashara nyingi', mode_many_sub: 'Ninafanya zaidi ya moja',
  choose_type_one: 'Chagua aina ya biashara yako', choose_type_many: 'Chagua aina zote za biashara zako', err_choose_type: 'Tafadhali chagua angalau aina moja ya biashara.',
  ob_details_title: 'Maelezo ya biashara', ob_details_sub: 'Ipe kila biashara jina na chagua sarafu yake.',
  business_name: 'Jina la biashara', custom_type: 'Eleza aina ya biashara yako', location: 'Mahali', currency: 'Sarafu',
  err_biz_name: 'Kila biashara inahitaji jina.', err_custom_type: 'Tafadhali eleza aina ya biashara yako.',
  add_business: 'Ongeza biashara', business_type: 'Aina ya biashara',
  ob_modules_title: 'Chagua huduma (modules)', ob_modules_sub: 'Tumechagua zinazofaa biashara yako. Washa au zima yoyote — unaweza kubadilisha baadaye.',

  // access gate
  gate_title: 'Washa MultiBiz',
  gate_sub: 'Weka nenosiri la ufikiaji ili kuanza kutumia app hii.',
  gate_password: 'Nenosiri la ufikiaji',
  gate_button: 'Endelea',
  err_gate_wrong: 'Nenosiri la ufikiaji si sahihi. Umebakiwa na majaribio {n}.',
  err_gate_locked: 'Umejaribu mara nyingi mno. Jaribu tena baada ya dakika {m}.',

  // password recovery
  sec_title: 'Kurejesha nenosiri',
  sec_sub: 'Jibu maswali 3 ya usalama. Utayatumia ukisahau nenosiri.',
  sec_q1: 'Jina lako la utani ni lipi?',
  sec_q2: 'Jina la tatu la mama yako ni lipi?',
  sec_q3: 'Ulizaliwa wapi (sehemu uliyozaliwa)?',
  sec_hint: 'Herufi kubwa au ndogo hazijalishi. Zikumbuke kama ulivyoandika.',
  err_sec_fill: 'Tafadhali jibu maswali yote matatu.',
  recover_title: 'Weka nenosiri jipya',
  recover_sub: 'Jibu maswali yako ya usalama ili kuweka nenosiri jipya.',
  recover_verify: 'Thibitisha majibu',
  err_sec_wrong: 'Jibu moja au zaidi si sahihi. Umebakiwa na majaribio {n}.',
  err_sec_locked: 'Umejaribu mara nyingi mno. Jaribu tena baada ya dakika {m}.',
  recover_none: 'Hujaweka maswali ya usalama kwenye simu hii. Unaweza kurejesha backup au kufuta data yote na kuanza upya.',
  recover_new_title: 'Chagua nenosiri jipya',
  recover_done: 'Nenosiri limebadilishwa. Karibu tena!',
  recover_erase: 'Huwezi kujibu? Futa data yote',
  back_to_login: 'Rudi kuingia',
  sec_setup_title: 'Weka njia ya kurejesha nenosiri',
  sec_setup_sub: 'Weka maswali 3 ya usalama ili uweze kuweka nenosiri jipya ukilisahau.',
  sec_later: 'Baadaye',
  sec_settings: 'Maswali ya usalama',
  sec_status_on: 'Maswali ya usalama yamewekwa.',
  sec_status_off: 'Hayajawekwa — hutaweza kurejesha nenosiri ukilisahau.',
  sec_change: 'Weka / badilisha maswali',

  // login
  hello_user: 'Habari, {name}', enter_password: 'Weka nenosiri lako kufungua app', unlock: 'Fungua',
  forgot_password: 'Umesahau nenosiri?', err_wrong_password: 'Nenosiri si sahihi.', reset_app: 'Futa data yote na uanze upya',
  reset_warning: 'Hii itafuta data ZOTE za simu hii (biashara, mauzo, stock…). Kama una backup, utaweza kuirudisha baadaye. Endelea?',

  // navigation
  nav_main: 'Kuu', nav_trade: 'Biashara na stock', nav_finance: 'Fedha', nav_people: 'Watu',
  nav_dashboard: 'Dashibodi', nav_alerts: 'Tahadhari', nav_sales: 'Mauzo', nav_new_sale: 'Uza sasa', nav_products: 'Bidhaa na huduma',
  nav_purchases: 'Ununuzi', nav_production: 'Uzalishaji', nav_expenses: 'Matumizi', nav_debts: 'Madeni', nav_reports: 'Ripoti',
  nav_customers: 'Wateja', nav_suppliers: 'Wasambazaji', nav_employees: 'Wafanyakazi', nav_settings: 'Mipangilio',
  nav_add_expense: 'Ongeza matumizi', nav_add_product: 'Ongeza bidhaa', lock_app: 'Funga app', account_owner: 'Mmiliki', my_businesses: 'Biashara zangu',

  // dashboard
  stat_sales: 'Mauzo ya leo', stat_expenses: 'Matumizi ya leo', stat_profit: 'Faida ya leo', stat_stock_value: 'Thamani ya stock',
  stat_owed_to_me: 'Ninaodai', stat_i_owe: 'Ninadaiwa', n_sales: 'Mauzo {n}', n_low: '{n} yanakaribia kuisha', sales_7d: 'Mauzo — siku 7 zilizopita',
  recent_activity: 'Shughuli za hivi karibuni', no_activity: 'Hakuna bado', view_all: 'Angalia zote', production_today: 'Uzalishaji wa leo', sale_no: 'Mauzo #{n}',

  // alerts
  al_lvl_danger: 'Hatari', al_lvl_warn: 'Tahadhari', al_lvl_good: 'Habari njema',
  al_out_of_stock: '{name} imekwisha stock',
  al_low_stock: '{name} inakaribia kuisha — imebaki {qty} {unit} tu',
  al_running_out: '{name} itaisha baada ya takriban siku {days} kwa kasi ya mauzo ya sasa',
  al_expired: '{name} imeisha muda wake tarehe {date}',
  al_expiring: '{name} inaisha muda ndani ya siku {days}',
  al_sales_up: 'Mauzo yamepanda {pct}% ukilinganisha na siku 7 zilizopita. Hongera!',
  al_sales_down: 'Mauzo yameshuka {pct}% ukilinganisha na siku 7 zilizopita',
  al_expenses_exceed: 'Wiki hii matumizi yako yamezidi mauzo kwa {amt}',
  al_expenses_up: 'Matumizi yamepanda {pct}% ukilinganisha na siku 7 zilizopita',
  al_profit_negative: 'Mwezi huu unaendesha kwa hasara ya {amt}',
  al_profit_good: 'Faida ya mwezi huu ni {amt} (asilimia {pct}) — nzuri!',
  al_best_day: 'Siku bora ya mauzo katika siku 30: leo umeuza {amt}!',
  al_debts_high: 'Wateja wanakudai {amt} — zaidi ya nusu ya mauzo ya siku 30 zilizopita',
  al_loss_high: 'Vifo/hasara {n} ndani ya siku 3 ({pct}%) — angalia afya na mazingira',
  al_produce_down: 'Uzalishaji umeshuka {pct}% ukilinganisha na siku 7 zilizopita',
  al_produce_up: 'Uzalishaji umepanda {pct}% ukilinganisha na siku 7 zilizopita',
  no_alerts: 'Hakuna tatizo', no_alerts_sub: 'Hakuna tahadhari kwa sasa. Tutakuonya stock ikikaribia kuisha au mwenendo ukibadilika.', restock: 'Nunua stock',

  // products
  no_products: 'Hakuna bidhaa bado', no_products_sub: 'Bonyeza + kuongeza bidhaa au huduma yako ya kwanza.', no_results: 'Hakuna matokeo',
  filter_all: 'Zote', filter_low: 'Zinakaribia kuisha', filter_expiry: 'Zinaisha muda', out_of_stock: 'Zimeisha', low_stock: 'Inakaribia kuisha',
  in_stock: 'Iliyopo', low_stock_level: 'Nionye stock ikifika au kushuka chini ya', sell_price: 'Bei ya kuuza', buy_price: 'Bei ya kununua',
  expiry_date: 'Tarehe ya kuisha muda', adjust_stock: 'Rekebisha stock', archive: 'Hifadhi kando', archive_confirm: 'Hifadhi kando "{name}"? Haitaonekana kwenye orodha.',
  stock_history: 'Mienendo ya stock', add_product: 'Ongeza bidhaa', edit_product: 'Hariri bidhaa', kind_product: 'Bidhaa (inafuatiliwa stock)',
  kind_service: 'Huduma (haina stock)', opening_qty: 'Idadi ya mwanzo', new_count: 'Idadi uliyohesabu', adjust_reason: 'Sababu (imeharibika, kuhesabu upya…)',
  mv_opening: 'Stock ya mwanzo', mv_purchase: 'Ununuzi', mv_sale: 'Mauzo', mv_adjust: 'Marekebisho', mv_return: 'Imerudishwa',

  // sales
  cart: 'Kikapu', cart_empty: 'Bonyeza bidhaa kuiongeza', checkout: 'Lipia', complete_sale: 'Kamilisha mauzo', custom_item: 'Kitu kingine',
  custom_item_hint: 'Tumia "Kitu kingine" kurekodi mauzo bila orodha ya bidhaa.', walk_in: 'Mteja wa kawaida', amount_paid: 'Kiasi kilicholipwa sasa',
  on_credit: 'Deni', sale_saved: 'Mauzo yamerekodiwa', no_sales: 'Hakuna mauzo kwa kipindi hiki', void_sale: 'Batilisha mauzo',
  void_confirm: 'Batilisha mauzo haya? Stock itarudishwa na hayataonekana kwenye ripoti.', voided: 'Yamebatilishwa',
  err_insufficient: 'Stock haitoshi: {d}', err_empty_cart: 'Ongeza angalau kitu kimoja.', err_credit_customer: 'Chagua mteja ili kuuza kwa deni.',
  err_credit_supplier: 'Chagua msambazaji ili kununua kwa deni.', err_amount: 'Weka kiasi sahihi.', err_over_balance: 'Kiasi ni kikubwa kuliko deni ({d}).',
  err_has_balance: 'Mtu huyu bado ana deni ambalo halijalipwa.',

  // purchases
  no_purchases: 'Hakuna ununuzi kwa kipindi hiki', no_supplier: 'Hakuna msambazaji', add_line: 'Ongeza bidhaa nyingine', unit_cost: 'Gharama kwa kipimo', save_purchase: 'Hifadhi ununuzi',

  // expenses
  no_expenses: 'Hakuna matumizi kwa kipindi hiki', add_expense: 'Ongeza matumizi', delete_confirm: 'Futa rekodi hii?',
  cat_rent: 'Kodi', cat_salary: 'Mishahara', cat_transport: 'Usafiri', cat_utilities: 'Umeme na maji', cat_airtime: 'Vocha na intaneti',
  cat_tax: 'Kodi na leseni', cat_supplies: 'Vifaa', cat_repairs: 'Matengenezo', cat_feed: 'Chakula na pembejeo', cat_other: 'Nyingine',

  // people
  no_customers: 'Hakuna wateja bado', no_suppliers: 'Hakuna wasambazaji bado', add_customer: 'Ongeza mteja', add_supplier: 'Ongeza msambazaji',
  debts_owed_to_me: 'Ninaodai', debts_i_owe: 'Ninadaiwa', no_debts: 'Hakuna madeni', receive_payment: 'Pokea malipo', make_payment: 'Lipa deni',
  no_employees: 'Hakuna wafanyakazi bado', add_employee: 'Ongeza mfanyakazi', monthly_payroll: 'Mishahara ya mwezi', pay_salary: 'Lipa mshahara',
  pay_salary_confirm: 'Rekodi mshahara wa {amt} wa {name} kama matumizi?',

  // production
  log_today: 'Rekodi ya kila siku', start_date: 'Tarehe ya kuanza',
  unit_flock: 'Kundi', unit_herd: 'Kundi la mifugo', unit_pond: 'Bwawa', unit_field: 'Shamba',
  no_units_flock: 'Hakuna makundi bado', no_units_herd: 'Hakuna makundi ya mifugo bado', no_units_pond: 'Hakuna mabwawa bado', no_units_field: 'Hakuna mashamba bado',
  no_units_sub: 'Bonyeza + kuongeza kisha uanze kurekodi kila siku.',
  add_unit_flock: 'Ongeza kundi', add_unit_herd: 'Ongeza kundi la mifugo', add_unit_pond: 'Ongeza bwawa', add_unit_field: 'Ongeza shamba',
  count_birds: 'Kuku', count_animals: 'Mifugo', count_fish: 'Samaki', count_acres: 'Ekari',
  m_eggs: 'Mayai', m_feed_kg: 'Chakula (kg)', m_mortality: 'Vifo', m_milk: 'Maziwa (lita)', m_deaths: 'Vifo', m_harvest_kg: 'Mavuno (kg)',

  // reports
  range_today: 'Leo', range_week: 'Siku 7', range_month: 'Mwezi huu', range_year: 'Mwaka huu', range_all: 'Zote',
  profit_loss: 'Faida na hasara', rep_revenue: 'Mapato ya mauzo', rep_cogs: 'Gharama ya bidhaa zilizouzwa', rep_gross: 'Faida ghafi', rep_net: 'Faida halisi', rep_margin: 'Asilimia ya faida',
  cash_flow: 'Mtiririko wa fedha', cash_in: 'Fedha zilizoingia', cash_out: 'Fedha zilizotoka', cash_net: 'Fedha halisi', daily_sales: 'Mauzo ya kila siku', top_products: 'Zinazouzika zaidi',
  expense_breakdown: 'Matumizi kwa aina', stock_valuation: 'Thamani ya stock', stock_at_cost: 'Stock kwa bei ya kununua', stock_at_retail: 'Stock kwa bei ya kuuza', expected_profit: 'Faida inayotarajiwa',

  // settings
  notifications: 'Arifa', notify_on: 'Arifa za tahadhari', notify_sub: 'Stock kuisha, muda wa bidhaa na mwenendo wa biashara', notify_test: 'Tuma arifa ya majaribio',
  notify_test_body: 'Arifa zinafanya kazi.', modules: 'Huduma (modules)', modules_sub: 'Washa au zima huduma kwa biashara hii.',
  delete_business: 'Futa biashara hii', delete_business_confirm: 'Futa "{name}" na data ZAKE ZOTE? Hili haliwezi kurudishwa.',
  account: 'Akaunti na usalama', current_password: 'Nenosiri la sasa', new_password: 'Nenosiri jipya', change_password: 'Badilisha nenosiri',
  backup: 'Backup na kurejesha', backup_sub: 'Hifadhi nakala ya data yako yote. Iweke salama (WhatsApp, Drive, barua pepe).',
  backup_export: 'Toa backup', backup_restore: 'Rejesha kutoka faili', backup_done: 'Backup iko tayari',
  restore_confirm: 'Rejesha backup hii? ITAFUTA na kubadilisha data yote iliyopo kwenye simu hii.', restore_done: 'Backup imerejeshwa', err_backup_file: 'Faili ya backup si sahihi.',

  // modules
  mod_sales: 'Mauzo', mod_inventory: 'Bidhaa na stock', mod_purchases: 'Ununuzi', mod_expenses: 'Matumizi', mod_customers: 'Wateja',
  mod_suppliers: 'Wasambazaji', mod_debts: 'Madeni', mod_employees: 'Wafanyakazi', mod_reports: 'Ripoti', mod_production: 'Uzalishaji', mod_expiry: 'Ufuatiliaji wa muda wa kuisha',

  // business types
  group_retail: 'Rejareja', group_health: 'Afya', group_agri: 'Kilimo na ufugaji', group_services: 'Huduma', group_other: 'Nyingine',
  type_shop: 'Duka', type_supermarket: 'Supermarket', type_electronics: 'Electronics', type_hardware: 'Hardware',
  type_pharmacy: 'Famasi', type_medical_store: 'Duka la dawa', type_farming: 'Kilimo', type_livestock: 'Mifugo', type_poultry: 'Ufugaji wa kuku',
  type_fish: 'Ufugaji wa samaki', type_salon: 'Saluni', type_restaurant: 'Mgahawa', type_garage: 'Gereji', type_consultancy: 'Ushauri', type_other: 'Nyingine (andika mwenyewe)',

  // units, payment methods
  unit_pcs: 'kipande', unit_kg: 'kg', unit_litre: 'lita', unit_box: 'boksi', unit_bag: 'gunia', unit_tray: 'trei', unit_dozen: 'dazeni', unit_meter: 'mita', unit_hour: 'saa', unit_service: 'huduma',
  method_cash: 'Pesa taslimu', method_mobile: 'Pesa ya simu', method_bank: 'Benki'
};
