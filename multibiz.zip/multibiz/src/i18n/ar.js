export default {
  // general
  yes: 'نعم', confirm: 'تأكيد', cancel: 'إلغاء', save: 'حفظ', saved: 'تم الحفظ', delete: 'حذف', edit: 'تعديل', add: 'إضافة',
  back: 'رجوع', next: 'التالي', finish: 'إنهاء', search: 'بحث…', new: 'جديد', share: 'مشاركة', copied: 'تم النسخ',
  date: 'التاريخ', name: 'الاسم', phone: 'الهاتف', address: 'العنوان', note: 'ملاحظة', category: 'الفئة', amount: 'المبلغ',
  price: 'السعر', qty: 'الكمية', total: 'الإجمالي', subtotal: 'المجموع الفرعي', discount: 'الخصم', paid: 'المدفوع', balance: 'الرصيد',
  method: 'طريقة الدفع', product: 'المنتج', supplier: 'المورّد', customer: 'العميل', service: 'خدمة', unit: 'الوحدة',
  kind: 'النوع', active: 'نشط', inactive: 'غير نشط', role: 'الوظيفة', salary: 'الراتب', history: 'السجل', payment: 'دفعة',
  purchase: 'مشتريات', receipt: 'إيصال', thank_you: 'شكراً لتعاملكم معنا!',

  // app
  nav_about: 'حول التطبيق', about_version: 'الإصدار {v}',
  app_tagline: 'أدِر نشاطاً تجارياً واحداً أو أكثر — بدون إنترنت وعلى هاتفك.', app_sub: 'مدير الأعمال', app_offline: 'يعمل بدون إنترنت',
  choose_language: 'اختر لغتك', language: 'اللغة',

  // onboarding
  ob_account_title: 'أنشئ حسابك', ob_account_sub: 'تبقى بياناتك على هذا الهاتف. لا حاجة للإنترنت.',
  full_name: 'الاسم الكامل', password: 'كلمة المرور', password_confirm: 'تأكيد كلمة المرور', password_hint: '4 أحرف على الأقل.',
  err_name: 'يرجى إدخال اسمك.', err_pin_short: 'يجب أن تتكوّن كلمة المرور من 4 أحرف على الأقل.', err_pin_match: 'كلمتا المرور غير متطابقتين.',
  ob_mode_title: 'ما هو نشاطك التجاري؟', ob_mode_sub: 'اختر نشاطاً واحداً أو عدة أنشطة. يمكنك إضافة المزيد لاحقاً.',
  mode_one: 'نشاط واحد', mode_one_sub: 'أدير نشاطاً تجارياً واحداً', mode_many: 'عدة أنشطة', mode_many_sub: 'أدير أكثر من نشاط',
  choose_type_one: 'اختر نوع نشاطك', choose_type_many: 'اختر جميع أنواع أنشطتك', err_choose_type: 'يرجى اختيار نوع نشاط واحد على الأقل.',
  ob_details_title: 'تفاصيل النشاط', ob_details_sub: 'سمِّ كل نشاط واختر عملته.',
  business_name: 'اسم النشاط', custom_type: 'صف نوع نشاطك', location: 'الموقع', currency: 'العملة',
  err_biz_name: 'كل نشاط يحتاج إلى اسم.', err_custom_type: 'يرجى وصف نوع نشاطك.',
  add_business: 'إضافة نشاط', business_type: 'نوع النشاط',
  ob_modules_title: 'اختر الوحدات', ob_modules_sub: 'اخترنا ما يناسب نشاطك. فعّل أو عطّل أي وحدة — ويمكنك التغيير لاحقاً.',

  // access gate
  gate_title: 'تفعيل MultiBiz',
  gate_sub: 'أدخل كلمة مرور الوصول لبدء استخدام هذا التطبيق.',
  gate_password: 'كلمة مرور الوصول',
  gate_button: 'متابعة',
  err_gate_wrong: 'كلمة مرور الوصول غير صحيحة. المحاولات المتبقية: {n}.',
  err_gate_locked: 'محاولات خاطئة كثيرة. حاول مجدداً بعد {m} دقيقة.',

  gate_help: 'للحصول على كلمة مرور الوصول، اتصل أو أرسل رسالة "password" إلى {phone}.',
  gate_call: 'اتصال',
  gate_sms: 'إرسال رسالة',

  // password recovery
  sec_title: 'استعادة كلمة المرور',
  sec_sub: 'أجب عن 3 أسئلة أمان. ستستخدمها إذا نسيت كلمة المرور.',
  sec_q1: 'ما هو اسمك المستعار (لقبك)؟',
  sec_q2: 'ما هو الاسم الثالث لوالدتك؟',
  sec_q3: 'أين وُلدت؟',
  sec_hint: 'لا فرق بين الأحرف الكبيرة والصغيرة. تذكّر إجاباتك كما كتبتها.',
  err_sec_fill: 'يرجى الإجابة عن الأسئلة الثلاثة.',
  recover_title: 'إعادة تعيين كلمة المرور',
  recover_sub: 'أجب عن أسئلة الأمان لإعادة تعيين كلمة المرور.',
  recover_verify: 'تحقق من الإجابات',
  err_sec_wrong: 'إجابة واحدة أو أكثر غير صحيحة. المحاولات المتبقية: {n}.',
  err_sec_locked: 'محاولات خاطئة كثيرة. حاول مجدداً بعد {m} دقيقة.',
  recover_none: 'لم تضبط أسئلة الأمان على هذا الهاتف. يمكنك استعادة نسخة احتياطية أو مسح كل البيانات والبدء من جديد.',
  recover_new_title: 'اختر كلمة مرور جديدة',
  recover_done: 'تم تغيير كلمة المرور. أهلاً بعودتك!',
  recover_erase: 'لا تستطيع الإجابة؟ امسح كل البيانات',
  back_to_login: 'العودة لتسجيل الدخول',
  sec_setup_title: 'فعّل استعادة كلمة المرور',
  sec_setup_sub: 'أضف 3 أسئلة أمان لتتمكن من إعادة تعيين كلمة المرور إذا نسيتها.',
  sec_later: 'لاحقاً',
  sec_settings: 'أسئلة الأمان',
  sec_status_on: 'أسئلة الأمان مفعّلة.',
  sec_status_off: 'غير مفعّلة — لن تتمكن من استعادة كلمة مرور منسية.',
  sec_change: 'ضبط / تغيير الأسئلة',

  // login
  hello_user: 'مرحباً، {name}', enter_password: 'أدخل كلمة المرور لفتح التطبيق', unlock: 'فتح',
  forgot_password: 'نسيت كلمة المرور؟', err_wrong_password: 'كلمة المرور غير صحيحة.', reset_app: 'مسح كل البيانات وإعادة الضبط',
  reset_warning: 'سيؤدي هذا إلى مسح جميع البيانات على هذا الهاتف (الأنشطة والمبيعات والمخزون…). يمكنك استعادتها لاحقاً من نسخة احتياطية إن وُجدت. هل تريد المتابعة؟',

  // navigation
  nav_main: 'الرئيسية', nav_trade: 'التجارة والمخزون', nav_finance: 'المالية', nav_people: 'الأشخاص',
  nav_dashboard: 'لوحة التحكم', nav_alerts: 'التنبيهات', nav_sales: 'المبيعات', nav_new_sale: 'بيع جديد', nav_products: 'المنتجات والخدمات',
  nav_purchases: 'المشتريات', nav_production: 'الإنتاج', nav_expenses: 'المصروفات', nav_debts: 'الديون', nav_reports: 'التقارير',
  nav_customers: 'العملاء', nav_suppliers: 'الموردون', nav_employees: 'الموظفون', nav_settings: 'الإعدادات',
  nav_add_expense: 'إضافة مصروف', nav_add_product: 'إضافة منتج', lock_app: 'قفل التطبيق', account_owner: 'المالك', my_businesses: 'أنشطتي',

  // dashboard
  stat_sales: 'مبيعات اليوم', stat_expenses: 'مصروفات اليوم', stat_profit: 'ربح اليوم', stat_stock_value: 'قيمة المخزون',
  stat_owed_to_me: 'مستحق لي', stat_i_owe: 'مستحق عليّ', n_sales: '{n} عمليات بيع', n_low: '{n} منخفضة', sales_7d: 'المبيعات — آخر 7 أيام',
  recent_activity: 'آخر العمليات', no_activity: 'لا شيء بعد', view_all: 'عرض الكل', production_today: 'إنتاج اليوم', sale_no: 'بيع رقم {n}',

  // alerts
  al_lvl_danger: 'خطر', al_lvl_warn: 'تحذير', al_lvl_good: 'أخبار جيدة',
  al_out_of_stock: 'نفد مخزون {name}',
  al_low_stock: '{name} على وشك النفاد — تبقّى {qty} {unit} فقط',
  al_running_out: 'سينفد {name} خلال نحو {days} يوم بمعدل مبيعاتك الحالي',
  al_expired: 'انتهت صلاحية {name} بتاريخ {date}',
  al_expiring: 'تنتهي صلاحية {name} خلال {days} يوم',
  al_sales_up: 'ارتفعت المبيعات {pct}% مقارنة بالأيام السبعة السابقة. عمل رائع!',
  al_sales_down: 'انخفضت المبيعات {pct}% مقارنة بالأيام السبعة السابقة',
  al_expenses_exceed: 'مصروفاتك هذا الأسبوع تتجاوز مبيعاتك بمقدار {amt}',
  al_expenses_up: 'ارتفعت المصروفات {pct}% مقارنة بالأيام السبعة السابقة',
  al_profit_negative: 'أنت تعمل بخسارة قدرها {amt} هذا الشهر',
  al_profit_good: 'ربح هذا الشهر {amt} (هامش {pct}%) — وضع ممتاز!',
  al_best_day: 'أفضل يوم مبيعات خلال آخر 30 يوماً: {amt} اليوم!',
  al_debts_high: 'العملاء مدينون لك بمبلغ {amt} — أكثر من نصف مبيعات آخر 30 يوماً',
  al_loss_high: 'خسائر {n} خلال آخر 3 أيام ({pct}%) — افحص الحالة الصحية والظروف',
  al_produce_down: 'انخفض الإنتاج {pct}% مقارنة بالأيام السبعة السابقة',
  al_produce_up: 'ارتفع الإنتاج {pct}% مقارنة بالأيام السبعة السابقة',
  no_alerts: 'كل شيء على ما يرام', no_alerts_sub: 'لا توجد تنبيهات حالياً. سننبهك عند اقتراب نفاد المخزون أو تغيّر الاتجاهات.', restock: 'إعادة التموين',

  // products
  no_products: 'لا توجد منتجات بعد', no_products_sub: 'اضغط + لإضافة أول منتج أو خدمة.', no_results: 'لا نتائج',
  filter_all: 'الكل', filter_low: 'مخزون منخفض', filter_expiry: 'تنتهي صلاحيتها', out_of_stock: 'نفد المخزون', low_stock: 'مخزون منخفض',
  in_stock: 'المتوفر', low_stock_level: 'نبّهني عندما يصل المخزون إلى أو دون', sell_price: 'سعر البيع', buy_price: 'سعر الشراء',
  expiry_date: 'تاريخ الانتهاء', adjust_stock: 'تعديل المخزون', archive: 'أرشفة', archive_confirm: 'أرشفة "{name}"؟ سيختفي من القوائم.',
  stock_history: 'حركة المخزون', add_product: 'إضافة منتج', edit_product: 'تعديل المنتج', kind_product: 'منتج (يُتابَع مخزونه)',
  kind_service: 'خدمة (بدون مخزون)', opening_qty: 'الكمية الافتتاحية', new_count: 'الكمية بعد الجرد', adjust_reason: 'السبب (تالف، إعادة جرد…)',
  mv_opening: 'رصيد افتتاحي', mv_purchase: 'شراء', mv_sale: 'بيع', mv_adjust: 'تعديل', mv_return: 'مرتجع',

  // sales
  cart: 'السلة', cart_empty: 'اضغط على منتج لإضافته', checkout: 'الدفع', complete_sale: 'إتمام البيع', custom_item: 'بند مخصص',
  custom_item_hint: 'استخدم "بند مخصص" لتسجيل بيع بدون قائمة منتجات.', walk_in: 'عميل عابر', amount_paid: 'المبلغ المدفوع الآن',
  on_credit: 'آجل', sale_saved: 'تم تسجيل البيع', no_sales: 'لا مبيعات في هذه الفترة', void_sale: 'إلغاء البيع',
  void_confirm: 'إلغاء هذا البيع؟ سيُعاد المخزون ويُستبعد من التقارير.', voided: 'ملغى',
  err_insufficient: 'المخزون غير كافٍ: {d}', err_empty_cart: 'أضف بنداً واحداً على الأقل.', err_credit_customer: 'اختر عميلاً للبيع بالآجل.',
  err_credit_supplier: 'اختر مورّداً للشراء بالآجل.', err_amount: 'أدخل مبلغاً صحيحاً.', err_over_balance: 'المبلغ أكبر من الرصيد ({d}).',
  err_has_balance: 'لا يزال لهذا الشخص رصيد غير مسدّد.',

  // purchases
  no_purchases: 'لا مشتريات في هذه الفترة', no_supplier: 'بدون مورّد', add_line: 'إضافة منتج آخر', unit_cost: 'التكلفة للوحدة', save_purchase: 'حفظ المشتريات',

  // expenses
  no_expenses: 'لا مصروفات في هذه الفترة', add_expense: 'إضافة مصروف', delete_confirm: 'حذف هذا السجل؟',
  cat_rent: 'الإيجار', cat_salary: 'الرواتب', cat_transport: 'النقل', cat_utilities: 'الكهرباء والماء', cat_airtime: 'رصيد وإنترنت',
  cat_tax: 'الضرائب والتراخيص', cat_supplies: 'مستلزمات', cat_repairs: 'الصيانة', cat_feed: 'الأعلاف والمدخلات', cat_other: 'أخرى',

  // people
  no_customers: 'لا يوجد عملاء بعد', no_suppliers: 'لا يوجد موردون بعد', add_customer: 'إضافة عميل', add_supplier: 'إضافة مورّد',
  debts_owed_to_me: 'مستحق لي', debts_i_owe: 'مستحق عليّ', no_debts: 'لا ديون مستحقة', receive_payment: 'استلام دفعة', make_payment: 'سداد دفعة',
  no_employees: 'لا يوجد موظفون بعد', add_employee: 'إضافة موظف', monthly_payroll: 'الرواتب الشهرية', pay_salary: 'دفع الراتب',
  pay_salary_confirm: 'تسجيل راتب {name} بمبلغ {amt} كمصروف؟',

  // production
  log_today: 'السجل اليومي', start_date: 'تاريخ البدء',
  unit_flock: 'قطيع', unit_herd: 'قطيع ماشية', unit_pond: 'حوض', unit_field: 'حقل',
  no_units_flock: 'لا توجد قطعان بعد', no_units_herd: 'لا توجد قطعان ماشية بعد', no_units_pond: 'لا توجد أحواض بعد', no_units_field: 'لا توجد حقول بعد',
  no_units_sub: 'اضغط + للإضافة ثم ابدأ التسجيل يومياً.',
  add_unit_flock: 'إضافة قطيع', add_unit_herd: 'إضافة قطيع ماشية', add_unit_pond: 'إضافة حوض', add_unit_field: 'إضافة حقل',
  count_birds: 'الطيور', count_animals: 'الحيوانات', count_fish: 'الأسماك', count_acres: 'الأفدنة',
  m_eggs: 'البيض', m_feed_kg: 'العلف (كجم)', m_mortality: 'النفوق', m_milk: 'الحليب (لتر)', m_deaths: 'النفوق', m_harvest_kg: 'المحصول (كجم)',

  // reports
  range_today: 'اليوم', range_week: '7 أيام', range_month: 'هذا الشهر', range_year: 'هذه السنة', range_all: 'الكل',
  profit_loss: 'الأرباح والخسائر', rep_revenue: 'إيرادات المبيعات', rep_cogs: 'تكلفة البضاعة المباعة', rep_gross: 'مجمل الربح', rep_net: 'صافي الربح', rep_margin: 'هامش الربح',
  cash_flow: 'التدفق النقدي', cash_in: 'النقد الداخل', cash_out: 'النقد الخارج', cash_net: 'صافي النقد', daily_sales: 'المبيعات اليومية', top_products: 'الأكثر مبيعاً',
  expense_breakdown: 'المصروفات حسب الفئة', stock_valuation: 'تقييم المخزون', stock_at_cost: 'المخزون بسعر التكلفة', stock_at_retail: 'المخزون بسعر البيع', expected_profit: 'الربح المتوقع',

  // settings
  notifications: 'الإشعارات', notify_on: 'إشعارات التنبيه', notify_sub: 'نفاد المخزون والصلاحية واتجاهات النشاط', notify_test: 'إرسال إشعار تجريبي',
  notify_test_body: 'الإشعارات تعمل بنجاح.', modules: 'الوحدات', modules_sub: 'فعّل الميزات أو عطّلها لهذا النشاط.',
  delete_business: 'حذف هذا النشاط', delete_business_confirm: 'حذف "{name}" وجميع بياناته؟ لا يمكن التراجع عن ذلك.',
  account: 'الحساب والأمان', current_password: 'كلمة المرور الحالية', new_password: 'كلمة المرور الجديدة', change_password: 'تغيير كلمة المرور',
  backup: 'النسخ الاحتياطي والاستعادة', backup_sub: 'احفظ نسخة من جميع بياناتك في مكان آمن (واتساب، درايف، البريد).',
  backup_export: 'تصدير نسخة احتياطية', backup_restore: 'استعادة من ملف', backup_done: 'النسخة الاحتياطية جاهزة',
  restore_confirm: 'استعادة هذه النسخة؟ سيتم استبدال جميع البيانات الموجودة على هذا الهاتف.', restore_done: 'تمت استعادة النسخة', err_backup_file: 'ملف النسخة الاحتياطية غير صالح.',

  // modules
  mod_sales: 'المبيعات', mod_inventory: 'المنتجات والمخزون', mod_purchases: 'المشتريات', mod_expenses: 'المصروفات', mod_customers: 'العملاء',
  mod_suppliers: 'الموردون', mod_debts: 'الديون', mod_employees: 'الموظفون', mod_reports: 'التقارير', mod_production: 'الإنتاج', mod_expiry: 'تتبع الصلاحية',

  // business types
  group_retail: 'التجزئة', group_health: 'الرعاية الصحية', group_agri: 'الزراعة', group_services: 'الخدمات', group_other: 'أخرى',
  type_shop: 'متجر', type_supermarket: 'سوبر ماركت', type_electronics: 'إلكترونيات', type_hardware: 'مواد بناء وأدوات',
  type_pharmacy: 'صيدلية', type_medical_store: 'مستلزمات طبية', type_farming: 'زراعة', type_livestock: 'ماشية', type_poultry: 'دواجن',
  type_fish: 'استزراع سمكي', type_salon: 'صالون', type_restaurant: 'مطعم', type_garage: 'ورشة سيارات', type_consultancy: 'استشارات', type_other: 'أخرى (مخصص)',

  // units, payment methods
  unit_pcs: 'قطعة', unit_kg: 'كجم', unit_litre: 'لتر', unit_box: 'صندوق', unit_bag: 'كيس', unit_tray: 'طبق', unit_dozen: 'دستة', unit_meter: 'متر', unit_hour: 'ساعة', unit_service: 'خدمة',
  method_cash: 'نقداً', method_mobile: 'محفظة موبايل', method_bank: 'بنك'
};
