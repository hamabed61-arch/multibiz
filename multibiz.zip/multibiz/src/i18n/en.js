export default {
  // general
  yes: 'Yes', confirm: 'Confirm', cancel: 'Cancel', save: 'Save', saved: 'Saved', delete: 'Delete', edit: 'Edit', add: 'Add',
  back: 'Back', next: 'Next', finish: 'Finish', search: 'Search…', new: 'New', share: 'Share', copied: 'Copied',
  date: 'Date', name: 'Name', phone: 'Phone', address: 'Address', note: 'Note', category: 'Category', amount: 'Amount',
  price: 'Price', qty: 'Qty', total: 'Total', subtotal: 'Subtotal', discount: 'Discount', paid: 'Paid', balance: 'Balance',
  method: 'Payment method', product: 'Product', supplier: 'Supplier', customer: 'Customer', service: 'Service', unit: 'Unit',
  kind: 'Type', active: 'Active', inactive: 'Inactive', role: 'Role', salary: 'Salary', history: 'History', payment: 'Payment',
  purchase: 'Purchase', receipt: 'Receipt', thank_you: 'Thank you for your business!',

  // app
  nav_about: 'About', about_version: 'Version {v}',
  app_tagline: 'Manage one business or many — offline, on your phone.', app_sub: 'Business manager', app_offline: 'Works offline',
  choose_language: 'Choose your language', language: 'Language',

  // onboarding
  ob_account_title: 'Create your account', ob_account_sub: 'Your data stays on this phone. No internet needed.',
  full_name: 'Full name', password: 'Password', password_confirm: 'Confirm password', password_hint: 'At least 4 characters.',
  err_name: 'Please enter your name.', err_pin_short: 'Password must be at least 4 characters.', err_pin_match: 'Passwords do not match.',
  ob_mode_title: 'What business do you run?', ob_mode_sub: 'Pick one business or several. You can add more later.',
  mode_one: 'One business', mode_one_sub: 'I run a single business', mode_many: 'Many businesses', mode_many_sub: 'I run more than one',
  choose_type_one: 'Choose your business type', choose_type_many: 'Choose all your business types', err_choose_type: 'Please choose at least one business type.',
  ob_details_title: 'Business details', ob_details_sub: 'Name each business and set its currency.',
  business_name: 'Business name', custom_type: 'Describe your business type', location: 'Location', currency: 'Currency',
  err_biz_name: 'Every business needs a name.', err_custom_type: 'Please describe your business type.',
  add_business: 'Add business', business_type: 'Business type',
  ob_modules_title: 'Choose modules', ob_modules_sub: 'We picked what fits your business. Turn anything on or off — you can change it later.',

  // access gate
  gate_title: 'Activate MultiBiz',
  gate_sub: 'Enter the access password to start using this app.',
  gate_password: 'Access password',
  gate_button: 'Continue',
  err_gate_wrong: 'Wrong access password. {n} attempt(s) left.',
  err_gate_locked: 'Too many wrong attempts. Try again in {m} minute(s).',

  // password recovery
  sec_title: 'Password recovery',
  sec_sub: 'Answer 3 security questions. You will use them if you forget your password.',
  sec_q1: 'What is your nickname?',
  sec_q2: 'What is your mother\'s third name?',
  sec_q3: 'Where were you born?',
  sec_hint: 'Answers are not case-sensitive. Remember them exactly as you type them.',
  err_sec_fill: 'Please answer all three questions.',
  recover_title: 'Reset password',
  recover_sub: 'Answer your security questions to reset your password.',
  recover_verify: 'Verify answers',
  err_sec_wrong: 'One or more answers are wrong. {n} attempt(s) left.',
  err_sec_locked: 'Too many wrong attempts. Try again in {m} minute(s).',
  recover_none: 'You haven\'t set recovery questions on this phone. You can restore a backup or erase all data and start again.',
  recover_new_title: 'Choose a new password',
  recover_done: 'Password changed. Welcome back!',
  recover_erase: 'Can\'t answer? Erase all data',
  back_to_login: 'Back to login',
  sec_setup_title: 'Set up password recovery',
  sec_setup_sub: 'Add 3 security questions so you can reset your password if you forget it.',
  sec_later: 'Later',
  sec_settings: 'Recovery questions',
  sec_status_on: 'Recovery questions are set.',
  sec_status_off: 'Not set — you won\'t be able to reset a forgotten password.',
  sec_change: 'Set / change questions',

  // login
  hello_user: 'Hello, {name}', enter_password: 'Enter your password to open the app', unlock: 'Unlock',
  forgot_password: 'Forgot password?', err_wrong_password: 'Wrong password.', reset_app: 'Erase all data & reset',
  reset_warning: 'This erases ALL data on this phone (businesses, sales, stock…). Restore from a backup afterwards if you have one. Continue?',

  // navigation
  nav_main: 'Main', nav_trade: 'Trade & stock', nav_finance: 'Finance', nav_people: 'People',
  nav_dashboard: 'Dashboard', nav_alerts: 'Alerts', nav_sales: 'Sales', nav_new_sale: 'New sale', nav_products: 'Products & services',
  nav_purchases: 'Purchases', nav_production: 'Production', nav_expenses: 'Expenses', nav_debts: 'Debts', nav_reports: 'Reports',
  nav_customers: 'Customers', nav_suppliers: 'Suppliers', nav_employees: 'Employees', nav_settings: 'Settings',
  nav_add_expense: 'Add expense', nav_add_product: 'Add product', lock_app: 'Lock app', account_owner: 'Owner', my_businesses: 'My businesses',

  // dashboard
  stat_sales: "Today's sales", stat_expenses: "Today's expenses", stat_profit: "Today's profit", stat_stock_value: 'Stock value',
  stat_owed_to_me: 'Owed to me', stat_i_owe: 'I owe', n_sales: '{n} sales', n_low: '{n} low', sales_7d: 'Sales — last 7 days',
  recent_activity: 'Recent activity', no_activity: 'Nothing yet', view_all: 'View all', production_today: "Today's production", sale_no: 'Sale #{n}',

  // alerts
  al_lvl_danger: 'Danger', al_lvl_warn: 'Warning', al_lvl_good: 'Good news',
  al_out_of_stock: '{name} is out of stock',
  al_low_stock: '{name} is running low — only {qty} {unit} left',
  al_running_out: '{name} will run out in about {days} day(s) at your current sales rate',
  al_expired: '{name} expired on {date}',
  al_expiring: '{name} expires in {days} day(s)',
  al_sales_up: 'Sales are up {pct}% compared with the previous 7 days. Great work!',
  al_sales_down: 'Sales are down {pct}% compared with the previous 7 days',
  al_expenses_exceed: 'This week your expenses are {amt} higher than your sales',
  al_expenses_up: 'Expenses rose {pct}% compared with the previous 7 days',
  al_profit_negative: 'This month you are running at a loss of {amt}',
  al_profit_good: "This month's profit is {amt} ({pct}% margin) — healthy!",
  al_best_day: 'Best sales day in the last 30 days: {amt} today!',
  al_debts_high: 'Customers owe you {amt} — more than half of your last 30 days of sales',
  al_loss_high: '{n} lost in the last 3 days ({pct}%) — check health and conditions',
  al_produce_down: 'Production is down {pct}% compared with the previous 7 days',
  al_produce_up: 'Production is up {pct}% compared with the previous 7 days',
  no_alerts: 'All clear', no_alerts_sub: 'No alerts right now. We will warn you when stock runs low or trends change.', restock: 'Restock',

  // products
  no_products: 'No products yet', no_products_sub: 'Tap + to add your first product or service.', no_results: 'No results',
  filter_all: 'All', filter_low: 'Low stock', filter_expiry: 'Expiring', out_of_stock: 'Out of stock', low_stock: 'Low stock',
  in_stock: 'In stock', low_stock_level: 'Alert me when stock is at or below', sell_price: 'Selling price', buy_price: 'Buying price',
  expiry_date: 'Expiry date', adjust_stock: 'Adjust stock', archive: 'Archive', archive_confirm: 'Archive "{name}"? It will be hidden from lists.',
  stock_history: 'Stock movements', add_product: 'Add product', edit_product: 'Edit product', kind_product: 'Product (tracked in stock)',
  kind_service: 'Service (no stock)', opening_qty: 'Opening quantity', new_count: 'Counted quantity', adjust_reason: 'Reason (damaged, recount…)',
  mv_opening: 'Opening stock', mv_purchase: 'Purchase', mv_sale: 'Sale', mv_adjust: 'Adjustment', mv_return: 'Returned',

  // sales
  cart: 'Cart', cart_empty: 'Tap a product to add it', checkout: 'Checkout', complete_sale: 'Complete sale', custom_item: 'Custom item',
  custom_item_hint: 'Use "Custom item" to record a sale without a product list.', walk_in: 'Walk-in customer', amount_paid: 'Amount paid now',
  on_credit: 'On credit', sale_saved: 'Sale recorded', no_sales: 'No sales in this period', void_sale: 'Cancel sale',
  void_confirm: 'Cancel this sale? Stock will be returned and it will be removed from reports.', voided: 'Cancelled',
  err_insufficient: 'Not enough stock: {d}', err_empty_cart: 'Add at least one item.', err_credit_customer: 'Choose a customer to sell on credit.',
  err_credit_supplier: 'Choose a supplier to buy on credit.', err_amount: 'Enter a valid amount.', err_over_balance: 'Amount is more than the balance ({d}).',
  err_has_balance: 'This contact still has an unpaid balance.',

  // purchases
  no_purchases: 'No purchases in this period', no_supplier: 'No supplier', add_line: 'Add another product', unit_cost: 'Cost per unit', save_purchase: 'Save purchase',

  // expenses
  no_expenses: 'No expenses in this period', add_expense: 'Add expense', delete_confirm: 'Delete this record?',
  cat_rent: 'Rent', cat_salary: 'Salaries', cat_transport: 'Transport', cat_utilities: 'Electricity & water', cat_airtime: 'Airtime & internet',
  cat_tax: 'Taxes & licences', cat_supplies: 'Supplies', cat_repairs: 'Repairs', cat_feed: 'Feed & inputs', cat_other: 'Other',

  // people
  no_customers: 'No customers yet', no_suppliers: 'No suppliers yet', add_customer: 'Add customer', add_supplier: 'Add supplier',
  debts_owed_to_me: 'Owed to me', debts_i_owe: 'I owe', no_debts: 'No outstanding debts', receive_payment: 'Receive payment', make_payment: 'Make payment',
  no_employees: 'No employees yet', add_employee: 'Add employee', monthly_payroll: 'Monthly payroll', pay_salary: 'Pay salary',
  pay_salary_confirm: 'Record salary of {amt} for {name} as an expense?',

  // production
  log_today: 'Daily log', start_date: 'Start date',
  unit_flock: 'Flock', unit_herd: 'Herd', unit_pond: 'Pond', unit_field: 'Field',
  no_units_flock: 'No flocks yet', no_units_herd: 'No herds yet', no_units_pond: 'No ponds yet', no_units_field: 'No fields yet',
  no_units_sub: 'Tap + to add one and start recording every day.',
  add_unit_flock: 'Add flock', add_unit_herd: 'Add herd', add_unit_pond: 'Add pond', add_unit_field: 'Add field',
  count_birds: 'Birds', count_animals: 'Animals', count_fish: 'Fish', count_acres: 'Acres',
  m_eggs: 'Eggs', m_feed_kg: 'Feed (kg)', m_mortality: 'Mortality', m_milk: 'Milk (litres)', m_deaths: 'Deaths', m_harvest_kg: 'Harvest (kg)',

  // reports
  range_today: 'Today', range_week: '7 days', range_month: 'This month', range_year: 'This year', range_all: 'All',
  profit_loss: 'Profit & loss', rep_revenue: 'Sales revenue', rep_cogs: 'Cost of goods sold', rep_gross: 'Gross profit', rep_net: 'Net profit', rep_margin: 'Net margin',
  cash_flow: 'Cash flow', cash_in: 'Cash in', cash_out: 'Cash out', cash_net: 'Net cash', daily_sales: 'Daily sales', top_products: 'Top sellers',
  expense_breakdown: 'Expenses by category', stock_valuation: 'Stock valuation', stock_at_cost: 'Stock at cost', stock_at_retail: 'Stock at selling price', expected_profit: 'Expected profit',

  // settings
  notifications: 'Notifications', notify_on: 'Alert notifications', notify_sub: 'Low stock, expiry and business trends', notify_test: 'Send a test notification',
  notify_test_body: 'Notifications are working.', modules: 'Modules', modules_sub: 'Turn features on or off for this business.',
  delete_business: 'Delete this business', delete_business_confirm: 'Delete "{name}" and ALL its data? This cannot be undone.',
  account: 'Account & security', current_password: 'Current password', new_password: 'New password', change_password: 'Change password',
  backup: 'Backup & restore', backup_sub: 'Save a copy of all your data. Keep it safe (WhatsApp, Drive, email).',
  backup_export: 'Export backup', backup_restore: 'Restore from file', backup_done: 'Backup ready',
  restore_confirm: 'Restore this backup? It REPLACES all data currently on this phone.', restore_done: 'Backup restored', err_backup_file: 'Invalid backup file.',

  // modules
  mod_sales: 'Sales', mod_inventory: 'Products & stock', mod_purchases: 'Purchases', mod_expenses: 'Expenses', mod_customers: 'Customers',
  mod_suppliers: 'Suppliers', mod_debts: 'Debts', mod_employees: 'Employees', mod_reports: 'Reports', mod_production: 'Production', mod_expiry: 'Expiry tracking',

  // business types
  group_retail: 'Retail', group_health: 'Healthcare', group_agri: 'Agriculture', group_services: 'Services', group_other: 'Other',
  type_shop: 'Shop', type_supermarket: 'Supermarket', type_electronics: 'Electronics', type_hardware: 'Hardware',
  type_pharmacy: 'Pharmacy', type_medical_store: 'Medical store', type_farming: 'Farming', type_livestock: 'Livestock', type_poultry: 'Poultry',
  type_fish: 'Fish farming', type_salon: 'Salon', type_restaurant: 'Restaurant', type_garage: 'Garage', type_consultancy: 'Consultancy', type_other: 'Other (custom)',

  // units, payment methods
  unit_pcs: 'pcs', unit_kg: 'kg', unit_litre: 'litre', unit_box: 'box', unit_bag: 'bag', unit_tray: 'tray', unit_dozen: 'dozen', unit_meter: 'metre', unit_hour: 'hour', unit_service: 'service',
  method_cash: 'Cash', method_mobile: 'Mobile money', method_bank: 'Bank'
};
