// data.js - mantiki yote ya biashara (SQLite): biashara, bidhaa, mauzo, ununuzi, madeni, ripoti...
import { all, one, val, run, tx, uid, now, dateStr, addDays } from './db/index.js';
import { typeInfo } from './templates.js';

const fail = (code, detail) => Object.assign(new Error(code), { code, detail });
const like = (q) => `%${String(q).trim().toLowerCase()}%`;
const at = (date) => (date && date !== dateStr() ? `${date} 12:00:00` : now());

// ═══════════ BUSINESSES ═══════════
export const listBusinesses = () => all('SELECT * FROM businesses ORDER BY sort, created_at');
export const getBusiness = (id) => one('SELECT * FROM businesses WHERE id = ?', [id]);

export async function createBusiness(b) {
  const id = uid();
  const sort = await val('SELECT COALESCE(MAX(sort),0)+1 FROM businesses');
  const modules = b.modules || typeInfo(b.type).modules;
  await run(
    `INSERT INTO businesses (id, name, type, custom_type, location, phone, currency, modules, sort, created_at, updated_at)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [id, b.name, b.type, b.custom_type || null, b.location || null, b.phone || null, b.currency || 'TZS', JSON.stringify(modules), sort, now(), now()]
  );
  return id;
}

export async function updateBusiness(id, f) {
  await run(
    `UPDATE businesses SET name=?, custom_type=?, location=?, phone=?, currency=?, updated_at=? WHERE id=?`,
    [f.name, f.custom_type || null, f.location || null, f.phone || null, f.currency, now(), id]
  );
}

export const saveModules = (id, modules) =>
  run('UPDATE businesses SET modules=?, updated_at=? WHERE id=?', [JSON.stringify(modules), now(), id]);

export async function deleteBusiness(id) {
  await tx(async () => {
    for (const tname of ['stock_movements', 'sale_items', 'purchase_items', 'sales', 'purchases', 'expenses', 'payments', 'products',
      'customers', 'suppliers', 'employees', 'production_logs', 'production_units', 'alerts']) {
      await run(`DELETE FROM ${tname} WHERE business_id = ?`, [id]);
    }
    await run('DELETE FROM businesses WHERE id = ?', [id]);
  });
}

// ═══════════ PRODUCTS / STOCK ═══════════
const STOCK_SQL = `(SELECT COALESCE(SUM(m.qty),0) FROM stock_movements m WHERE m.product_id = p.id)`;

export async function listProducts(bizId, { q = '', includeInactive = false } = {}) {
  const args = [bizId];
  let where = 'p.business_id = ?';
  if (!includeInactive) where += ' AND p.active = 1';
  if (q) { where += ' AND (LOWER(p.name) LIKE ? OR LOWER(COALESCE(p.category,\'\')) LIKE ?)'; args.push(like(q), like(q)); }
  return all(`SELECT p.*, ${STOCK_SQL} AS stock,
      EXISTS(SELECT 1 FROM stock_movements m WHERE m.product_id = p.id) AS has_moves
      FROM products p WHERE ${where} ORDER BY p.name COLLATE NOCASE`, args);
}

export const getProduct = (id) => one(`SELECT p.*, ${STOCK_SQL} AS stock FROM products p WHERE p.id = ?`, [id]);

export async function saveProduct(bizId, f, id = null) {
  const track = f.kind === 'service' ? 0 : 1;
  if (id) {
    await run(
      `UPDATE products SET name=?, category=?, unit=?, kind=?, track_stock=?, buy_price=?, sell_price=?, low_stock=?, expiry_date=?, updated_at=? WHERE id=?`,
      [f.name, f.category || null, f.unit || null, f.kind, track, f.buy_price, f.sell_price, f.low_stock, f.expiry_date || null, now(), id]
    );
    return id;
  }
  const pid = uid();
  await tx(async () => {
    await run(
      `INSERT INTO products (id, business_id, name, category, unit, kind, track_stock, buy_price, sell_price, low_stock, expiry_date, active, created_at, updated_at)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,1,?,?)`,
      [pid, bizId, f.name, f.category || null, f.unit || null, f.kind, track, f.buy_price, f.sell_price, f.low_stock, f.expiry_date || null, now(), now()]
    );
    if (track && f.opening_qty > 0) {
      await run(
        `INSERT INTO stock_movements (id, business_id, product_id, type, qty, unit_cost, note, created_at) VALUES (?,?,?,?,?,?,?,?)`,
        [uid(), bizId, pid, 'opening', f.opening_qty, f.buy_price, null, now()]
      );
    }
  });
  return pid;
}

export const archiveProduct = (id) => run('UPDATE products SET active = 0, updated_at = ? WHERE id = ?', [now(), id]);

// weka idadi mpya (count) - tofauti inarekodiwa kama adjustment
export async function setStock(bizId, productId, newQty, note) {
  const cur = await val('SELECT COALESCE(SUM(qty),0) FROM stock_movements WHERE product_id = ?', [productId]);
  const diff = newQty - cur;
  if (diff === 0) return;
  const p = await getProduct(productId);
  await run(
    `INSERT INTO stock_movements (id, business_id, product_id, type, qty, unit_cost, note, created_at) VALUES (?,?,?,?,?,?,?,?)`,
    [uid(), bizId, productId, 'adjust', diff, p.buy_price, note || null, now()]
  );
}

export const stockMovements = (productId) =>
  all('SELECT * FROM stock_movements WHERE product_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 30', [productId]);

// ═══════════ CUSTOMERS / SUPPLIERS ═══════════
const PARTY = {
  customer: { table: 'customers', owing: `COALESCE((SELECT SUM(s.total - s.paid) FROM sales s WHERE s.customer_id = x.id AND s.status = 'ok'),0)` },
  supplier: { table: 'suppliers', owing: `COALESCE((SELECT SUM(pu.total - pu.paid) FROM purchases pu WHERE pu.supplier_id = x.id),0)` }
};
const paidSql = (kind) => `COALESCE((SELECT SUM(pm.amount) FROM payments pm WHERE pm.party_type = '${kind}' AND pm.party_id = x.id),0)`;

export async function listParties(kind, bizId, q = '') {
  const P = PARTY[kind];
  const args = [bizId];
  let where = 'x.business_id = ?';
  if (q) { where += ' AND (LOWER(x.name) LIKE ? OR COALESCE(x.phone,\'\') LIKE ?)'; args.push(like(q), like(q)); }
  return all(`SELECT x.*, (${P.owing} - ${paidSql(kind)}) AS balance FROM ${P.table} x WHERE ${where} ORDER BY x.name COLLATE NOCASE`, args);
}

export async function getParty(kind, id) {
  const P = PARTY[kind];
  return one(`SELECT x.*, (${P.owing} - ${paidSql(kind)}) AS balance FROM ${P.table} x WHERE x.id = ?`, [id]);
}

export async function saveParty(kind, bizId, f, id = null) {
  const table = PARTY[kind].table;
  if (id) {
    await run(`UPDATE ${table} SET name=?, phone=?, address=?, note=?, updated_at=? WHERE id=?`, [f.name, f.phone || null, f.address || null, f.note || null, now(), id]);
    return id;
  }
  const nid = uid();
  await run(`INSERT INTO ${table} (id, business_id, name, phone, address, note, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?)`,
    [nid, bizId, f.name, f.phone || null, f.address || null, f.note || null, now(), now()]);
  return nid;
}

export async function deleteParty(kind, id) {
  const bal = (await getParty(kind, id))?.balance || 0;
  if (Math.abs(bal) > 0.009) throw fail('has_balance');
  const col = kind === 'customer' ? 'customer_id' : 'supplier_id';
  const tbl = kind === 'customer' ? 'sales' : 'purchases';
  await run(`UPDATE ${tbl} SET ${col} = NULL WHERE ${col} = ?`, [id]);
  await run(`DELETE FROM payments WHERE party_type = ? AND party_id = ?`, [kind, id]);
  await run(`DELETE FROM ${PARTY[kind].table} WHERE id = ?`, [id]);
}

export async function recordPayment(bizId, kind, partyId, amount, method = 'cash', note = '') {
  if (!(amount > 0)) throw fail('bad_amount');
  const party = await getParty(kind, partyId);
  if (amount > party.balance + 0.009) throw fail('over_balance', party.balance);
  await run(`INSERT INTO payments (id, business_id, party_type, party_id, amount, method, note, created_at) VALUES (?,?,?,?,?,?,?,?)`,
    [uid(), bizId, kind, partyId, amount, method, note || null, now()]);
}

// historia ya mteja/msambazaji: mauzo/ununuzi + malipo
export async function partyHistory(kind, id) {
  const src = kind === 'customer'
    ? `SELECT 'sale' AS t, id, total AS amount, paid, created_at, receipt_no AS ref FROM sales WHERE customer_id = ? AND status = 'ok'`
    : `SELECT 'purchase' AS t, id, total AS amount, paid, created_at, NULL AS ref FROM purchases WHERE supplier_id = ?`;
  return all(`${src} UNION ALL SELECT 'payment', id, amount, amount, created_at, NULL FROM payments WHERE party_type = ? AND party_id = ? ORDER BY created_at DESC LIMIT 40`,
    [id, kind, id]);
}

export async function debtTotals(bizId) {
  const owedToMe = await val(`SELECT COALESCE(SUM(total - paid),0) FROM sales WHERE business_id = ? AND status = 'ok'`, [bizId])
    - await val(`SELECT COALESCE(SUM(amount),0) FROM payments WHERE business_id = ? AND party_type = 'customer'`, [bizId]);
  const iOwe = await val(`SELECT COALESCE(SUM(total - paid),0) FROM purchases WHERE business_id = ?`, [bizId])
    - await val(`SELECT COALESCE(SUM(amount),0) FROM payments WHERE business_id = ? AND party_type = 'supplier'`, [bizId]);
  return { owedToMe: Math.max(0, owedToMe), iOwe: Math.max(0, iOwe) };
}

// ═══════════ SALES ═══════════
// items: [{ product_id|null, name, qty, price, cost, track }]
export async function createSale(bizId, s) {
  const items = s.items.filter((i) => i.qty > 0);
  if (!items.length) throw fail('empty_cart');
  const subtotal = items.reduce((a, i) => a + i.qty * i.price, 0);
  const discount = Math.min(Math.max(s.discount || 0, 0), subtotal);
  const total = subtotal - discount;
  const paid = Math.min(Math.max(s.paid ?? total, 0), total);
  if (paid < total - 0.009 && !s.customer_id) throw fail('credit_needs_customer');

  return tx(async () => {
    // ukaguzi wa stock
    const need = {};
    for (const i of items) if (i.product_id && i.track) need[i.product_id] = (need[i.product_id] || 0) + i.qty;
    for (const pid of Object.keys(need)) {
      const stock = await val('SELECT COALESCE(SUM(qty),0) FROM stock_movements WHERE product_id = ?', [pid]);
      if (stock + 1e-9 < need[pid]) {
        const p = await one('SELECT name FROM products WHERE id = ?', [pid]);
        throw fail('insufficient', `${p.name} (${stock})`);
      }
    }
    const id = uid();
    const receipt = await val('SELECT COALESCE(MAX(receipt_no),0)+1 FROM sales WHERE business_id = ?', [bizId]);
    const ts = now();
    await run(
      `INSERT INTO sales (id, business_id, receipt_no, customer_id, subtotal, discount, total, paid, method, status, note, created_at)
       VALUES (?,?,?,?,?,?,?,?,?,'ok',?,?)`,
      [id, bizId, receipt, s.customer_id || null, subtotal, discount, total, paid, s.method || 'cash', s.note || null, ts]
    );
    for (const i of items) {
      await run(`INSERT INTO sale_items (id, sale_id, business_id, product_id, name, qty, unit_price, unit_cost) VALUES (?,?,?,?,?,?,?,?)`,
        [uid(), id, bizId, i.product_id || null, i.name, i.qty, i.price, i.cost || 0]);
      if (i.product_id && i.track) {
        await run(`INSERT INTO stock_movements (id, business_id, product_id, type, qty, unit_cost, ref_id, created_at) VALUES (?,?,?,?,?,?,?,?)`,
          [uid(), bizId, i.product_id, 'sale', -i.qty, i.cost || 0, id, ts]);
      }
    }
    return { id, receipt, total, paid };
  });
}

export async function listSales(bizId, from, to) {
  return all(
    `SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id = s.customer_id
     WHERE s.business_id = ? AND date(s.created_at) BETWEEN ? AND ? ORDER BY s.created_at DESC, s.rowid DESC`, [bizId, from, to]);
}

export async function getSale(id) {
  const s = await one(`SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id = s.customer_id WHERE s.id = ?`, [id]);
  if (s) s.items = await all('SELECT * FROM sale_items WHERE sale_id = ?', [id]);
  return s;
}

export async function voidSale(id) {
  await tx(async () => {
    const s = await getSale(id);
    if (!s || s.status !== 'ok') return;
    await run(`UPDATE sales SET status = 'void' WHERE id = ?`, [id]);
    for (const i of s.items) {
      const p = i.product_id ? await one('SELECT track_stock FROM products WHERE id = ?', [i.product_id]) : null;
      if (p && p.track_stock) {
        await run(`INSERT INTO stock_movements (id, business_id, product_id, type, qty, unit_cost, ref_id, note, created_at) VALUES (?,?,?,?,?,?,?,?,?)`,
          [uid(), s.business_id, i.product_id, 'return', i.qty, i.unit_cost, id, 'void', now()]);
      }
    }
  });
}

// ═══════════ PURCHASES ═══════════
// items: [{ product_id, name, qty, cost, expiry }]
export async function createPurchase(bizId, p) {
  const items = p.items.filter((i) => i.qty > 0);
  if (!items.length) throw fail('empty_cart');
  const total = items.reduce((a, i) => a + i.qty * i.cost, 0);
  const paid = Math.min(Math.max(p.paid ?? total, 0), total);
  if (paid < total - 0.009 && !p.supplier_id) throw fail('credit_needs_supplier');
  return tx(async () => {
    const id = uid();
    const ts = now();
    await run(`INSERT INTO purchases (id, business_id, supplier_id, total, paid, note, created_at) VALUES (?,?,?,?,?,?,?)`,
      [id, bizId, p.supplier_id || null, total, paid, p.note || null, ts]);
    for (const i of items) {
      await run(`INSERT INTO purchase_items (id, purchase_id, business_id, product_id, name, qty, unit_cost) VALUES (?,?,?,?,?,?,?)`,
        [uid(), id, bizId, i.product_id, i.name, i.qty, i.cost]);
      await run(`INSERT INTO stock_movements (id, business_id, product_id, type, qty, unit_cost, ref_id, created_at) VALUES (?,?,?,?,?,?,?,?)`,
        [uid(), bizId, i.product_id, 'purchase', i.qty, i.cost, id, ts]);
      await run(`UPDATE products SET buy_price = ?, expiry_date = COALESCE(?, expiry_date), updated_at = ? WHERE id = ?`,
        [i.cost, i.expiry || null, ts, i.product_id]);
    }
    return { id, total, paid };
  });
}

export async function listPurchases(bizId, from, to) {
  return all(
    `SELECT p.*, s.name AS supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id
     WHERE p.business_id = ? AND date(p.created_at) BETWEEN ? AND ? ORDER BY p.created_at DESC, p.rowid DESC`, [bizId, from, to]);
}

export async function getPurchase(id) {
  const p = await one(`SELECT p.*, s.name AS supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id = p.supplier_id WHERE p.id = ?`, [id]);
  if (p) p.items = await all('SELECT * FROM purchase_items WHERE purchase_id = ?', [id]);
  return p;
}

// ═══════════ EXPENSES ═══════════
export async function addExpense(bizId, f) {
  if (!(f.amount > 0)) throw fail('bad_amount');
  await run(`INSERT INTO expenses (id, business_id, category, amount, note, created_at) VALUES (?,?,?,?,?,?)`,
    [uid(), bizId, f.category, f.amount, f.note || null, at(f.date)]);
}
export const listExpenses = (bizId, from, to) =>
  all(`SELECT * FROM expenses WHERE business_id = ? AND date(created_at) BETWEEN ? AND ? ORDER BY created_at DESC, rowid DESC`, [bizId, from, to]);
export const deleteExpense = (id) => run('DELETE FROM expenses WHERE id = ?', [id]);

// ═══════════ EMPLOYEES ═══════════
export const listEmployees = (bizId) => all('SELECT * FROM employees WHERE business_id = ? ORDER BY active DESC, name COLLATE NOCASE', [bizId]);
export async function saveEmployee(bizId, f, id = null) {
  if (id) {
    await run('UPDATE employees SET name=?, phone=?, role=?, salary=?, active=?, updated_at=? WHERE id=?', [f.name, f.phone || null, f.role || null, f.salary, f.active ? 1 : 0, now(), id]);
    return id;
  }
  const nid = uid();
  await run('INSERT INTO employees (id, business_id, name, phone, role, salary, active, created_at, updated_at) VALUES (?,?,?,?,?,?,1,?,?)',
    [nid, bizId, f.name, f.phone || null, f.role || null, f.salary, now(), now()]);
  return nid;
}
export const deleteEmployee = (id) => run('DELETE FROM employees WHERE id = ?', [id]);
export const paySalary = (bizId, emp, amount) => addExpense(bizId, { category: 'salary', amount, note: emp.name });

// ═══════════ PRODUCTION (kuku, mifugo, kilimo, samaki) ═══════════
export const listUnits = (bizId) => all(
  `SELECT u.*,
     COALESCE((SELECT SUM(l.value) FROM production_logs l WHERE l.unit_id = u.id AND l.metric = 'loss'),0) AS lost,
     COALESCE((SELECT SUM(l.value) FROM production_logs l WHERE l.unit_id = u.id AND l.metric = 'produce'),0) AS produced
   FROM production_units u WHERE u.business_id = ? ORDER BY u.active DESC, u.created_at DESC`, [bizId]);

export async function saveUnit(bizId, f, id = null) {
  if (id) {
    await run('UPDATE production_units SET name=?, count=?, started_at=?, note=?, active=? WHERE id=?', [f.name, f.count, f.started_at || null, f.note || null, f.active ? 1 : 0, id]);
    return id;
  }
  const nid = uid();
  await run('INSERT INTO production_units (id, business_id, name, count, started_at, note, active, created_at) VALUES (?,?,?,?,?,?,1,?)',
    [nid, bizId, f.name, f.count, f.started_at || dateStr(), f.note || null, now()]);
  return nid;
}

export async function deleteUnit(id) {
  await run('DELETE FROM production_logs WHERE unit_id = ?', [id]);
  await run('DELETE FROM production_units WHERE id = ?', [id]);
}

// metrics: { produce: 12, feed: 3, loss: 1 }
export async function addLog(bizId, unitId, date, metrics, note) {
  await tx(async () => {
    for (const [metric, value] of Object.entries(metrics)) {
      if (!(value > 0)) continue;
      await run('INSERT INTO production_logs (id, business_id, unit_id, log_date, metric, value, note, created_at) VALUES (?,?,?,?,?,?,?,?)',
        [uid(), bizId, unitId, date, metric, value, note || null, now()]);
    }
  });
}

export const unitLogs = (unitId) => all(
  `SELECT log_date, metric, SUM(value) AS value FROM production_logs WHERE unit_id = ? GROUP BY log_date, metric ORDER BY log_date DESC LIMIT 45`, [unitId]);

export const productionTotals = (bizId, from, to) => all(
  `SELECT metric, COALESCE(SUM(value),0) AS value FROM production_logs WHERE business_id = ? AND log_date BETWEEN ? AND ? GROUP BY metric`, [bizId, from, to]);

// ═══════════ REPORTS ═══════════
export async function summary(bizId, from, to) {
  const rng = [bizId, from, to];
  const revenue = await val(`SELECT COALESCE(SUM(total),0) FROM sales WHERE business_id=? AND status='ok' AND date(created_at) BETWEEN ? AND ?`, rng);
  const cogs = await val(
    `SELECT COALESCE(SUM(si.qty * si.unit_cost),0) FROM sale_items si JOIN sales s ON s.id = si.sale_id
     WHERE s.business_id=? AND s.status='ok' AND date(s.created_at) BETWEEN ? AND ?`, rng);
  const expenses = await val(`SELECT COALESCE(SUM(amount),0) FROM expenses WHERE business_id=? AND date(created_at) BETWEEN ? AND ?`, rng);
  const salesCount = await val(`SELECT COUNT(*) FROM sales WHERE business_id=? AND status='ok' AND date(created_at) BETWEEN ? AND ?`, rng);
  const purchases = await val(`SELECT COALESCE(SUM(total),0) FROM purchases WHERE business_id=? AND date(created_at) BETWEEN ? AND ?`, rng);
  const cashIn = await val(`SELECT COALESCE(SUM(paid),0) FROM sales WHERE business_id=? AND status='ok' AND date(created_at) BETWEEN ? AND ?`, rng)
    + await val(`SELECT COALESCE(SUM(amount),0) FROM payments WHERE business_id=? AND party_type='customer' AND date(created_at) BETWEEN ? AND ?`, rng);
  const cashOut = await val(`SELECT COALESCE(SUM(paid),0) FROM purchases WHERE business_id=? AND date(created_at) BETWEEN ? AND ?`, rng)
    + expenses
    + await val(`SELECT COALESCE(SUM(amount),0) FROM payments WHERE business_id=? AND party_type='supplier' AND date(created_at) BETWEEN ? AND ?`, rng);
  const gross = revenue - cogs;
  return { revenue, cogs, gross, expenses, net: gross - expenses, salesCount, purchases, cashIn, cashOut, cashFlow: cashIn - cashOut };
}

export async function dailySeries(bizId, from, to) {
  const rows = await all(
    `SELECT date(created_at) AS d, SUM(total) AS v FROM sales WHERE business_id=? AND status='ok' AND date(created_at) BETWEEN ? AND ? GROUP BY date(created_at)`,
    [bizId, from, to]);
  const map = Object.fromEntries(rows.map((r) => [r.d, r.v]));
  const out = [];
  for (let d = new Date(from + 'T00:00:00'); dateStr(d) <= to; d = addDays(d, 1)) out.push({ d: dateStr(d), v: map[dateStr(d)] || 0 });
  return out;
}

export const topProducts = (bizId, from, to, limit = 5) => all(
  `SELECT si.name AS name, SUM(si.qty) AS qty, SUM(si.qty * si.unit_price) AS revenue
   FROM sale_items si JOIN sales s ON s.id = si.sale_id
   WHERE s.business_id=? AND s.status='ok' AND date(s.created_at) BETWEEN ? AND ?
   GROUP BY COALESCE(si.product_id, si.name) ORDER BY revenue DESC LIMIT ?`, [bizId, from, to, limit]);

export const expenseBreakdown = (bizId, from, to) => all(
  `SELECT category, SUM(amount) AS total FROM expenses WHERE business_id=? AND date(created_at) BETWEEN ? AND ? GROUP BY category ORDER BY total DESC`, [bizId, from, to]);

export async function stockStats(bizId) {
  const rows = await listProducts(bizId);
  let value = 0, retail = 0, low = 0, out = 0;
  for (const p of rows) {
    if (!p.track_stock) continue;
    value += Math.max(p.stock, 0) * p.buy_price;
    retail += Math.max(p.stock, 0) * p.sell_price;
    if (p.has_moves && p.stock <= 0) out += 1;
    else if (p.has_moves && p.stock <= p.low_stock) low += 1;
  }
  return { value, retail, low, out, count: rows.length };
}

export const recentActivity = (bizId, limit = 8) => all(
  `SELECT 'sale' AS t, id, total AS amount, created_at, CAST(receipt_no AS TEXT) AS ref FROM sales WHERE business_id = ? AND status = 'ok'
   UNION ALL SELECT 'expense', id, amount, created_at, category FROM expenses WHERE business_id = ?
   UNION ALL SELECT 'purchase', id, total, created_at, NULL FROM purchases WHERE business_id = ?
   ORDER BY created_at DESC LIMIT ?`, [bizId, bizId, bizId, limit]);

export const countRows = (table, bizId) => val(`SELECT COUNT(*) FROM ${table} WHERE business_id = ?`, [bizId]);
