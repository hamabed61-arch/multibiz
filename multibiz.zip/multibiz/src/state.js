// state.js - hali ya app inayoshirikiwa (mtumiaji, biashara iliyochaguliwa, alerts)
import { getSetting, setSetting } from './db/index.js';
import { setLang } from './i18n/index.js';
import { listBusinesses } from './data.js';
import { refreshAlerts, notifyNew, unreadCount } from './alerts.js';

export const S = { user: null, unlocked: false, biz: null, businesses: [], unread: 0 };
export const bus = new EventTarget();
export const nav = (path) => { location.hash = '#' + path; };

export async function loadUser() {
  const name = await getSetting('user_name');
  if (!name) return null;
  return {
    name,
    phone: await getSetting('user_phone', ''),
    salt: await getSetting('pin_salt'),
    hash: await getSetting('pin_hash'),
    lang: await getSetting('lang', 'sw')
  };
}

export async function loadBusinesses() {
  S.businesses = await listBusinesses();
  const activeId = await getSetting('active_business_id');
  S.biz = S.businesses.find((b) => b.id === activeId) || S.businesses[0] || null;
  if (S.biz && S.biz.id !== activeId) await setSetting('active_business_id', S.biz.id);
}

export async function setActiveBusiness(id) {
  await setSetting('active_business_id', id);
  await loadBusinesses();
  await afterChange();
}

// Ita baada ya kila badiliko la data (mauzo, stock, matumizi...): inahesabu alerts upya na kutuma notification
export async function afterChange() {
  if (!S.biz) return;
  try {
    const fresh = await refreshAlerts(S.biz);
    await notifyNew(S.biz, fresh);
    S.unread = await unreadCount(S.biz.id);
  } catch (e) {
    console.error('alerts', e);
  }
  bus.dispatchEvent(new Event('bell'));
}

// wakati wa kuanza app: angalia biashara zote
export async function checkAllBusinesses() {
  for (const b of S.businesses) {
    try { await notifyNew(b, await refreshAlerts(b)); } catch (e) { console.error('alerts', e); }
  }
  await afterChange();
}

export async function changeLanguage(code) {
  setLang(code);
  await setSetting('lang', code);
  if (S.user) S.user.lang = code;
  bus.dispatchEvent(new Event('rerender'));
}
