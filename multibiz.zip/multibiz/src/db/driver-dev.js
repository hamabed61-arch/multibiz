// driver-dev.js - kwa majaribio kwenye kompyuta tu (browser + dev/server.py).
// Kwenye simu (APK) faili hii haitumiki.
async function post(path, body) {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  const json = await res.json();
  if (!res.ok || json.error) throw new Error(json.error || 'SQL error');
  return json;
}

export async function create() {
  return {
    async open() { await post('/__sql', { op: 'exec', sql: 'SELECT 1;' }); },
    async exec(sql) { await post('/__sql', { op: 'exec', sql }); },
    async run(sql, params) { return post('/__sql', { op: 'run', sql, params }); },
    async all(sql, params) { return (await post('/__sql', { op: 'all', sql, params })).values; },
    async begin() { await post('/__sql', { op: 'exec', sql: 'BEGIN;' }); },
    async commit() { await post('/__sql', { op: 'exec', sql: 'COMMIT;' }); },
    async rollback() { await post('/__sql', { op: 'exec', sql: 'ROLLBACK;' }).catch(() => {}); }
  };
}
