// db/index.js - mlango mmoja wa kufikia database (native au dev)
import { MIGRATIONS, TABLES } from './schema.js';

let drv = null;

export function isNative() {
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

export async function initDb() {
  if (drv) return;
  const mod = isNative() ? await import('./driver-native.js') : await import('./driver-dev.js');
  drv = await mod.create();
  await drv.open();
  await migrate();
}

async function migrate() {
  await drv.exec('CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);');
  const row = (await drv.all("SELECT value FROM settings WHERE key = 'schema_version'", []))[0];
  let v = row ? parseInt(row.value, 10) : 0;
  while (v < MIGRATIONS.length) {
    await drv.exec(MIGRATIONS[v]);
    v += 1;
    await drv.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', ['schema_version', String(v)]);
  }
}

// ── helpers ──
export const all = (sql, p = []) => drv.all(sql, p);
export const run = (sql, p = []) => drv.run(sql, p);
export const one = async (sql, p = []) => (await drv.all(sql, p))[0] || null;
export async function val(sql, p = [], def = 0) {
  const r = await one(sql, p);
  if (!r) return def;
  const v = Object.values(r)[0];
  return v === null || v === undefined ? def : v;
}

export async function tx(fn) {
  await drv.begin();
  try {
    const out = await fn();
    await drv.commit();
    return out;
  } catch (e) {
    await drv.rollback();
    throw e;
  }
}

export const uid = () => (crypto.randomUUID ? crypto.randomUUID() : 'id-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 10));

// tarehe za hapa (saa za kifaa), muundo: YYYY-MM-DD HH:MM:SS
const p2 = (n) => String(n).padStart(2, '0');
export const dateStr = (d = new Date()) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
export const now = (d = new Date()) => `${dateStr(d)} ${p2(d.getHours())}:${p2(d.getMinutes())}:${p2(d.getSeconds())}`;
export const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };

// settings
export async function getSetting(key, def = null) {
  const r = await one('SELECT value FROM settings WHERE key = ?', [key]);
  return r ? r.value : def;
}
export const setSetting = (key, value) => run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, String(value)]);

// futa data zote (Reset app)
export async function wipeAll() {
  for (const t of TABLES) await drv.exec(`DROP TABLE IF EXISTS ${t};`);
  await migrate();
}

// Backup / Restore (JSON) - inafanya kazi kwa driver zote
export async function exportAll() {
  const out = { app: 'multibiz', version: 1, exported_at: now(), tables: {} };
  for (const t of TABLES) out.tables[t] = await all(`SELECT * FROM ${t}`);
  return out;
}

export async function importAll(data) {
  if (!data || data.app !== 'multibiz' || !data.tables) throw new Error('Invalid backup file');
  await tx(async () => {
    for (const t of TABLES) await run(`DELETE FROM ${t}`);
    for (const t of TABLES) {
      const rows = data.tables[t] || [];
      for (const r of rows) {
        const cols = Object.keys(r);
        if (!cols.length) continue;
        await run(`INSERT INTO ${t} (${cols.join(',')}) VALUES (${cols.map(() => '?').join(',')})`, cols.map((c) => r[c]));
      }
    }
  });
}
