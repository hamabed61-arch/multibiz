// schema.js - muundo wa database (SQLite). Ongeza migration mpya mwishoni mwa orodha.
// Kila rekodi ina id ya UUID (TEXT) na tarehe, ili sync ya cloud iwezekane baadaye.

export const TABLES = [
  'settings', 'businesses', 'products', 'stock_movements', 'customers', 'suppliers',
  'sales', 'sale_items', 'purchases', 'purchase_items', 'expenses', 'payments',
  'employees', 'production_units', 'production_logs', 'alerts'
];

export const MIGRATIONS = [
  // ── v1 ──
  `
  CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);

  CREATE TABLE IF NOT EXISTS businesses (
    id TEXT PRIMARY KEY, name TEXT NOT NULL, type TEXT NOT NULL, custom_type TEXT,
    location TEXT, phone TEXT, currency TEXT NOT NULL DEFAULT 'TZS',
    modules TEXT NOT NULL DEFAULT '[]', sort INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS products (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, category TEXT, unit TEXT,
    kind TEXT NOT NULL DEFAULT 'product', track_stock INTEGER NOT NULL DEFAULT 1,
    buy_price REAL NOT NULL DEFAULT 0, sell_price REAL NOT NULL DEFAULT 0,
    low_stock REAL NOT NULL DEFAULT 5, expiry_date TEXT, active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_products_biz ON products (business_id, active);

  CREATE TABLE IF NOT EXISTS stock_movements (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, product_id TEXT NOT NULL,
    type TEXT NOT NULL, qty REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0,
    ref_id TEXT, note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_stock_product ON stock_movements (product_id);

  CREATE TABLE IF NOT EXISTS customers (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT, address TEXT, note TEXT,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS suppliers (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT, address TEXT, note TEXT,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sales (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, receipt_no INTEGER NOT NULL, customer_id TEXT,
    subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0, total REAL NOT NULL, paid REAL NOT NULL,
    method TEXT NOT NULL DEFAULT 'cash', status TEXT NOT NULL DEFAULT 'ok', note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_sales_biz_date ON sales (business_id, created_at);
  CREATE INDEX IF NOT EXISTS idx_sales_customer ON sales (customer_id);

  CREATE TABLE IF NOT EXISTS sale_items (
    id TEXT PRIMARY KEY, sale_id TEXT NOT NULL, business_id TEXT NOT NULL, product_id TEXT,
    name TEXT NOT NULL, qty REAL NOT NULL, unit_price REAL NOT NULL, unit_cost REAL NOT NULL DEFAULT 0
  );
  CREATE INDEX IF NOT EXISTS idx_sale_items_sale ON sale_items (sale_id);

  CREATE TABLE IF NOT EXISTS purchases (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, supplier_id TEXT, total REAL NOT NULL, paid REAL NOT NULL,
    note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_purchases_biz_date ON purchases (business_id, created_at);
  CREATE TABLE IF NOT EXISTS purchase_items (
    id TEXT PRIMARY KEY, purchase_id TEXT NOT NULL, business_id TEXT NOT NULL, product_id TEXT NOT NULL,
    name TEXT NOT NULL, qty REAL NOT NULL, unit_cost REAL NOT NULL
  );

  CREATE TABLE IF NOT EXISTS expenses (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, category TEXT NOT NULL, amount REAL NOT NULL,
    note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_expenses_biz_date ON expenses (business_id, created_at);

  CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, party_type TEXT NOT NULL, party_id TEXT NOT NULL,
    amount REAL NOT NULL, method TEXT NOT NULL DEFAULT 'cash', note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_payments_party ON payments (party_type, party_id);

  CREATE TABLE IF NOT EXISTS employees (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, phone TEXT, role TEXT,
    salary REAL NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS production_units (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, name TEXT NOT NULL, count REAL NOT NULL DEFAULT 0,
    started_at TEXT, note TEXT, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL
  );
  CREATE TABLE IF NOT EXISTS production_logs (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, unit_id TEXT NOT NULL, log_date TEXT NOT NULL,
    metric TEXT NOT NULL, value REAL NOT NULL, note TEXT, created_at TEXT NOT NULL
  );
  CREATE INDEX IF NOT EXISTS idx_prod_logs ON production_logs (business_id, log_date);

  CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY, business_id TEXT NOT NULL, key TEXT NOT NULL, level TEXT NOT NULL,
    code TEXT NOT NULL, params TEXT NOT NULL DEFAULT '{}', active INTEGER NOT NULL DEFAULT 1,
    read INTEGER NOT NULL DEFAULT 0, notified INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL
  );
  CREATE UNIQUE INDEX IF NOT EXISTS idx_alerts_key ON alerts (business_id, key);
  `
];
