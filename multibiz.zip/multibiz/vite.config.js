import { defineConfig } from 'vite';

// base './' ni muhimu ili faili zipatikane ndani ya APK (bila server)
export default defineConfig({
  base: './',
  build: { outDir: 'dist', emptyOutDir: true, chunkSizeWarningLimit: 1500 }
});
